# -*- coding: utf-8 -*-
"""
Created on Fri Nov  9 17:59:27 2018

@author: Otto
"""

# -*- coding: utf-8 -*-
"""
Created on Sat Aug 12 17:29:25 2017

@author: Otto


However, it is possible to add many Orders at once.
When initiating a order message the received Order list or df is checked on consistency.
A DataFrame is returned. The DataFrame then can be added to a Orderbook.


Note init_time attribute is not the actual time of the model run, but the rank number in
which the agents took steps. these rank is random (random scheduler). However important
to prioritise orders with same price

order type: limit order means that the volume can be partially cleared, while the rest stays in the order book.
Order type: All-or-none means that the order can only be matched entirely or not
Order type: market order means that it is fill-and-kill order where as much as possible is cleared, but no rest stays in the order book.
            Market orders have currently a price of buy 1000 or sell -1000 EUR/MWh. this has a effect on market statistics.
"""
import pandas as pd
from pandas import Series, DataFrame
import numpy as np


class OrderMessage():

    def __init__(self, orders):
        #label lists needed to convert single orders in dataframe collections
        self.columnlabels = ['agent_id','associated_asset','delivery_location',
                             'volume','price', 'delivery_day','delivery_time',
                             'order_type','init_time', 'order_id', 'direction','delivery_duration']

        self.order_df = self.consistency_check(orders)
        self.order_df, self.portfolio_exclusions = self.exclude_internal_IDtrades(self.order_df)

    def consistency_check(self, orders):
        if type(orders) is list:
            order_df = DataFrame(orders, columns = self.columnlabels)
        else:
            order_df = orders
        if (order_df['order_type']=='redispatch_demand').any():
            #TSO orders do not contain price integers but nan which are considered as float64 by dtypes
            consistent_reference = DataFrame([['o','o','o',1,1.1,
                                     1,1,'o',1.1,
                                     'o','o',1]],columns=self.columnlabels).dtypes
        else:
            consistent_reference = DataFrame([['o','o','o',1,1,
                                     1,1,'o',1.1,
                                     'o','o',1]],columns=self.columnlabels).dtypes
        if (order_df['volume']<=0).any():
            import pdb
            pdb.set_trace()
            raise Exception('order message volume <=0...')

        if consistent_reference.equals(order_df.dtypes):
            return (order_df)
        else:
            import pdb
            pdb.set_trace()
            print(order_df)
            print(order_df.dtypes)
            print (consistent_reference)
            raise Exception('Order Message contains invalid dtypes at some columns')

    def exclude_internal_IDtrades(self, orders):
        """this is actually a agent portfolio 'matching'"""
        orders.set_index(['delivery_day','delivery_time'], inplace=True)
        orders.sort_index(inplace=True)
        if ((orders['order_type']=='intraday_limit_order').any())|(
                (orders['order_type']=='market_order').any())|(
                 (orders['order_type']=='IDCONS_order').any()):
            excl_lst=[]
            for deliveryday, orders_t in orders.groupby(level=[0,1]):
                sells = orders_t.loc[orders_t['direction']=='sell']
                buys = orders_t.loc[orders_t['direction']=='buy']
                low_sells=sells.loc[sells['price']<=buys['price'].max()].copy()
                high_buys=buys.loc[buys['price']>=sells['price'].min()].copy()
                if low_sells['volume'].sum()>high_buys['volume'].sum():
                    excl_lst =excl_lst + list(high_buys['order_id'])
                    low_sells.sort_values(['price'], ascending=True,inplace=True)
                    o_numb = len(low_sells.loc[low_sells['volume'].cumsum()<high_buys['volume'].sum()])
                    excl_lst =excl_lst+ list(low_sells['order_id'].iloc[:o_numb])
                    #volume correction of the last order that overlaps with the buys
                    o_id = low_sells['order_id'].iloc[o_numb]
                    orders['volume'].loc[orders['order_id']==o_id] = low_sells['volume'].iloc[:o_numb+1].sum()-high_buys['volume'].sum()

                elif low_sells['volume'].sum()<high_buys['volume'].sum():
                    #exclude all low_sells
                    excl_lst =excl_lst + list(low_sells['order_id'])
                    #exclude as much highbuys as vilume of lowsells, in decending price order
                    high_buys.sort_values(['price'], ascending=False,inplace=True)
                    o_numb = len(high_buys.loc[high_buys['volume'].cumsum()<low_sells['volume'].sum()])
                    excl_lst =excl_lst+ list(high_buys['order_id'].iloc[:o_numb])
                    #volume correction of the last order that overlaps with the sells
                    o_id = high_buys['order_id'].iloc[o_numb]
                    orders['volume'].loc[orders['order_id']==o_id] = high_buys['volume'].iloc[:o_numb+1].sum()-low_sells['volume'].sum()
                else:
                    excl_lst =excl_lst + list(high_buys['order_id']) + list(low_sells['order_id'])

                if excl_lst:
                    #filter the excluded orders and return
                    orders_df=orders.loc[~(orders['order_id'].isin(excl_lst))].reset_index()
                    excl_orders=orders.loc[orders['order_id'].isin(excl_lst)].reset_index()
                    print('portfolio internal matched ID orders')
                    print(excl_orders)
                    return (orders_df, excl_orders)
                else:
                    return(orders.reset_index(), DataFrame())
        else:
            orders.reset_index(inplace=True)
            excl_orders=DataFrame()
            return (orders, excl_orders)

    def get_as_df(self):
        return(self.order_df)



"""test"""
#lst=[]
#o1= ['werdenn','dasda','o',12,10,2,14,'full_flex', 1,'id1' ,'sell']
#lst.append(o1)
#o2= ['werdend','dasda','o',12,20,2,14,'full_flex', 1,'id2' ,'sell']
#lst.append(o2)
#o3= ['werdenn','dasda','o',12,30,2,14,'full_flex', 1,'id3' ,'sell']
#lst.append(o3)
#o4= ['werdend','dasda','o',12,25,2,14,'full_flex', 1,'id4' ,'buy']
#lst.append(o4)
#o5= ['werdend','dasda','o',11,15,2,14,'full_flex', 1,'id5' ,'buy']
#lst.append(o5)
#o6= ['werdend','dasda','o',12,5,2,14,'full_flex', 1,'id6' ,'buy']
#lst.append(o6)
#newOM =    OrderMessage(lst)
#df =newOM.get_as_df()
#excl= newOM.portfolio_exclusions



