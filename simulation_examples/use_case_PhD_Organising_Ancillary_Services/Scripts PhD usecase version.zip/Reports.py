# -*- coding: utf-8 -*-
"""
Created on Wed Oct 11 09:59:29 2017

@author: Otto
"""

from mesa import Agent, Model
import pandas as pd
from pandas import Series, DataFrame
import numpy as np



class Reports():
    def __init__(self, model, areas):
        self.model = model
        self.areas = areas
        #all_books dict is used to capture market stats
        self.all_books ={}
        try:
            self.all_books['RED']=self.model.red_obook
        except AttributeError:
            pass
        try:
            self.all_books['IDM']=self.model.IDM_obook
        except AttributeError:
            pass
        try:
            self.all_books['DAM']=self.model.DAM_obook
        except AttributeError:
            pass
        try:
            self.all_books['BEM']=self.model.BEM_obook
        except AttributeError:
            pass

        #here it is possible to add simple reports
        self.table_reporters = {}
        self.model_reporters = {}
        self.agent_reporters = {"bank_deposit": lambda a: a.money,
                                "step_rank": lambda a: a.step_rank}

        #TODO: initilize this elsewhere (only if IBM and BEM are simulated)
        self.DAM_prices=DataFrame()
        self.IBM_prices = self.model.clock.schedule_template.copy()
        self.IBM_prices['IBP_short'] = None
        self.IBM_prices['IBP_long'] =None
        self.IBM_prices['regulating_state'] = None
        self.IBM_prices.drop('commit',axis=1, inplace=True)
        #Df with expected imbalance prices. this is updated every step and has size of schedules_horizon
        self.eIBP = DataFrame()


    def rep_portfolio(self):
        """return the total portfolio of initialized agents"""
        assetsdf = DataFrame()
        for agent in self.model.schedule.agents:
            all_ids = agent.assets.index.values
            # this is a place holder for a Day-ahead market result dispatch method
            for i in range(len(all_ids)):
                a = agent.assets.loc[all_ids[i],:].item()
                df = a.get_as_df()
#                df.insert(loc = 0, column ='agent_id',value = agent.unique_id)
                assetsdf = pd.concat([assetsdf, df], ignore_index=True)
        return(assetsdf)

    def rep_sim_task(self):
        df = self.model.exodata.sim_task
        return (df)

    def rep_market_rules(self):
        df = self.model.exodata.market_rules
        return (df)

    def rep_agent_strategies(self):
        df = self.model.exodata.agent_strategies
        return (df)

    def rep_congestions(self):
        df = self.model.exodata.congestions
        return (df)

    def rep_forecast_errors(self):
        df = self.model.exodata.forecast_errors
        return (df)


    def publish_DAM_prices(self,clearing_prices):
        #receives clearing prices from DAM operator and conversts them to mtu prices
        clearing_prices = pd.concat([clearing_prices,clearing_prices,clearing_prices,clearing_prices])
        clearing_prices.sort_index(inplace=True)
        if (self.model.clock.get_MTU() >= self.model.DA_marketoperator.gate_closure_time) & (
                self.model.schedule.steps == 0):
            #get the right delivery mtu from the schedules horizon
            mtus = list(self.model.schedules_horizon.index.get_level_values(1))
        elif (self.model.clock.get_MTU() < self.model.DA_marketoperator.gate_closure_time) & (
                self.model.schedule.steps == 0):
            mtus = list(range(self.model.clock.get_MTU(),97))
        elif self.model.clock.get_MTU() == self.model.DA_marketoperator.gate_closure_time:
            mtus = list(range(1,97))
        #cut of MTUs of a first hour that lie in the past.
        cut_value =len(clearing_prices)-len(mtus)

        clearing_prices = clearing_prices.iloc[len(clearing_prices)-len(mtus):]
        clearing_prices['delivery_time'] = mtus
        clearing_prices.drop('delivery_hour', axis = 1, inplace = True)
        clearing_prices.set_index(['delivery_day','delivery_time'], inplace= True)
        #change the bus name from pypsa model. to be generic, the column is copied and the original is dropped
        clearing_prices.rename(columns={clearing_prices.columns[0]:'DAP'},inplace =True)
        self.DAM_prices = pd.concat([self.DAM_prices,clearing_prices], axis=0)

    def publish_BEM_regulating_state(self,cur_reg_state, day, mtu):
        self.IBM_prices.loc[(day,mtu),'regulating_state'] = cur_reg_state

    def publish_IBM_prices(self,IBP_short,IBP_long, day, mtu):
        self.IBM_prices.loc[(day,mtu),'IBP_short'] = IBP_short
        self.IBM_prices.loc[(day,mtu),'IBP_long'] = IBP_long

    def update_expected_IBP(self):
        """the expeced IBP dataframe is updated every step to ensure similar length
           with self.model.schedules_horizon"""

        if not self.DAM_prices.empty:
            self.eIBP = self.DAM_prices.loc[self.model.schedules_horizon.index]
        else:
            #if there is either no DAM run, or a default run without hourly prices
            self.eIBP = self.model.schedules_horizon
            self.eIBP['DAP'] = 30

        #MTU of hour list needed to get the specific opportunity cost distribution function
        MTU = list(self.eIBP.index.get_level_values(1))
        MTU_of_h = []
        for mtu in MTU:
            mtu_of_h = mtu%4
            if mtu_of_h == 0:
                mtu_of_h=4
            MTU_of_h += [mtu_of_h]
        DAP = list(self.eIBP['DAP'])
        odf = self.model.exodata.opportunity_costs_db
        expected_values_short =[]
        expected_values_long =[]
        for p in range(len(DAP)):
            #expeced value of IBP given a DA bin. The K-value is irrelevant here, but one existing (e.g. 30) must be chosen.
            try:
                value_short =odf.loc[(odf['price_data']=='IB_price_short') & (odf['PTU_of_an_hour']==MTU_of_h[p]) & (
                    odf['DAP_left_bin']<=DAP[p]) & (odf['DAP_right_bin(excl)'] >DAP[p] ) & (
                            odf['K-value'] == 30),'bin_exp_value'].iloc[0]
            except:
                import pdb
                pdb.set_trace()

            expected_values_short += [int(round(value_short,0))]

            value_long =odf.loc[(odf['price_data']=='IB_price_long') & (odf['PTU_of_an_hour']==MTU_of_h[p]) & (
                    odf['DAP_left_bin']<=DAP[p]) & (odf['DAP_right_bin(excl)'] >DAP[p] ) & (
                            odf['K-value'] == 30),'bin_exp_value'].iloc[0]
            expected_values_long += [int(round(value_long,0))]

        self.eIBP['expected_IBP_short'] =expected_values_short
        self.eIBP['expected_IBP_long'] = expected_values_long


    def save_all_orders_per_round(self, modus='as_dict'):
        """
        -method must be applied before save_market stats,
        because otherwise orders are deleted"""
        day, MTU=   self.model.clock.calc_timestamp_by_steps(self.model.schedule.steps -1, 0)
        key =str('(')+str(day)+str(', ')+str(MTU)+str(')')
        if modus == 'as dict':
            for obook in self.all_books.keys():
                self.all_books[obook].buyorders_per_round[key] = self.all_books[obook].buyorders_full_step
                self.all_books[obook].sellorders_per_round[key] = self.all_books[obook].sellorders_full_step
                self.all_books[obook].cleared_buyorders_per_round[key] = self.all_books[obook].cleared_buyorders
                self.all_books[obook].cleared_sellorders_per_round[key] = self.all_books[obook].cleared_sellorders
        elif modus == 'as_df':
            for obook in self.all_books.keys():
                self.all_books[obook].buyorders_full_step['offer_daytime']= key
                self.all_books[obook].buyorders_all_df = pd.concat([self.all_books[obook].buyorders_all_df,
                                                                   self.all_books[obook].buyorders_full_step], ignore_index=True)
                self.all_books[obook].sellorders_full_step['offer_daytime']= key
                self.all_books[obook].sellorders_all_df = pd.concat([self.all_books[obook].sellorders_all_df,
                                                                    self.all_books[obook].sellorders_full_step], ignore_index=True)
                self.all_books[obook].cleared_buyorders['offer_daytime']= key
                self.all_books[obook].cleared_buyorders_all_df = pd.concat([self.all_books[obook].cleared_buyorders_all_df,
                                                                          self.all_books[obook].cleared_buyorders], ignore_index=True)
                self.all_books[obook].cleared_sellorders['offer_daytime']= key
                self.all_books[obook].cleared_sellorders_all_df = pd.concat([self.all_books[obook].cleared_sellorders_all_df,
                                                                            self.all_books[obook].cleared_sellorders], ignore_index=True)
                if obook == 'RED':
                    #Attention
                    self.all_books[obook].redispatch_demand_orders_upward['offer_daytime']= key
                    self.all_books[obook].redispatch_demand_upward_all_df=pd.concat([self.all_books[obook].redispatch_demand_upward_all_df,
                                  self.all_books[obook].redispatch_demand_orders_upward], ignore_index=True)
                    self.all_books[obook].redispatch_demand_orders_downward['offer_daytime']= key
                    self.all_books[obook].redispatch_demand_downward_all_df=pd.concat([self.all_books[obook].redispatch_demand_downward_all_df,
                                  self.all_books[obook].redispatch_demand_orders_downward], ignore_index=True)


    def save_market_stats(self, mode='at_end'):
        """method called at the beginning of a model step, to store results of previous step
           - it is not saved at the end of the step because schedule.step() increases
           the step counter

           Note that sum volume figures are sum of (cleared) order MW. Not MWh"""

        #calculate timestamp of last round
        day, MTU=   self.model.clock.calc_timestamp_by_steps(self.model.schedule.steps -1, 0)
        end_date = self.model.clock.calc_timestamp_by_steps(0,self.model.exodata.sim_task.loc[0,'number_steps']-1)


#        self.save_all_orders_per_round(modus='as_df')
        if mode=='at_end':
            """stats are only savend once at the end of the simulation"""
            #save orders in dict
            self.save_all_orders_per_round(modus='as_df')

            if not (day==end_date[0])&(MTU == end_date[1]):
                #and delete orders per round

                for obook in self.all_books.keys():
                    self.all_books[obook].sellorders_full_step =self.all_books[obook].sellorders_full_step.iloc[0:0]
                    self.all_books[obook].buyorders_full_step =self.all_books[obook].buyorders_full_step.iloc[0:0]
                    self.all_books[obook].cleared_sellorders =self.all_books[obook].cleared_sellorders.iloc[0:0]
                    self.all_books[obook].cleared_buyorders =self.all_books[obook].cleared_buyorders.iloc[0:0]
                    if obook == 'RED':
                        self.all_books[obook].redispatch_demand_orders_upward=self.all_books[obook].redispatch_demand_orders_upward.iloc[0:0]
                        self.all_books[obook].redispatch_demand_orders_downward=self.all_books[obook].redispatch_demand_orders_downward.iloc[0:0]

            else:
                for obook in self.all_books.keys():
                    #copy all orders to the per step df
                    self.all_books[obook].sellorders_full_step =self.all_books[obook].sellorders_all_df
                    self.all_books[obook].buyorders_full_step =self.all_books[obook].buyorders_all_df
                    self.all_books[obook].cleared_sellorders =self.all_books[obook].cleared_sellorders_all_df
                    self.all_books[obook].cleared_buyorders =self.all_books[obook].cleared_buyorders_all_df
                    if obook == 'RED':
                        self.all_books[obook].redispatch_demand_orders_upward =self.all_books[obook].redispatch_demand_upward_all_df
                        self.all_books[obook].redispatch_demand_orders_downward =self.all_books[obook].redispatch_demand_downward_all_df
        if (mode =='every_round')|((day==end_date[0])&(MTU == end_date[1])):

            print('save market statistics of previous round')
            for obook in self.all_books.keys():

                if obook == 'RED':
                    round_index = (slice(None),slice(day,day),slice(MTU,MTU))
                else:
                    round_index = (day,MTU)

                if self.all_books[obook].sellorders_full_step.empty:
                    pass
                else:
                    if obook =='IDM':
                        #market order prices of need to be set to np.nan to avoid distortion of statistic
                        self.all_books[obook].sellorders_full_step.loc[self.all_books[obook].sellorders_full_step
                                       ['order_type'] == 'market_order', 'price'] = np.nan
                    res = self.group_statistic(self.all_books[obook].sellorders_full_step, 'volume', obook)
                    if obook=='RED':
                        included_areas=list(res.index.unique().get_level_values(level=0))
                        res=res.unstack(level=0)
                        for i in range(len(included_areas)):
                            area =included_areas[i]
                            #store results in report matrixes
                            self.all_books[obook].sell_sum_volume.loc[(area,day,MTU),:] = res.loc[:,('volume','sum',area)].copy()
                            self.all_books[obook].sell_min_price.loc[(area,day,MTU),:] = res.loc[:,('price','min',area)].copy()
                            self.all_books[obook].sell_wm_price.loc[(area,day,MTU),:] = res.loc[:,('price','weighted_mean',area)].copy()
                            self.all_books[obook].sell_max_price.loc[(area,day,MTU),:] = res.loc[:,('price','max',area)].copy()
                    else:
                        #store results in report matrixes
                        self.all_books[obook].sell_sum_volume.loc[round_index,res.index] = res[('volume','sum')].copy()
                        self.all_books[obook].sell_min_price.loc[round_index,res.index] = res[('price','min')].copy()
                        self.all_books[obook].sell_wm_price.loc[round_index,res.index] = res[('price','weighted_mean')].copy()
                        self.all_books[obook].sell_max_price.loc[round_index,res.index] = res[('price','max')].copy()
                    #clean the orderbook for the next round
                    self.all_books[obook].sellorders_full_step=self.all_books[obook].sellorders_full_step.iloc[0:0]
                if self.all_books[obook].buyorders_full_step.empty:
                    pass
                else:
                    if obook =='IDM':
                        #market order prices of need to be set to np.nan to avoid distortion of statistic
                        self.all_books[obook].buyorders_full_step.loc[self.all_books[obook].buyorders_full_step
                                       ['order_type'] == 'market_order', 'price'] = np.nan
                    res = self.group_statistic(self.all_books[obook].buyorders_full_step, 'volume', obook)
                    if obook=='RED':
                        included_areas=list(res.index.unique().get_level_values(level=0))
                        res=res.unstack(level=0)
                        for i in range(len(included_areas)):
                            area =included_areas[i]
                            #store results in report matrixes
                            self.all_books[obook].buy_sum_volume.loc[(area,day,MTU),:] = res.loc[:,('volume','sum',area)].copy()
                            self.all_books[obook].buy_min_price.loc[(area,day,MTU),:] = res.loc[:,('price','min',area)].copy()
                            self.all_books[obook].buy_wm_price.loc[(area,day,MTU),:] = res.loc[:,('price','weighted_mean',area)].copy()
                            self.all_books[obook].buy_max_price.loc[(area,day,MTU),:] = res.loc[:,('price','max',area)].copy()
                    else:
                        #store results in report matrixes
                        self.all_books[obook].buy_sum_volume.loc[round_index, res.index] = res[('volume','sum')].copy()
                        self.all_books[obook].buy_min_price.loc[round_index, res.index] = res[('price','min')].copy()
                        self.all_books[obook].buy_wm_price.loc[round_index, res.index] = res[('price','weighted_mean')].copy()
                        self.all_books[obook].buy_max_price.loc[round_index, res.index] = res[('price','max')].copy()
                    #clean the orderbook for the next round
                    self.all_books[obook].buyorders_full_step=self.all_books[obook].buyorders_full_step.iloc[0:0]

                if self.all_books[obook].cleared_sellorders.empty:
                    pass
                else:
                    res = self.group_statistic(self.all_books[obook].cleared_sellorders, 'cleared_volume', obook)
                    if obook=='RED':
                        included_areas=list(res.index.unique().get_level_values(level=0))
                        res=res.unstack(level=0)
                        for i in range(len(included_areas)):
                            area =included_areas[i]
                            #store results in report matrixes
                            self.all_books[obook].cleared_sell_sum_volume.loc[(area,day,MTU),:] = res.loc[:,('cleared_volume','sum',area)].copy()
                            self.all_books[obook].cleared_sell_min_price.loc[(area,day,MTU),:] = res.loc[:,('cleared_price','min',area)].copy()
                            self.all_books[obook].cleared_sell_wm_price.loc[(area,day,MTU),:] = res.loc[:,('cleared_price','weighted_mean',area)].copy()
                            self.all_books[obook].cleared_sell_max_price.loc[(area,day,MTU),:] = res.loc[:,('cleared_price','max',area)].copy()
                            self.all_books[obook].cleared_sellorders=self.all_books[obook].cleared_sellorders.iloc[0:0]
                    else:
                        #store results in report matrixes
                        self.all_books[obook].cleared_sell_sum_volume.loc[round_index, res.index] = res[('cleared_volume','sum')].copy()
                        self.all_books[obook].cleared_sell_min_price.loc[round_index, res.index] = res[('cleared_price','min')].copy()
                        self.all_books[obook].cleared_sell_wm_price.loc[round_index, res.index] = res[('cleared_price','weighted_mean')].copy()
                        self.all_books[obook].cleared_sell_max_price.loc[round_index, res.index] = res[('cleared_price','max')].copy()
                    #clean the orderbook for the next round
                    self.all_books[obook].cleared_sellorders=self.all_books[obook].cleared_sellorders.iloc[0:0]
                if self.all_books[obook].cleared_buyorders.empty:
                    pass
                else:
                    res = self.group_statistic(self.all_books[obook].cleared_buyorders, 'cleared_volume', obook)
                    if obook=='RED':
                        included_areas=list(res.index.unique().get_level_values(level=0))
                        res=res.unstack(level=0)
                        for i in range(len(included_areas)):
                            area =included_areas[i]
                            #store results in report matrixes
                            self.all_books[obook].cleared_buy_sum_volume.loc[(area,day,MTU),:] = res.loc[:,('cleared_volume','sum',area)].copy()
                            self.all_books[obook].cleared_buy_min_price.loc[(area,day,MTU),:] = res.loc[:,('cleared_price','min',area)].copy()
                            self.all_books[obook].cleared_buy_wm_price.loc[(area,day,MTU),:] = res.loc[:,('cleared_price','weighted_mean',area)].copy()
                            self.all_books[obook].cleared_buy_max_price.loc[(area,day,MTU),:] = res.loc[:,('cleared_price','max',area)].copy()
                            self.all_books[obook].cleared_buyorders=self.all_books[obook].cleared_sellorders.iloc[0:0]
                    else:
                        #store results in report matrixes
                        self.all_books[obook].cleared_buy_sum_volume.loc[round_index, res.index] = res[('cleared_volume','sum')].copy()
                        self.all_books[obook].cleared_buy_min_price.loc[round_index, res.index] = res[('cleared_price','min')].copy()
                        self.all_books[obook].cleared_buy_wm_price.loc[round_index, res.index] = res[('cleared_price','weighted_mean')].copy()
                        self.all_books[obook].cleared_buy_max_price.loc[round_index, res.index] = res[('cleared_price','max')].copy()
                    #clean the orderbook for the next round
                    self.all_books[obook].cleared_buyorders=self.all_books[obook].cleared_buyorders.iloc[0:0]

                if obook=='RED':
                    round_index = (slice(None),slice(day,day),slice(MTU,MTU))
                    #get redispatch demand order volume upward
                    if self.all_books[obook].redispatch_demand_orders_upward.empty:
                        pass
                    else:
                        red =  self.group_statistic(self.all_books[obook].redispatch_demand_orders_upward.fillna(value=0), 'volume', obook)
                        included_areas=list(red.index.unique().get_level_values(level=0))
                        red=red.unstack(level=0)
                        for i in range(len(included_areas)):
                            area =included_areas[i]
                            self.all_books[obook].redispatch_demand_upward.loc[(area,day,MTU),:] = red.loc[:,('volume','sum',area)].copy()
                        self.all_books[obook].redispatch_demand_orders_upward=self.all_books[obook].redispatch_demand_orders_upward.iloc[0:0]
                    #get redispatch demand order volume downward

                    if self.all_books[obook].redispatch_demand_orders_downward.empty:
                        pass
                    else:
                        red =  self.group_statistic(self.all_books[obook].redispatch_demand_orders_downward.fillna(value=0), 'volume', obook)
                        included_areas=list(red.index.unique().get_level_values(level=0))
                        red=red.unstack(level=0)
                        for i in range(len(included_areas)):
                            area =included_areas[i]
                            self.all_books[obook].redispatch_demand_downward.loc[(area,day,MTU),:] = red.loc[:,('volume','sum',area)].copy()
                        self.all_books[obook].redispatch_demand_orders_downward=self.all_books[obook].redispatch_demand_orders_downward.iloc[0:0]




    def group_statistic(self, data, volume_type, obook):
        """volume_type must be string 'volume' or string 'cleared_volume'"""
        if volume_type == 'cleared_volume':
            price_type = 'cleared_price'
        else:
            price_type = 'price'
        if  obook=='RED':
            group_lst= ['delivery_location','delivery_day','delivery_time']
        else:
            group_lst= ['delivery_day','delivery_time']
        data=data.reset_index()
        grouped = data.groupby(group_lst)
        try:

            wm = lambda x: np.average(x, weights=data.loc[x.index,volume_type])
        except:
            import pdb
            pdb.set_trace()

        f = {volume_type: ['sum'],price_type:{'weighted_mean' : wm,
             'mean': np.mean, 'max': np.max, 'min': np.min} }
        result =grouped.agg(f)
        result= result.reset_index()
        result[['delivery_day','delivery_time']]=result[['delivery_day','delivery_time']].astype(int)
        result.set_index(group_lst, inplace=True)
        result.sort_index(inplace = True)
        return(result)


    def get_system_trade(self):
        """sum of cleared orders (buy and sell seperated and as total saldo)
        for all deliverytimes.it shows all trades up to the step of method application"""
        all_trades=DataFrame()
        buy_keys =[]
        sell_keys=[]
        for obook in self.all_books.keys():
            csell = self.all_books[obook].cleared_sell_sum_volume.sum()
            cbuy =self.all_books[obook].cleared_buy_sum_volume.sum()
            all_trades[str(obook)+ '_sell' ] = csell
            all_trades[str(obook)+ '_buy' ] = cbuy
            if (str(obook) =='DAM')|(str(obook) =='IDM'):
                #store keys of commodity markets to check consistency
                buy_keys =buy_keys +[str(obook)+ '_buy']
                sell_keys =sell_keys +[str(obook)+ '_sell']


        all_trades['sum_trades'] = all_trades[buy_keys].sum(axis=1)-all_trades[sell_keys].sum(axis=1)

        return (all_trades)


    def get_all_trade_schedules(self):
        """BE position and forecast errors are excluded for the moment, because not used"""
        all_trade_schedules = DataFrame()
        for agent in self.model.schedule.agents:
            df=agent.trade_schedule.copy()
            df.drop(['BE_position','commit','forecast_error','total_dispatch'], axis=1, inplace=True)
            df.columns=pd.MultiIndex.from_product([[agent.unique_id],df.columns])
            all_trade_schedules = pd.concat([all_trade_schedules,df], axis=1)
        return (all_trade_schedules)

    def get_all_returns(self):
        """BE return are excluded for the moment, because not used"""
        all_returns = DataFrame()
        for agent in self.model.schedule.agents:
            df=agent.financial_return.copy()
            df.drop(['BE_return','commit'], axis=1, inplace=True)
            df.columns=pd.MultiIndex.from_product([[agent.unique_id],df.columns])
            all_returns = pd.concat([all_returns,df], axis=1)
        return (all_returns)


    def get_system_dispatch(self):
        all_scheds = {}
        for agent in self.model.schedule.agents:
            for asset in agent.assets['object']:
                name =  asset.assetID
                all_scheds[name]=asset.schedule['commit']
        dispatch_df = DataFrame.from_dict(all_scheds)
        dispatch_df['sum_dispatch'] = dispatch_df.sum(axis=1)
        return (dispatch_df)

    def get_system_cost(self):
        """ critics: intraday return is counted twice, while redispatch and DA are not"""
        all_return = {}
        all_dispatch_cost = {}
        for agent in self.model.schedule.agents:
            all_return[agent.unique_id] = agent.financial_return['total_return']
            all_dispatch_cost[agent.unique_id] = agent.financial_return['total_dispatch_costs']
        return_df =  DataFrame.from_dict(all_return)
        return_df['sum_return'] = return_df.sum(axis = 1)
        dcost_df =  DataFrame.from_dict(all_dispatch_cost)
        dcost_df['sum_dispatch_cost'] = dcost_df.sum(axis = 1)
        df = pd.concat([return_df['sum_return'],dcost_df['sum_dispatch_cost']], axis =1)
        df['producer_surplus'] = df['sum_return'] + df['sum_dispatch_cost']
        return (df)

    def get_cleared_prices(self):
        prices =pd.concat([self.DAM_prices,self.IBM_prices], axis =1)

         #make weighted averages over all simulation steps
        vol_red_up=self.model.red_obook.cleared_sell_sum_volume
        wm_red_up=(self.model.red_obook.cleared_sell_wm_price * vol_red_up/(vol_red_up.sum().T)).sum()

        vol_red_down=self.model.red_obook.cleared_buy_sum_volume
        wm_red_down=(self.model.red_obook.cleared_buy_wm_price * vol_red_down/(vol_red_down.sum().T)).sum()

        vol_IDM = self.model.IDM_obook.cleared_sell_sum_volume
        wm_IDM=(self.model.IDM_obook.cleared_sell_wm_price * vol_IDM/(vol_IDM.sum().T)).sum()
        #Attention, it should be mentioned explicitly that in case one value is missing a 0 is assumed.
        wm_red_spread =wm_red_up.sub(wm_red_down, fill_value=0)

        prices['IDM_weighted_mean'] = wm_IDM
        prices['RED_upwards_weighted_mean'] =wm_red_up
        prices['RED_downwards_weighted_mean'] =wm_red_down
        prices['RED_spread_weighted_mean'] =wm_red_spread

        return(prices)

    def redispatch_PI(self, norm_values_to =None):
        """this method provides the performance indicators 'oversupply procurement',
        under procurement and 'redisaptch imbalance' per delivery timestamp
        Note that the values are in MW, not MWh"""

        #get a dataframe with cleared redispatch and imbalances for the past up to horizon.
        r_pi = pd.concat([self.model.aTSO.imbalances['imbalance_redispatch'],
                          self.model.aTSO.system_transactions[['RED_buy', 'RED_sell']]],axis=1)
        r_pi['redispatch_demand'] = np.nan

        #current time;
        cur_day = self.model.schedules_horizon.index.get_level_values(0)[0]
        cur_mtu = self.model.schedules_horizon.index.get_level_values(1)[0]
        if self.model.exodata.sim_task.loc[0,'congestions'] == 'exogenious':
            #GET all congestions up to this point

            cong = self.model.exodata.congestions.loc[(self.model.exodata.congestions[
                    'identification_day']<=cur_day)&(self.model.exodata.congestions[
                            'identification_MTU']<=cur_mtu)]
            if cong.empty:
                pass
            else:
                for i in range(len(cong)):
                    #there can be overlapping congestions
                    a_cong= r_pi.loc[(slice(cong.loc[i,'congestion_start_day'],cong.loc[
                            i,'congestion_end_day']), slice(cong.loc[i,'congestion_start_time'
                                                  ], cong.loc[i,'congestion_end_time'
                                                  ])), 'redispatch_demand']
                    a_cong = a_cong.add(cong.loc[i,'redispatch_volume'], fill_value=0)
                    try:
                        r_pi.loc[a_cong.index,'redispatch_demand'] = r_pi.loc[a_cong.index,'redispatch_demand'].add(a_cong, fill_value =0)
                    except:
                        #a_cong not in the index horizon of r_pi
                        pass
        elif self.model.exodata.sim_task.loc[0,'congestions'] == 'from_scenario':
             #Get all congestions up to this point
             #select all congestions within the schedules horizon with indetification time == current
            cong = self.model.exodata.congestions.loc[(
                    self.model.exodata.congestions['identification_day'] <=cur_day)&(
                            self.model.exodata.congestions['identification_mtu'] <=cur_mtu)]
            #ensure that congestions before starttime are not considered
            try:
                cong = cong.loc[(cong['identification_day']>=self.model.exodata.sim_task.loc[0, 'start_day'])&(
                        cong['identification_mtu']>=self.model.exodata.sim_task.loc[0, 'start_MTU'])]

            except:
                #start day and startday are 'from_scenario' instead of integers
                pass
            if cong.empty:
                pass
            else:
                r_pi.loc[cong.index,'redispatch_demand'] = cong['congestion_MW']
        else:
            raise Exception('redispatch_PI doesnt now sim_task congestion paramameter')

        r_pi['residual_demand_downwards'] = r_pi['RED_buy']- r_pi['redispatch_demand']
        r_pi['residual_demand_upwards'] = r_pi['RED_sell']- r_pi['redispatch_demand']
        r_pi['overproc_downwards'] = r_pi['residual_demand_downwards'].where(r_pi['residual_demand_downwards']>0,np.nan)
        r_pi['underproc_downwards'] = -r_pi['residual_demand_downwards'].where(r_pi['residual_demand_downwards']<0,np.nan)
        r_pi['overproc_upwards'] = r_pi['residual_demand_upwards'].where(r_pi['residual_demand_upwards']>0,np.nan)
        r_pi['underproc_upwards'] = -r_pi['residual_demand_upwards'].where(r_pi['residual_demand_upwards']<0,np.nan)
        r_pi['redispatch_solved'] =pd.concat([r_pi['redispatch_demand'].fillna(value=0).where(r_pi['RED_buy']>=r_pi['redispatch_demand'], r_pi['RED_buy']
            ), r_pi['redispatch_demand'].fillna(value=0).where(r_pi['RED_sell']>=r_pi['redispatch_demand'], r_pi['RED_sell'])], axis=1).sum(axis=1)/2
        """to be added when needed"""
        #sum overprocurement and underprocument relative to redisaptch demand, load, peak,load
        return(r_pi)

    def redispatch_supply_demand_ratio(self):
        #volume mean supply/demand ratio per offer daytime
        demand_up =self.model.red_obook.redispatch_demand_upward_all_df.groupby(by=['delivery_day','delivery_time','delivery_location','offer_daytime']).sum()['volume']
        demand_down =self.model.red_obook.redispatch_demand_downward_all_df.groupby(by=['delivery_day','delivery_time','delivery_location','offer_daytime']).sum()['volume']
        supply_up =self.model.red_obook.sellorders_all_df.groupby(by=['delivery_day','delivery_time','delivery_location','offer_daytime']).sum()['volume']
        supply_down =self.model.red_obook.buyorders_all_df.groupby(by=['delivery_day','delivery_time','delivery_location','offer_daytime']).sum()['volume']


        demand_up =demand_up.to_frame().join(supply_up.to_frame(), lsuffix='_demand',rsuffix='_supply').copy()
        demand_down =demand_down.to_frame().join(supply_down.to_frame(), lsuffix='_demand',rsuffix='_supply').copy()
        demand_up['s_d_ratio'] =demand_up['volume_supply'].fillna(value=0).values/demand_up['volume_demand'].values
        demand_down['s_d_ratio'] =demand_down['volume_supply'].fillna(value=0).values/demand_down['volume_demand'].values
        r_pi=Series()
        r_pi['av_s_d_ratio_up'] = demand_up['s_d_ratio'].mean()
        r_pi['av_s_d_ratio_down'] = demand_down['s_d_ratio'].mean()
        return(r_pi)


    def interdependence_indicators(self, volume_indicator='sum'):

        """ Attention: this method works ponly correct if the market statistics are produced
            onece at the end of the simulation (and not every simulation step). Because
            else the weighted average is not correct.
            the average of all offered/cleared volumes in a step (nan's are ignored)
            gives more similar values for markets with bidding every round and markets
            with single or few bidding rounds. However results can be confusing, as
            e.g. average cleared volume might be larger than average offered volume.
            Total volume on the otherhand does not entail the 'averaging effects' ,
            but can also be confusing because large differences in trading periods
            and resulting large differences in offered volumes. For both indicators
            it is important to notice that cleared volumes influence the offered volume."""

        indicators= DataFrame(index =list(self.all_books.keys()), columns=[
        'vol_av_av_sell','vol_av_av_buy','vol_av_av_sell_cleared','vol_av_av_buy_cleared',
        'price_med_wav_sell','price_med_wav_buy','price_med_wav_sell_cleared','price_med_wav_buy_cleared',
        'return', 'return [%]'])

        for obook in self.all_books.keys():
            #calculate the average volumes offered per round, normed over all delivery periods
            if not self.all_books[obook].buyorders_all_df.empty:
                vol_buy= self.all_books[obook].buyorders_all_df.groupby(by=['delivery_day', 'delivery_time','offer_daytime'])['volume'].sum()
                indicators.loc[obook, 'vol_av_av_buy'] = (vol_buy.unstack(level=[0,1])).mean().mean()
                indicators.loc[obook, 'vol_total_buy_MWh'] = vol_buy.sum().sum()/4
            else:
                if obook =='RED':
                    indicators.loc[obook, 'vol_av_av_buy'] = self.all_books[obook].buy_sum_volume.groupby(level=[1,2]).sum().mean().mean()
                else:
                    indicators.loc[obook, 'vol_av_av_buy'] = self.all_books[obook].buy_sum_volume.mean().mean()
                indicators.loc[obook, 'vol_total_buy_MWh'] = self.all_books[obook].buy_sum_volume.sum().sum()/4
            if not self.all_books[obook].sellorders_all_df.empty:
                vol_sell= self.all_books[obook].sellorders_all_df.groupby(by=['delivery_day', 'delivery_time','offer_daytime'])['volume'].sum()
                indicators.loc[obook, 'vol_av_av_sell'] = (vol_sell.unstack(level=[0,1])).mean().mean()
                indicators.loc[obook, 'vol_total_sell_MWh'] =vol_sell.sum().sum()/4
            else:
                if obook =='RED':
                    indicators.loc[obook, 'vol_av_av_sell'] =self.all_books[obook].sell_sum_volume.groupby(level=[1,2]).sum().mean().mean()
                else:
                    indicators.loc[obook, 'vol_av_av_sell'] =self.all_books[obook].sell_sum_volume.mean().mean()
                indicators.loc[obook, 'vol_total_sell_MWh'] = self.all_books[obook].sell_sum_volume.sum().sum()/4
            if not self.all_books[obook].cleared_buyorders_all_df.empty:
                vol_buy_cleared= self.all_books[obook].cleared_buyorders_all_df.groupby(by=['delivery_day', 'delivery_time','offer_daytime'])['cleared_volume'].sum()
                indicators.loc[obook, 'vol_av_av_buy_cleared'] = (vol_buy_cleared.unstack(level=[0,1])).mean().mean()
                indicators.loc[obook, 'vol_total_buy_cleared_MWh'] =vol_buy_cleared.sum().sum()/4
            else:
                if obook =='RED':
                    indicators.loc[obook, 'vol_av_av_buy_cleared'] =self.all_books[obook].cleared_buy_sum_volume.groupby(level=[1,2]).sum().mean().mean()
                else:
                    indicators.loc[obook, 'vol_av_av_buy_cleared'] =self.all_books[obook].cleared_buy_sum_volume.mean().mean()
                indicators.loc[obook, 'vol_total_buy_cleared_MWh'] = self.all_books[obook].cleared_buy_sum_volume.sum().sum()/4
            if not self.all_books[obook].cleared_sellorders_all_df.empty:
                vol_sell_cleared=self.all_books[obook].cleared_sellorders_all_df.groupby(by=['delivery_day', 'delivery_time','offer_daytime'])['cleared_volume'].sum()
                indicators.loc[obook, 'vol_av_av_sell_cleared'] = (vol_sell_cleared.unstack(level=[0,1])).mean().mean()
                indicators.loc[obook, 'vol_total_sell_cleared_MWh'] =vol_sell_cleared.sum().sum()/4
            else:
                if obook =='RED':
                    indicators.loc[obook, 'vol_av_av_sell_cleared'] =self.all_books[obook].cleared_sell_sum_volume.groupby(level=[1,2]).sum().mean().mean()
                else:
                    indicators.loc[obook, 'vol_av_av_sell_cleared'] =self.all_books[obook].cleared_sell_sum_volume.mean().mean()
                indicators.loc[obook, 'vol_total_sell_cleared_MWh'] =self.all_books[obook].cleared_sell_sum_volume.sum().sum()/4

            #the total volumes are shown in MWh instead of MW (unlike the averages above)
#            indicators.loc[obook, 'vol_total_sell_MWh'] = self.all_books[obook].sell_sum_volume.sum().sum()/4
#            indicators.loc[obook, 'vol_total_buy_MWh'] = self.all_books[obook].buy_sum_volume.sum().sum()/4
#            indicators.loc[obook, 'vol_total_sell_cleared_MWh'] =self.all_books[obook].cleared_sell_sum_volume.sum().sum()/4
#            indicators.loc[obook, 'vol_total_buy_cleared_MWh'] = self.all_books[obook].cleared_buy_sum_volume.sum().sum()/4



            vol_sell=self.all_books[obook].sell_sum_volume
            vol_buy=self.all_books[obook].buy_sum_volume
            vol_sell_cleared=self.all_books[obook].cleared_sell_sum_volume
            vol_buy_cleared=self.all_books[obook].cleared_buy_sum_volume

            indicators.loc[obook, 'price_med_wav_sell'] = (self.all_books[obook].sell_wm_price * vol_sell/(
                    vol_sell.sum().T)).sum().median()
            indicators.loc[obook, 'price_med_wav_buy'] = (self.all_books[obook].buy_wm_price * vol_buy/(
                    vol_buy.sum().T)).sum().median()
            indicators.loc[obook, 'price_med_wav_sell_cleared'] = (self.all_books[obook].cleared_sell_wm_price * vol_sell_cleared/(
                    vol_sell_cleared.sum().T)).sum().median()
            indicators.loc[obook, 'price_med_wav_buy_cleared'] = (self.all_books[obook].cleared_buy_wm_price * vol_buy_cleared/(
                    vol_buy_cleared.sum().T)).sum().median()

            indicators.loc[obook,'price_med_wav_spread'] =  indicators.loc[obook,
                          'price_med_wav_sell_cleared'] - indicators.loc[obook, 'price_med_wav_buy_cleared']


        indicators['total_vol_cleared [%]'] =(indicators[['vol_total_sell_cleared_MWh',
                  'vol_total_buy_cleared_MWh']].sum(axis=1))/(
            indicators[['vol_total_sell_cleared_MWh','vol_total_buy_cleared_MWh']].sum().sum()) *100

        all_returns =DataFrame(index=['DA_return','ID_return','RD_return', 'BE_return','IB_return'])
        all_profit_loss =DataFrame(index=['total_dispatch_costs', 'profit'])

        for agent in self.model.schedule.agents:
            all_returns= pd.concat([all_returns,agent.financial_return[[
                     'DA_return','ID_return','RD_return', 'BE_return','IB_return']].sum()], axis=1)
            all_profit_loss=pd.concat([all_profit_loss,agent.financial_return[['total_dispatch_costs', 'profit']].sum()],axis=1)

        all_profit_loss=all_profit_loss.sum(axis=1)
        all_profit_loss['system_operations_cost'] = self.model.aTSO.financial_return['total_return'].sum()
        all_profit_loss.rename({'profit': 'market_profit', 'total_dispatch_costs':'total_dispatch_cost'}, inplace=True)
        all_profit_loss['cost_of_electricity'] =all_profit_loss['total_dispatch_cost'] + all_profit_loss[
                'system_operations_cost'] -all_profit_loss['market_profit']
        # DEPRECIATED 6-11-2019: the profit and loss is devided by the sum of the residual load
        # of the simulation period including the last schedule.
        #sum of the residual load is equal to vol_total_buy of DAM
#        all_profit_loss = all_profit_loss/indicators.loc['DAM','vol_total_buy_MWh']

        #profit and loss are normalized on the load corrected by import and export.
        #thus profit and loss per day-ahead net position MWh (i.e. zonal production obligation)
        divid = self.model.exodata.DA_residual_load.set_index(
                ['delivery_day','delivery_time']).loc[
                self.model.aTSO.financial_return.index,'load_DA_cor'].sum()/4

        all_profit_loss = all_profit_loss/divid


        all_returns=all_returns.abs().sum(axis=1)
        #to avoid double counting of IDM returns (sellers and buyers)
        all_returns['ID_return'] =all_returns['ID_return']/2
        if 'IDM' in indicators.index:
            indicators.loc['IDM', 'return'] = all_returns['ID_return']
        if 'DAM' in indicators.index:
            indicators.loc['DAM', 'return'] = all_returns['DA_return']
        if 'RED' in indicators.index:
            indicators.loc['RED', 'return'] = all_returns['RD_return']
        if 'BEM' in indicators.index:
            indicators.loc['BEM', 'return'] = all_returns['BE_return']
        indicators['return [%]'] =indicators['return']/indicators['return'].sum()*100
        return(indicators, all_profit_loss)











