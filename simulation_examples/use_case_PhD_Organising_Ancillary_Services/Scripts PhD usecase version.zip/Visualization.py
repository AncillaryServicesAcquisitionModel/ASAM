# -*- coding: utf-8 -*-
"""
Created on Fri Mar 16 12:25:08 2018
vizualization
@author: Otto
"""
import pandas as pd
from pandas import Series, DataFrame
import numpy as np
import os
import matplotlib.pyplot as plt
from datetime import datetime
from matplotlib.ticker import FuncFormatter, MaxNLocator
from MarketModel import *
from Asset import *

class Visualizations():
    def __init__(self, model):
        self.model = model
        self.dir = self.model.exodata.output_path
        self.sname = self.model.exodata.sim_name +'_'

    def step_stat_sellbuy(self, steps_lst=None, market=None, indicator=None):
        """ makes plots from offered or cleared orders during specific steps of the simulation"""

        if market == 'IDM':
            obook = self.model.IDM_obook
        elif market == 'RED':
            obook = self.model.red_obook
        else:
            raise Exception()

        if indicator == 'sum_volume':
            selldf = obook.sell_sum_volume
            buydf = obook.buy_sum_volume
            ylab = 'MW'
        elif indicator == 'min_price':
            selldf = obook.sell_min_price
            buydf =obook.buy_min_price
            ylab = 'EUR/MWh'
        elif indicator == 'wm_price':
            selldf =obook.sell_wm_price
            buydf =obook.buy_wm_price
            ylab = 'EUR/MWh'
        elif indicator == 'max_price':
            selldf =obook.sell_max_price
            buydf =obook.buy_max_price
            ylab = 'EUR/MWh'
        elif indicator == 'cleared_sum_volume':
            selldf =obook.cleared_sell_sum_volume
            buydf =obook.cleared_buy_sum_volume
            ylab = 'MW'
        elif indicator == 'cleared_min_price':
            selldf =obook.cleared_sell_min_price
            buydf =obook.cleared_buy_min_price
            ylab = 'EUR/MWh'
        elif indicator == 'cleared_wm_price':
            selldf =obook.cleared_sell_wm_price
            buydf =obook.cleared_buy_wm_price
            ylab = 'EUR/MWh'
        elif indicator == 'cleared_max_price':
            selldf =obook.cleared_sell_max_price
            buydf =obook.cleared_buy_max_price
            ylab = 'EUR/MWh'
        elif indicator == 'allredispatchvolumes':
            selldf = obook.sell_sum_volume
            buydf = obook.buy_sum_volume
            cselldf =obook.cleared_sell_sum_volume
            cbuydf =obook.cleared_buy_sum_volume
            dselldf = obook.redispatch_demand_upward
            dbuydf = obook.redispatch_demand_downward
            ylab = 'MW'

        else:
            raise Exception ('given step_stat indicator for visualization not known')
        if (selldf.empty) & (buydf.empty):
            print('dataframes given to visu.step_stat() are both empty')
        else:
            if market == 'IDM':
                subtitles= [market+str('_')+indicator+str('_sell_orders'),market+str('_')+indicator+str('_buy_orders')]
                #for equal y max label
                y_max =max(selldf.max().max(), buydf.max().max())+20
                y_min=min(selldf.min().min(), buydf.min().min())-20
                if (y_max>0)|(y_max<0):
                    y_max=y_max + 0.2*abs(y_max)
                else:
                    y_max=20
                if (y_min>0)|(y_min<0):
                    y_min=y_min - 0.2*abs(y_min)
                else:
                    y_min=-20
                fig = plt.figure(figsize=(7,7));
                i = 0
                for data in [selldf, buydf]:
                    ax = fig.add_subplot(2,1,i+1)
                    if i == 0:
                        direction = 'sell_orders' #used for filename
                    else:
                        direction = 'buy_orders'
                    k = 0
                    for k in range(len(steps_lst)):
                        #abwechselnd -- und -
                        if (k+1)%2==0:
                            linestyle = ["--","--"]
                        else:
                            linestyle = ["-","-"]
                        #get step row from matrix
                        labl = 'day-MTU {0}'.format(steps_lst[k])
                        df = data.loc[(steps_lst[k][0],steps_lst[k][1])]
                        df.plot(ax = ax,grid = True, style =linestyle, subplots = False,legend=False, label = labl)
        #                ax.step(df.index,df,where='pre', label=labl)
                        ax.legend(loc="best")
                        ax.set_title(subtitles[i])
                        ax.set_ylim(bottom=y_min, top = y_max)
                        ax.grid(b=True)
                        plt.ylabel(ylab)
                    i += 1
                fig.tight_layout()
    #            plt.show()
                stamp=str(datetime.now().replace(microsecond=0))
                stamp=stamp.replace('.','')
                stamp=stamp.replace(':','_')
                fig.savefig(self.dir+self.sname+market+indicator+' '+stamp+'.png')   # save the figure to file
                plt.close(fig)

            if (market == 'RED')&(indicator!='allredispatchvolumes'):
                print("plotting redispatch market statistics")
                #for equal y max label
                y_max =max(selldf.fillna(value=0).max().max(), buydf.fillna(value=0).max().max())+20
                y_min=min(selldf.fillna(value=0).min().min(), buydf.fillna(value=0).min().min())-20
                if (y_max>0)|(y_max<0):
                    y_max=ymax + 0.2*abs(y_max)
                else:
                    y_max=20
                if (y_min>0)|(y_min<0):
                    y_min=ymin - 0.2*abs(y_min)
                else:
                    y_min=-20
#                print(y_max)
#                print(y_min)
                i = 0
                for data in [selldf, buydf]:
                    fig = plt.figure(figsize=(10,10));
                    l=0
                    for l in range(len(self.model.gridareas)):
                        ax = fig.add_subplot(2,2,l+1)
                        subtitles= [self.model.gridareas[l]+str('_')+market+str('_')+str('upward')+str('_')+indicator,self.model.gridareas[l]+str('_')+market+str('_')+str('downward')+str('_')+indicator]
                        if i == 0:
                            direction = '_upward'#used for filename
                        else:
                            direction = '_downward'#used for filename
                        k = 0
                        for k in range(len(steps_lst)):
                            #abwechselnd -- und -
                            if (k+1)%2==0:
                                linestyle = ["--","--"]
                            else:
                                linestyle = ["-","-"]
                            #get step row from matrix
                            labl = 'day-MTU {0}'.format(steps_lst[k])
                            df = data.loc[(self.model.gridareas[l],steps_lst[k][0],steps_lst[k][1])]
                            if (indicator=='cleared_sum_volume')|(indicator=='sum_volume'):
                                df.fillna(value=0, inplace=True)
                            df.plot(ax = ax,grid = True, style =linestyle, subplots = False,legend=False, label = labl)
            #                ax.step(df.index,df,where='pre', label=labl)
                            ax.legend(loc="best")
                            ax.set_title(subtitles[i])
                            ax.set_ylim(bottom=y_min, top = y_max)
                            ax.grid(b=True)
                            plt.ylabel(ylab)
                    i += 1
                    fig.tight_layout()
        #            plt.show()
                    stamp=str(datetime.now().replace(microsecond=0))
                    stamp=stamp.replace('.','')
                    stamp=stamp.replace(':','_')
                    fig.savefig(self.dir+self.sname+market+indicator+direction+' '+stamp+'.png')   # save the figure to file
                    plt.close(fig)

            elif (market == 'RED')&(indicator=='allredispatchvolumes'):
                print("plotting redispatch market statistics")
                #for equal y max label
                y_max =max(selldf.fillna(value=0).max().max(), buydf.fillna(value=0).max().max(),
                           cselldf.fillna(value=0).max().max(), cbuydf.fillna(value=0).max().max()
                           , dselldf.fillna(value=0).max().max(),dbuydf.fillna(value=0).max().max())
                if (y_max>0)|(y_max<0):
                    y_max=y_max + 0.2*abs(y_max)
                else:
                    y_max=20
                y_min=min(selldf.fillna(value=0).min().min(), buydf.fillna(value=0).min().min(),
                          cselldf.fillna(value=0).min().min(), cbuydf.fillna(value=0).min().min(),
                          dselldf.fillna(value=0).min().min(),dbuydf.fillna(value=0).min().min())
                if (y_min>0)|(y_min<0):
                    y_min=y_min - 0.2*abs(y_min)
                else:
                    y_min=-20
                i = 0
                for data in [[selldf,dselldf,cselldf], [buydf,dbuydf, cbuydf]]:
                    fig = plt.figure(figsize=(10,10));
                    l=0
                    for l in range(len(self.model.gridareas)):
                        ax = fig.add_subplot(2,2,l+1)
                        subtitles= [self.model.gridareas[l]+str('_')+market+str('_')+str('upward'),self.model.gridareas[l]+str('_')+market+str('_')+str('downward')]
                        if i == 0:
                            direction = '_upward' #used for filename
                        else:
                            direction = '_downward'
                        k = 0
                        for k in range(len(steps_lst)):
                            #abwechselnd -- und -
                            if (k+1)%2==0:
                                linestyle = ["--","--"]
                            else:
                                linestyle = ["-","-"]
                            #get step row from matrix
                            labl = ['offered_redispatch {0}'.format(steps_lst[k]),
                                    'redispatch_demand {0}'.format(steps_lst[k]),
                                    'cleared_redispatch {0}'.format(steps_lst[k])]
                            df = data[0].loc[(self.model.gridareas[l],steps_lst[k][0],steps_lst[k][1])].fillna(value=0)
                            dfd = data[1].loc[(self.model.gridareas[l],steps_lst[k][0],steps_lst[k][1])].fillna(value=0)
                            dfc = data[2].loc[(self.model.gridareas[l],steps_lst[k][0],steps_lst[k][1])].fillna(value=0)
                            df.plot(ax = ax,drawstyle="steps-post", grid = True, style =linestyle, subplots = False,legend=False, label = labl[0])
                            dfd.plot(ax = ax,drawstyle="steps-post", grid = True, style =linestyle, subplots = False,legend=False, label = labl[1])
                            dfc.plot(ax = ax,drawstyle="steps-post", grid = True, style =linestyle, subplots = False,legend=False, label = labl[2])
                            if l==0:
                                ax.legend(loc="best")
                            ax.set_title(subtitles[i])
                            ax.set_ylim(bottom=y_min, top = y_max)
                            ax.grid(b=True)
                            plt.ylabel(ylab)
                    i += 1
                    fig.tight_layout()
        #            plt.show()
                    stamp=str(datetime.now().replace(microsecond=0))
                    stamp=stamp.replace('.','')
                    stamp=stamp.replace(':','_')
                    fig.savefig(self.dir+self.sname+market+indicator+direction+' '+stamp+'.png')   # save the figure to file
                    plt.close(fig)


    def show_asset_schedules(self):
        #get the right time for the graph
        day, MTU=   self.model.clock.calc_timestamp_by_steps(self.model.schedule.steps -1, 0)
        all_scheds ={}
        for agent in self.model.schedule.agents:
            for asset in agent.assets['object']:
                name = agent.unique_id + str('_') + asset.assetID
                all_scheds[name]=asset.schedule['commit']/asset.pmax*100

        fig = plt.figure(figsize=(7,5));
        ax = fig.add_subplot(1,1,1)
        i = 1
        key_lst=sorted(all_scheds.keys())
        for key in key_lst:
            #linestyle jumps from '-' to '--' with i jumping from 1 to -1
            linestyle = ["-",'-',"--"]
            df = all_scheds[key]
            titl = 'asset_schedules_at_timestamp Day_{0}_MTU_{1}'.format(day,MTU)
            df.plot(ax = ax,grid = True, style=linestyle[i], subplots = False,
                            rot=45,legend=False, title =titl,
                            label = key)
            i =i*(-1)

        ax.set_ylim(bottom=0, top = 100)
        # Shrink current axis by 30%
        box = ax.get_position()
        ax.set_position([box.x0, box.y0, box.width * 0.7, box.height])
        # Put a legend to the right of the current axis
        ax.legend(loc='center left', bbox_to_anchor=(1, 0.5))

        #place legend above figure
#        lines = ax.get_lines()
#        labels =[]
#        for l in lines:
#            labels.append(l.get_label())
#        fig.legend(lines, labels, loc = 7, ncol=1)
        plt.ylabel('% of Pmax')
#        fig.suptitle(titl)
#        fig.tight_layout()
#        plt.show()
        strFile ='results/'+titl+'.png'
#        if os.path.isfile(strFile):
#            os.remove(strFile)   # Opt.: os.system("rm "+strFile)
        fig.savefig(strFile)   # save the figure to file
        plt.close(fig)


    def show_agent_trade_positions(self, position=None):
        #todo: make order fixed to get same color per plot
        #get the right time for the graph
        day, MTU=   self.model.clock.calc_timestamp_by_steps(self.model.schedule.steps -1, 0)
        all_scheds ={}
        ymin=0
        ymax=0
        for agent in self.model.schedule.agents:
            all_scheds[agent.unique_id]=agent.trade_schedule

        fig = plt.figure(figsize=(7,5));
        ax = fig.add_subplot(1,1,1)
        i = 1
        key_lst=sorted(all_scheds.keys())
        for key in key_lst:
            #linestyle jumps from '-' to '--' with i jumping from 1 to -1
            linestyle = ["-",'-',"--"]
            df = all_scheds[key]
            titl = 'agent_{0}_at_timestamp Day_{1}_MTU_{2}'.format(position, day,MTU)
            df[position].plot(ax = ax,grid = True, style=linestyle[i], subplots = False,
                            rot=45,legend=False, title =titl,
                            label = key)
            i =i*(-1)

        # Shrink current axis by 30%
        box = ax.get_position()
        ax.set_position([box.x0, box.y0, box.width * 0.7, box.height])
        # Put a legend to the right of the current axis
        ax.legend(loc='center left', bbox_to_anchor=(1, 0.5))
        #place legend above figure
#        lines = ax.get_lines()
#        labels =[]
#        for l in lines:
#            labels.append(l.get_label())
#        fig.legend(lines, labels, loc = 7, ncol=1)
        plt.ylabel('MW')
#        fig.suptitle(titl)
#        fig.tight_layout()
#        plt.show()
        stamp=str(datetime.now().replace(microsecond=0))
        stamp=stamp.replace('.','')
        stamp=stamp.replace(':','_')
        fig.savefig(self.dir+self.sname+titl+' '+stamp+'.png')   # save the figure to file
        plt.close(fig)

    def show_trade_per_agent(self, only_agent =None):
        #get the right time for the graph
        day, MTU=   self.model.clock.calc_timestamp_by_steps(self.model.schedule.steps -1, 0)

        #stacked trade positions as areas and stacked disaptch as lines per agent
        all_scheds ={}
        ymin_ag =[]
        ymax_ag =[]
        if not only_agent:
            #all agents are plotted

            for agent in self.model.schedule.agents:
                all_scheds[agent.unique_id]=agent.trade_schedule.copy()/1000
                ymin_ag += [min(agent.trade_schedule.min().min()/1000, 0)]
                ymax_ag += [max(agent.trade_schedule.max().max()/1000, 0)]

        else:
            agent = self.model.MP_dict[only_agent]
            #only one agent is plotted
            all_scheds[agent.unique_id]=agent.trade_schedule.copy()/1000
            ymin_ag += [min(agent.trade_schedule.min().min()/1000, 0)]
            ymax_ag += [max(agent.trade_schedule.max().max()/1000, 0)]

        ymin = min(ymin_ag)
        ymax = max(ymax_ag)
        if (ymax != 0):
                    ymax=ymax + 0.1*abs(ymax)
        else:
            ymax=20
        if (ymin !=0 ):
            ymin=ymin - 0.1*abs(ymin)
        else:
            ymin=-20

        key_lst=sorted(all_scheds.keys())
        if len(key_lst) ==1:
            fwidth = 7
            fhight = 6
            number_rows = 1
            number_col = 1
        elif len(key_lst)< 5:
            fwidth = 8
            fhight = 8
            number_rows = 2
            number_col = 2
        else:
            fwidth = 10
            fhight = 11.5
            number_rows = round((len(key_lst)+len(key_lst)%4)/4)
            number_col = 4

        fig = plt.figure(figsize=(fwidth,fhight));
        suptitl='Trade positions at day {} MTU {}'.format(day,MTU)
        plt.suptitle(suptitl)
        for i in range(len(key_lst)):
            if i == 0:
                choice = True
            else:
                choice = False
            ax = fig.add_subplot(number_rows, number_col, i+1)
            df = all_scheds[key_lst[i]].copy()
            # Shrink current axis by 30%
            box = ax.get_position()
            ax.set_position([box.x0, box.y0, box.width, box.height])

            mask=df[['DA_position','ID_position','RD_position', 'forecast_error']]>=0
            df[['DAM_position','IDM_position','RED_position','forecast_error']]=df[['DA_position','ID_position','RD_position','forecast_error']].where(mask, np.nan)
            df[['DAM_neg','IDM_neg','RED_neg','neg_FE']]=df[['DA_position','ID_position','RD_position','forecast_error']].where(~mask, np.nan)

            titl = 'agent {0}'.format(key_lst[i])
            df[['DAM_position','IDM_position','RED_position','forecast_error']].plot.area(ax = ax,
#            df[['IDM_position','RED_position','forecast_error']].plot.area(ax = ax,
                            stacked=True, grid = True, subplots = False,
                            legend=False, title =titl, color=[
                                  'mediumaquamarine','cornflowerblue','mediumpurple','orange'])
#                                    'cornflowerblue','mediumpurple','orange'])
            df[['DAM_neg','IDM_neg','RED_neg','neg_FE']].plot.area(ax = ax,
#            df[['IDM_neg','RED_neg','neg_FE']].plot.area(ax = ax,
                            stacked=True, grid = True, subplots = False,
                            legend=False, title =titl, color=[
                                    'mediumaquamarine','cornflowerblue','mediumpurple','orange'])
#                                    'cornflowerblue','mediumpurple','orange'])
#            df[['total_trade','total_dispatch','imbalance_position']].plot(ax = ax,
            df[['total_trade','total_dispatch','imbalance_position']].plot(ax = ax,
                grid = True, subplots = False, style="--",
                legend=False, title =titl, color=['darkgreen','darkblue','red'])
            if choice==True:
                handels, labels =  ax.get_legend_handles_labels()
            ax.set_ylim(bottom=ymin, top = ymax)
            if (i >=12):
                plt.xlabel('delivery_day, delivery_MTU')
            else:
                plt.xlabel('')
            if (i %4==0):
                plt.ylabel('GW')

        if len(key_lst)>= 5:
            plt.subplots_adjust(top=0.89,
                                bottom=0.04,
                                left=0.09,
                                right=0.97,
                                hspace=0.29,
                                wspace=0.315)
            fig.legend(handels[:7],labels[:7],loc='center', bbox_to_anchor=(0.5, 0.935), ncol =4)


        elif len(key_lst)== 1:
            plt.subplots_adjust(top=0.8,
                                bottom=0.045,
                                left=0.115,
                                right=0.96,
                                hspace=0.29,
                                wspace=0.315)
            fig.legend(handels[:7],labels[:7],loc='center', bbox_to_anchor=(0.5, 0.90), ncol =4)

        else:
            plt.subplots_adjust(
                            top=0.86,
                            bottom=0.04,
                            left=0.09,
                            right=0.97,
                            hspace=0.29,
                            wspace=0.315)
            fig.legend(handels[:7],labels[:7],loc='center', bbox_to_anchor=(0.5, 0.925), ncol =4)


        stamp=str(datetime.now().replace(microsecond=0))
        stamp=stamp.replace('.','')
        stamp=stamp.replace(':','_')
        if only_agent:
            suptitl =suptitl +'_'+agent.unique_id
        fig.savefig(self.dir+self.sname+suptitl+' '+stamp+'.png')   # save the figure to file
        plt.close(fig)

    def show_dispatch_per_agent(self):
        #get the right time for the graph
        day, MTU=   self.model.clock.calc_timestamp_by_steps(self.model.schedule.steps -1, 0)

        def format_fn(tick_val, tick_pos):
            """local function to set ticks on x axes"""
            if int(tick_val) in xs:
                return labels[int(tick_val)]
            else:
                return ''
        #TODO: shared y
        asset_owners_set={}

        fig = plt.figure(figsize=(10,10));
        suptitl='Asset dispatch at day {} MTU {}'.format(day,MTU)
        plt.suptitle(suptitl)
        for agent in self.model.schedule.agents:
            all_scheds ={}
            for asset in agent.assets['object']:
                name =  asset.assetID
                all_scheds[name]=asset.schedule['commit']/asset.pmax*100
            asset_owners_set[agent.unique_id]=all_scheds.copy()
        key_lst=sorted(asset_owners_set.keys())
        for i in range(len(key_lst)):
            ax = fig.add_subplot(2,2,i+1)
            asset_lst=sorted(asset_owners_set[key_lst[i]].keys())
            for k in range(len(asset_lst)):
                df = asset_owners_set[key_lst[i]][asset_lst[k]]
                titl = 'Dispatch of agent {0}'.format(key_lst[i],day,MTU)
#                df.plot(ax = ax,grid = True, subplots = False,
#                        legend=True, title =titl,
#                                label = asset_lst[k])
                xs=range(len(df))
                labels = df.index.values

                ax.xaxis.set_major_formatter(FuncFormatter(format_fn))
#                ax.xaxis.set_major_locator(MaxNLocator(integer=True))
#                import pdb
#                pdb.set_trace()
                ax.plot(df.values, drawstyle ='steps-pre', label=asset_lst[k])
                plt.title(titl)
                ax.legend(loc="best")
                ax.grid(True)
                ax.set_ylim(bottom=0, top = 105)
                if (i ==2)|(i==3):
                    plt.xlabel('delivery_day, delivery_MTU')
                if (i ==0)|(i==2):
                    plt.ylabel('% of Pmax')

        stamp=str(datetime.now().replace(microsecond=0))
        stamp=stamp.replace('.','')
        stamp=stamp.replace(':','_')
        fig.savefig(self.dir+self.sname+suptitl+' '+stamp+'.png')   # save the figure to file
        plt.close(fig)
#        plt.show()



    def show_demand_supply_IDM(self, simulation_daytime, delivery_day, delivery_time):
        sellorders = pd.concat(self.model.IDM_obook.sellorders_per_round.values(),
                               keys= self.model.IDM_obook.sellorders_per_round.keys())
        buyorders= pd.concat(self.model.IDM_obook.buyorders_per_round.values(),
                             keys= self.model.IDM_obook.buyorders_per_round.keys())
        c_sellorders= pd.concat(self.model.IDM_obook.cleared_sellorders_per_round.values(),
                                keys= self.model.IDM_obook.cleared_sellorders_per_round.keys())
        c_buyorders = pd.concat(self.model.IDM_obook.cleared_buyorders_per_round.values(),
                                keys= self.model.IDM_obook.cleared_buyorders_per_round.keys())

        allsupply= sellorders.loc[(slice(simulation_daytime,simulation_daytime),slice(None))]
        supply = allsupply.loc[(allsupply['delivery_day']==delivery_day)&
                          (allsupply['delivery_time']==delivery_time)].sort_values('price').reset_index()[
                                  ['price', 'volume', 'direction']]
        supply['MW']=supply['volume'].cumsum()
        alldemand= buyorders.loc[(slice(simulation_daytime,simulation_daytime),slice(None))]
        demand = alldemand.loc[(alldemand['delivery_day']==delivery_day)&
                          (alldemand['delivery_time']==delivery_time)].sort_values('price', ascending=False).reset_index()[
                                  ['price', 'volume', 'direction']]
        demand['MW']=demand['volume'].cumsum()
        #make multicolumn dataframe from supply and demand
        demand_supply_df =pd.concat([demand,supply], axis=0).set_index('direction', append=True)
        demand_supply_df= demand_supply_df.unstack(1).swaplevel(0,1,1).sort_index(1)
        demand_supply_df.sort_index(axis=1, inplace=True)

        #make dataframe that can be plot
#        begin = demand_supply_df.loc[:,(slice(None),slice('MW','MW'))].min().min()-1
        end = demand_supply_df.loc[:,(slice(None),slice('MW','MW'))].max().max()+1
        print(end)
        x= np.linspace(0,end,end+1, endpoint=True)

        df= DataFrame(columns=['x','NaN','sell_price', 'buy_price'])
        df['x']=x
        df.set_index('x', inplace=True)
        df['sell_price']=demand_supply_df[[('sell','price'),('sell','MW')]].set_index([('sell','MW')])
        df['sell_price']=df['sell_price'].bfill()
        df['buy_price']=demand_supply_df[[('buy','price'),('buy','MW')]].set_index([('buy','MW')])
        df['buy_price']=df['buy_price'].bfill()
        plt.step(df['sell_price'],where='pre', label='sell_price')
        plt.step(df['buy_price'],where='pre', label='buy_price')
        titl='simulation datime {0}, delivery daytime ({1}, {2})'.format(simulation_daytime,delivery_day, delivery_time)
        plt.title(titl)
        plt.legend(loc="best")
        plt.grid(True)
        plt.xlabel('MW')
        plt.ylabel("Eur/MW")
        plt.tight_layout()
        stamp=str(datetime.now().replace(microsecond=0))
        stamp=stamp.replace('.','')
        stamp=stamp.replace(':','_')
        fig.savefig(self.dir+self.sname+'demand_supply_curve'+stamp+'.png')   # save the figure to file
        plt.close(fig)

    def show_system_balance(self):
        def format_fn(tick_val, tick_pos):
            """local function to set ticks on x axes"""
            if int(tick_val) in xs:
                return labels[int(tick_val)]
            else:
                return ''

        #get the right time for the graph
        day, MTU=   self.model.clock.calc_timestamp_by_steps(self.model.schedule.steps -1, 0)
        ymin=0
        ymax=0
        sell_labels = []
        buy_labels = []
        shown_labels = []
        #to enable plots with a subset of simulated markets, lables need to be selected
        if self.model.exodata.sim_task['run_DAM[y/n]'][0] =='y':
            sell_labels += ['DAM_sell']
            buy_labels += ['DAM_buy']
            shown_labels += ['DAM']
        if self.model.exodata.sim_task['run_IDM[y/n]'][0] =='y':
            sell_labels += ['IDM_sell']
            buy_labels += ['IDM_buy']
            shown_labels += ['IDM']
        if self.model.exodata.sim_task['run_RDM[y/n]'][0] =='y':
            sell_labels += ['RED_sell']
            buy_labels += ['RED_buy']
            shown_labels += ['RED']
        if self.model.exodata.sim_task['run_BEM[y/n]'][0] =='y':
            sell_labels += ['BEM_sell']
            buy_labels += ['BEM_buy']
            shown_labels += ['BEM']
        df = pd.concat([self.model.rpt.get_system_dispatch(),
                        self.model.aTSO.system_transactions.loc[:self.model.schedules_horizon.index[-1]],
                        self.model.aTSO.imbalances.loc[:self.model.schedules_horizon.index[-1]]], axis=1)


        #make sell negative accordint to convestion
        df[sell_labels]=-1*df[sell_labels]
        #for simple plotting (only one legend sell and buy)
        df[shown_labels]=df[sell_labels]

        ymin=min(df[sell_labels].sum(axis=1).min().min(),df['sum_dispatch'].min().min(), ymin)

        ymax=max(df[buy_labels].sum(axis=1).max().max(),df['sum_dispatch'].max().max(), ymax)

        if (ymax>0)|(ymax<0):
                    ymax=int(ymax + 0.1*abs(ymax))
        else:
            ymax=20
        if (ymin>0)|(ymin<0):
            ymin=int(ymin - 0.1*abs(ymin))
        else:
            ymin=-20
        fig = plt.figure(figsize=(8,5));
        ax = fig.add_subplot(1,1,1)

        # Shrink current axis by 30%
        box = ax.get_position()
        ax.set_position([box.x0, box.y0, box.width* 0.6, box.height])
        titl = 'System trade and dispatch at day {0},MTU {1}'.format(day, MTU)



        df[shown_labels].plot.area(ax=ax,
                            stacked=True, grid = True, subplots = False,
                            legend=True, title =titl, color=['mediumaquamarine','cornflowerblue','mediumpurple','orange'])

        df[buy_labels].plot.area(ax=ax, stacked=True,
                grid = True, subplots = False,
                legend=False, title =titl,color=['mediumaquamarine','cornflowerblue','mediumpurple','orange'])
        df[['sum_dispatch','imbalance_redispatch','imbalance_market(scheduled)','imbalance_market(realized)']].plot(
                ax=ax,color=['darkblue','darkviolet','orange','red'],stacked=False,
                grid = True, subplots = False,
                legend=True, title =titl, style="--")

        handels, labels = handles, labels = ax.get_legend_handles_labels()
#        import pdb
#        pdb.set_trace()
        plt.legend(handels[:8],labels[:8],loc='center left', bbox_to_anchor=(1.00, 0.5))

        ax.set_ylim(bottom=ymin, top = ymax)
        plt.ylabel('MW')
        plt.xlabel('delivery day, MTU')

#        plt.tight_layout()

        stamp=str(datetime.now().replace(microsecond=0))
        stamp=stamp.replace('.','')
        stamp=stamp.replace(':','_')
        fig.savefig(self.dir+self.sname+titl+' '+stamp+'.png')   # save the figure to file
        plt.close(fig)





    def show_return_per_agent(self, only_agent =None):
        #get the right time for the graph
        day, MTU=   self.model.clock.calc_timestamp_by_steps(self.model.schedule.steps -1, 0)
        #to enable plots with a subset of simulated markets, lables need to be selected
        sell_labels = []
        buy_labels = []
        shown_labels = []
        #to enable plots with a subset of simulated markets, lables need to be selected
        if self.model.exodata.sim_task['run_IDM[y/n]'][0] =='y':
            sell_labels += ['DAM_sell']
            buy_labels += ['DAM_buy']
            shown_labels += ['DAM_return']
        if self.model.exodata.sim_task['run_IDM[y/n]'][0] =='y':
            sell_labels += ['IDM_sell']
            buy_labels += ['IDM_buy']
            shown_labels += ['IDM_return']
        if self.model.exodata.sim_task['run_RDM[y/n]'][0] =='y':
            sell_labels += ['RED_sell']
            buy_labels += ['RED_buy']
            shown_labels += ['RED_return']
        if self.model.exodata.sim_task['run_BEM[y/n]'][0] =='y':
            sell_labels += ['BEM_sell']
            buy_labels += ['BEM_buy']
            shown_labels += ['BEM_return']

         #stacked trade positions as areas and stacked disaptch as lines per agent
        all_scheds ={}
        ymin_ag =[]
        ymax_ag =[]
        if not only_agent:
            #all agents are plotted

            for agent in self.model.schedule.agents:
                all_scheds[agent.unique_id]=agent.financial_return.copy()/1000
                ymin_ag += [min(agent.financial_return.min().min()/1000, 0)]
                ymax_ag += [max(agent.financial_return.max().max()/1000, 0)]

        else:
            agent = self.model.MP_dict[only_agent]
            #only one agent is plotted
            all_scheds[agent.unique_id]=agent.financial_return.copy()/1000
            ymin_ag += [min(agent.financial_return.min().min()/1000, 0)]
            ymax_ag += [max(agent.financial_return.max().max()/1000, 0)]

        ymin = min(ymin_ag)
        ymax = max(ymax_ag)
        if (ymax != 0):
                    ymax=ymax + 0.1*abs(ymax)
        else:
            ymax=20
        if (ymin !=0 ):
            ymin=ymin - 0.1*abs(ymin)
        else:
            ymin=-20

        key_lst=sorted(all_scheds.keys())
        if len(key_lst) ==1:
            fwidth = 7
            fhight = 6
            number_rows = 1
            number_col = 1
        elif len(key_lst)< 5:
            fwidth = 8
            fhight = 8
            number_rows = 2
            number_col = 2
        else:
            fwidth = 10
            fhight = 11.5
            number_rows = round((len(key_lst)+len(key_lst)%4)/4)
            number_col = 4


        fig = plt.figure(figsize=(fwidth,fhight));
        suptitl='Financial returns at day {} MTU {}'.format(day,MTU)
        plt.suptitle(suptitl)
        for i in range(len(key_lst)):
            if i == 0:
                choice = True
            else:
                choice = False
            ax = fig.add_subplot(number_rows,number_col,i+1)
            df = all_scheds[key_lst[i]]
            mask=df[['DA_return','ID_return','RD_return', 'IB_return']]>=0
            df[['DAM_return','IDM_return','RED_return','IBM_return']] = df[['DA_return','ID_return','RD_return', 'IB_return']].where(mask, np.nan)
#            import pdb
#            pdb.set_trace()
            df[['DAM_neg','IDM_neg','RED_neg', 'IBM_neg']] = df[['DA_return','ID_return','RD_return','IB_return']].where(~mask, np.nan)

            titl = 'agent {0}'.format(key_lst[i])

            df[['DAM_return','IDM_return','RED_return', 'IBM_return']].plot.area(ax = ax,
                            stacked=True, grid = True, subplots = False,
                            legend=False, title =titl, color=[
                                    'mediumaquamarine','cornflowerblue','mediumpurple', 'orange'])
            df[['DAM_neg','IDM_neg','RED_neg', 'IBM_neg']].plot.area( ax = ax,
                            stacked=True, grid = True, subplots = False,
                            legend=False, title =titl, color=[
                                    'mediumaquamarine','cornflowerblue','mediumpurple','orange'])
            df[['total_return','total_dispatch_costs', 'profit']].plot( ax = ax,
                grid = True, subplots = False, style=["--", "--",'--'],
                legend=False, title =titl, color=['darkgreen','darkblue','red'])
            ax.set_ylim(bottom=ymin, top = ymax)
            if choice==True:
                handels, labels =  ax.get_legend_handles_labels()
            ax.set_ylim(bottom=ymin, top = ymax)
            if (i >=12):
                plt.xlabel('delivery_day, delivery_MTU')
            else:
                plt.xlabel('')
            if (i %4==0):
                plt.ylabel('thousand EUR')

        if len(key_lst)>= 5:
            plt.subplots_adjust(top=0.89,
                                bottom=0.04,
                                left=0.09,
                                right=0.97,
                                hspace=0.29,
                                wspace=0.315)
            fig.legend(handels[:7],labels[:7],loc='center', bbox_to_anchor=(0.5, 0.935), ncol =4)


        elif len(key_lst)== 1:
            plt.subplots_adjust(top=0.8,
                                bottom=0.045,
                                left=0.115,
                                right=0.96,
                                hspace=0.29,
                                wspace=0.315)
            fig.legend(handels[:7],labels[:7],loc='center', bbox_to_anchor=(0.5, 0.90), ncol =4)

        else:
            plt.subplots_adjust(
                            top=0.86,
                            bottom=0.04,
                            left=0.09,
                            right=0.97,
                            hspace=0.29,
                            wspace=0.315)
            fig.legend(handels[:7],labels[:7],loc='center', bbox_to_anchor=(0.5, 0.925), ncol =4)


        stamp=str(datetime.now().replace(microsecond=0))
        stamp=stamp.replace('.','')
        stamp=stamp.replace(':','_')
        if only_agent:
            suptitl =suptitl +'_'+agent.unique_id
        fig.savefig(self.dir+self.sname+suptitl+' '+stamp+'.png')   # save the figure to file
        plt.close(fig)

    def show_system_cost(self, mode = 'perMWh'):
        """ not yet done"""
        if mode == 'absolute':
            df = self.model.rpt.get_system_cost()
#        elif mode == 'perMWh':
#            pass auf mit teilen durch 0
#            df = pd.concat([self.model.rpt.get_system_cost(),
#                            self.model.rpt.get_system_dispatch(),
#                            self.model.rpt.get_system_trade()], axis=1)
#            df['dispatch_cost_per_MWh'] = df['sum_dispatch_cost']/df['sum_dispatch']*4
#            df['return_per_MWh'] = -df['sum_return']/df['sum_trades']*4


        import pdb
        pdb.set_trace()
        #get the right time for the graph
        day, MTU=   self.model.clock.calc_timestamp_by_steps(self.model.schedule.steps -1, 0)
        fig = plt.figure(figsize=(7,7));
        ax = fig.add_subplot(1,1,1)
#        suptitl='Trade positions at day {} MTU {}'.format(day,MTU)
#        plt.suptitle(suptitl)
        titl = 'System cost and producer surplus {0},MTU {1}'.format(day, MTU)


        df.plot(color=['darkgreen','darkblue','red'],stacked=False,
                grid = True, subplots = False,
                legend=True, title =titl, style="--")
        ax.set_ylim(bottom=ymin, top = ymax)
        plt.ylabel('EUR')
        plt.xlabel('delivery day, MTU')
        plt.tight_layout()
        plt.show()
        stamp=str(datetime.now().replace(microsecond=0))
        stamp=stamp.replace('.','')
        stamp=stamp.replace(':','_')
        fig.savefig(self.dir+self.sname+titl+stamp+'.png')   # save the figure to file
        plt.close(fig)


    def show_redispatch_PI(self, df=None):
        def format_fn(tick_val, tick_pos):
            """local function to set ticks on x axes"""
            if int(tick_val) in xs:
                return labels[int(tick_val)]
            else:
                return ''

        #get the right time for the graph
        day, MTU=   self.model.clock.calc_timestamp_by_steps(self.model.schedule.steps -1, 0)
        fig = plt.figure(figsize=(7,7));
        ax = fig.add_subplot(1,1,1)

        titl = 'Redispatch Performance Indicators at day {0},MTU {1}'.format(day, MTU)

        df = self.model.rpt.redispatch_PI()[['residual_demand_downwards','residual_demand_upwards',
                                 'imbalance_redispatch']]

        xs=range(len(df))
        labels = df.index.values
        ax.xaxis.set_major_formatter(FuncFormatter(format_fn))

        lineObjects=ax.plot(df.values, drawstyle ='steps-pre', ls='--')

        colors =['darkorange', 'darkred','darkviolet']
        for i in range(len(lineObjects)):
            lineObjects[i].set_color(colors[i])

        # Shrink current axis by 30%
        box = ax.get_position()
        ax.set_position([box.x0, box.y0*(1.6), box.width, box.height])
        ax.grid(True)
        plt.legend(lineObjects, ['residual_demand_downwards','residual_demand_upwards',
                                 'imbalance_redispatch'],loc='center left',
            bbox_to_anchor=(0, -0.15),fancybox=True, shadow=False)

        plt.ylabel('MW')
        plt.xlabel('delivery day, MTU')
        stamp=str(datetime.now().replace(microsecond=0))
        stamp=stamp.replace('.','')
        stamp=stamp.replace(':','')
        fig.savefig(self.dir+self.sname+titl+' '+stamp+'.png')   # save the figure to file
        plt.close(fig)


    def test_plot_available_volume(self, avalable_volume, direction, asset):
        """to be executed in the market party method 'make ID orders.
        self.model.visu.test_plot_available_volume(av_volume, 'upward', a.assetID)
        you need to temporary return also the available_vol dataframe from random volum method"""
        #get the right time for the graph
        day, MTU=   self.model.clock.calc_timestamp_by_steps(self.model.schedule.steps, 0)
        titl = 'Available volume {0} asset {1} at day {2}, MTU {3}'.format(direction, asset, day, MTU)
        fig = plt.figure(figsize=(7,7));
        ax = fig.add_subplot(1,1,1)
        avalable_volume.iloc[:,0].plot( ax=ax, grid=True, legend=True, title =titl)
        avalable_volume[['min_vol','max_vol','rand_vol']].plot(x=avalable_volume.index, ax=ax, style='--', grid=True, legend=True, title =titl)
        fig.savefig('results/'+titl+'.png')   # save the figure to file
        plt.close(fig)

    def show_cleared_prices(self):
        def format_fn(tick_val, tick_pos):
            """local function to set ticks on x axes"""
            if int(tick_val) in xs:
                return labels[int(tick_val)]
            else:
                return ''
        #make weighted averages over all simulation steps
        vol_red_up=self.model.red_obook.cleared_sell_sum_volume
        wm_red_up=(self.model.red_obook.cleared_sell_wm_price * vol_red_up/(vol_red_up.sum().T)).sum()

        vol_red_down=self.model.red_obook.cleared_buy_sum_volume
        wm_red_down=(self.model.red_obook.cleared_buy_wm_price * vol_red_down/(vol_red_down.sum().T)).sum()

        vol_IDM = self.model.IDM_obook.cleared_sell_sum_volume
        wm_IDM=(self.model.IDM_obook.cleared_sell_wm_price * vol_IDM/(vol_IDM.sum().T)).sum()
#        wm_IDM= self.model.IDM_obook.cleared_sell_wm_price.mean()
#        #vol_IDM=model.IDM_obook.cleared_sell_sum_volume
#        wm_red_up=self.model.red_obook.cleared_sell_wm_price.mean()
#        wm_red_down=self.model.red_obook.cleared_buy_wm_price.mean()
        wm_red_spread =wm_red_up-wm_red_down
        #vol_red=model.red_obook.cleared_sell_sum_volume
        DAP = self.model.rpt.DAM_prices
        IBP = self.model.rpt.IBM_prices


        fig = plt.figure(figsize=(7,5));
        ax = fig.add_subplot(1,1,1)
        xs=range(len(wm_IDM))
        labels = wm_IDM.index.values
        ax.xaxis.set_major_formatter(FuncFormatter(format_fn))

        ax.plot(wm_IDM.values, drawstyle ='steps-pre', label='IDM_weighted_mean')
        #ax.plot(wm_red_up.values, drawstyle ='steps-pre', label='RDM_up_weighted_mean')
        #ax.plot(wm_red_down.values, drawstyle ='steps-pre', label='RDM_down_weighted_mean')
        ax.plot(wm_red_spread.values, drawstyle ='steps-pre', label='RDM_weighted_mean')
        ax.plot(DAP.values, drawstyle ='steps-pre', label='DAM')
        ax.plot(IBP['IBP_short'].values, drawstyle ='steps-pre', label='IBP_short')
        ax.plot(IBP['IBP_long'].values, drawstyle ='steps-pre', label='IBP_long')

        # Shrink current axis by 30%
        box = ax.get_position()
        ax.set_position([box.x0, box.y0, box.width * 0.7, box.height])
        # Put a legend to the right of the current axis
        ax.legend(loc='center left', bbox_to_anchor=(1, 0.5))
        ax.grid(True)
        plt.ylabel('EUR/MWh')
        plt.xlabel('delivery day, MTU')
        plt.title('Cleared prices')

        stamp=str(datetime.now().replace(microsecond=0))
        stamp=stamp.replace('.','')
        stamp=stamp.replace(':','_')
        fig.savefig(self.dir+self.sname+'Cleared prices_'+stamp+'.png')   # save the figure to file
        plt.close(fig)

    def show_trade_per_agent_depreciated(self):
        #get the right time for the graph
        day, MTU=   self.model.clock.calc_timestamp_by_steps(self.model.schedule.steps -1, 0)
        #stacked trade positions as areas and stacked disaptch as lines per agent
        all_scheds ={}
        ymin_ag =[]
        ymax_ag =[]
        for agent in self.model.schedule.agents:
            all_scheds[agent.unique_id]=agent.trade_schedule.copy()
            ymin_ag += [min(agent.trade_schedule.min().min(), 0)]
            ymax_ag += [max(agent.trade_schedule.max().max(), 0)]
        ymin = min(ymin_ag)
        ymax = max(ymax_ag)
        if (ymax != 0):
                    ymax=ymax + 0.1*abs(ymax)
        else:
            ymax=20
        if (ymin !=0 ):
            ymin=ymin - 0.1*abs(ymin)
        else:
            ymin=-20

        fig = plt.figure(figsize=(10,8));

        suptitl='Trade positions at day {} MTU {}'.format(day,MTU)
        plt.suptitle(suptitl)
        i = 0
        key_lst=sorted(all_scheds.keys())

        number_rows = (len(key_lst)+len(key_lst)%3)/3

        for i in range(len(key_lst)):
            if i == 0:
                choice = True
            else:
                choice = False
            ax = fig.add_subplot(2,number_rows,i+1)
            df = all_scheds[key_lst[i]].copy()
            # Shrink current axis by 30%
            box = ax.get_position()
            ax.set_position([box.x0* 0.8, box.y0, box.width* 0.75, box.height])

            mask=df[['DA_position','ID_position','RD_position', 'forecast_error']]>=0
            df[['DAM_position','IDM_position','RED_position','forecast_error']]=df[['DA_position','ID_position','RD_position','forecast_error']].where(mask, np.nan)
            df[['DAM_neg','IDM_neg','RED_neg','neg_FE']]=df[['DA_position','ID_position','RD_position','forecast_error']].where(~mask, np.nan)

            titl = 'Trade position of agent {0}'.format(key_lst[i])
            df[['DAM_position','IDM_position','RED_position','forecast_error']].plot.area(ax = ax,
                            stacked=True, grid = True, subplots = False,
                            legend=False, title =titl, color=[
                                    'mediumaquamarine','cornflowerblue','mediumpurple','orange'])
            df[['DAM_neg','IDM_neg','RED_neg','neg_FE']].plot.area(ax = ax,
                            stacked=True, grid = True, subplots = False,
                            legend=False, title =titl, color=[
                                    'mediumaquamarine','cornflowerblue','mediumpurple','orange'])
            df[['total_trade','total_dispatch','imbalance_position']].plot(ax = ax,
                grid = True, subplots = False, style="--",
                legend=False, title =titl, color=['darkgreen','darkblue','red'])
            if choice==True:
                handels, labels =  ax.get_legend_handles_labels()
            ax.set_ylim(bottom=ymin, top = ymax)
            if (i ==2)|(i==3):
                plt.xlabel('delivery_day, delivery_MTU')
            if (i ==0)|(i==2):
                plt.ylabel('MW')
        fig.legend(handels[:7],labels[:7],loc='center left', bbox_to_anchor=(0.7, 0.7))
        stamp=str(datetime.now().replace(microsecond=0))
        stamp=stamp.replace('.','')
        stamp=stamp.replace(':','_')
        fig.savefig(self.dir+self.sname+suptitl+stamp+'.png')   # save the figure to file
        plt.close(fig)


