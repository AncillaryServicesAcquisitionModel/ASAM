# -*- coding: utf-8 -*-
"""
Created on Sat Aug 12 17:29:25 2017

@author: Otto

Note init_time attribute is not the actual time of the model run, but the rank number in
which the agents took steps. these rank is random (random scheduler). However important
to prioritise orders with same price

order type: full_flex means that the volume can be partially cleared, while the rest stays in the order book.
Order type: All-or-none means that the order can only be matched entirely or not
Order type: market order means that it is fill-and-kill order where as much as possible is cleared, but no rest stays in the order book.
"""
import pandas as pd
from pandas import Series, DataFrame
import numpy as np


class Order():

    def __init__(self, agentID, assetname, area, volume, price, deliveryday, deliverytime, order_type, init_time, orderID, direction, delivery_duration):
        #TODO start delivery period and product lenght implementation to make the class more generic (or from to)
        #no type test on agentID because might be int or string
        self.agentID = agentID

        if (isinstance(assetname, str)):
            self.assetname = assetname
        else:
            raise Exception("Order() argument 'assetname' must be string")

        if (isinstance(area, str)):
            self.area = area
        else:
            raise Exception("Order() argument 'area' must be string")

        if (isinstance(volume, int))|(isinstance(volume, np.int32)):
            self.volume = volume
        else:
            raise Exception("Order() argument 'volume' must be int")

        #TODO:reconsider the need for float. i could also handle integer cents
        if (isinstance(price, int))|(np.isnan(price)):
            #currently implicitly implemented as EUR/MWh.
            #nan is OK voor TSO orders
            self.price = price
        else:
            raise Exception("Order() argument 'price' must be int")

        if (isinstance(deliveryday, int))|(isinstance(deliveryday, np.int32)):
            self.deliveryday = deliveryday
        else:
            raise Exception("Order() argument 'deliveryday' must be int")

        if (isinstance(deliverytime, int))|(isinstance(deliverytime, np.int32)):
            self.deliverytime = deliverytime
        else:
            raise Exception("Order() argument 'deliveryhour' must be int")

        if isinstance(init_time, int):
            self.init_time = init_time
        else:
            raise Exception("Order() argument 'init_prio' must be int")

        if isinstance(order_type, str):
            self.order_type = order_type
        else:
            raise Exception("Order() argument 'order_type' must be string")

        if isinstance(orderID, str):
            self.orderID = orderID
        else:
            raise Exception("Order() argument 'orderID' must be string")
        if isinstance(direction, str):
            self.direction = direction
        else:
            raise Exception("Order() argument 'direction' must be string (buy or sell)")

    def get_as_list (self):
        lst = [self.agentID,self.assetname,self.area,self.volume, self.price,self.deliveryday,self.deliverytime, self.order_type, self.init_time, self.orderID, self.direction]
        return (lst)







