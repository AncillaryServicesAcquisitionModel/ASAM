# -*- coding: utf-8 -*-
"""
Created on Sun Sep  3 15:24:23 2017

@author: Otto
"""
#delete all variables in case you want to run main several times
#get_ipython().magic('reset -sf')


import pandas as pd
from pandas import Series, DataFrame
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime
from MarketModel import *
from Asset import *
from Visualization import *
import cProfile
import mesa
from IPython import get_ipython
import os


pd.options.mode.chained_assignment = None  # default='warn'
def read_input_data(path,input_data):
#    path=''

    #prepare parameters for model
    print('read exogenious data')

    #model compatible with pandas 0.19.1 and
    if pd.__version__ == '0.24.2':
        # from excel all taps in a dictionary
        simulation_parameters =pd.read_excel(path+input_data, sheet_name=None)
        simulation_parameters['da_residual_load'] = pd.read_excel(path+input_data, sheet_name='da_residual_load', header =[0,1])
        simulation_parameters['market_rules']=simulation_parameters['market_rules'].set_index('Unnamed: 0')
    elif pd.__version__ == '0.19.1':
        simulation_parameters =pd.read_excel(path+input_data, sheetname=None)
        simulation_parameters['da_residual_load'] = pd.read_excel(path+input_data, sheetname='da_residual_load', header =[0,1])



#    #get IBP kde pdfs from hdf5 file
    IBP_kde_pdfs = pd.read_hdf(path+'IBP_pdf_kernels_20190930.h5', 'IBP_pdf_kernels')
    #add dataframe from pickl to dictionary
    simulation_parameters['IBP_kde_pdfs'] = IBP_kde_pdfs
    return (simulation_parameters)
#
if os.path.isdir(r'results/'):
    rdir=r'results/'
    idir=r''
elif os.path.isdir(r'/home/sam/outputdata/'):
    rdir=r'/home/sam/outputdata/'
    idir=r'/home/sam/scripts/'
##
##
# NOTE: add hier the input file name
iname = "Input_first_scenarios_full_IDCONS.xlsx"

##
##
##
simulation_parameters = read_input_data(idir, iname)
#
simulation_parameters['output_path'] = rdir
######
##run various rounds
simulation_start_time = datetime.now().replace(microsecond=0)
####
sim_task = simulation_parameters['simulation_task']
####
model = MarketModel(simulation_parameters, seed = sim_task['seed'].iloc[0])
####
for i in range(sim_task['number_steps'].iloc[0]):
    model.step()
####
simulation_end_time = datetime.now().replace(microsecond=0)
simulation_run_time = simulation_end_time - simulation_start_time

print(">>>>>>>>>>>>>>>>>>END>>>>>>>>>>>>>>>>>>>>>>>>>>>")
print("results")

##
rep = Reports(model,['North','South'])
try:
    aaa=rep.redispatch_PI()
except:
    aaa=DataFrame()
##aaaa=rep.get_system_trade()
vizzu = Visualizations(model)
vizzu.show_redispatch_PI(df=aaa)
vizzu.show_cleared_prices()
#vizzu.show_redispatch_demand()
#vizzu.show_system_cost(mode='perMWh')
vizzu.show_system_balance()
vizzu.show_trade_per_agent()
vizzu.show_return_per_agent()
for agent in model.schedule.agents:
    vizzu.show_trade_per_agent(only_agent=agent.unique_id)
    vizzu.show_return_per_agent(only_agent=agent.unique_id)
#rep.save_market_stats(mode='at_end')
#
#simulation_daytime = '(2, 56)'
#delivery_day =3
#delivery_time=61
#vizzu.demand_supply_IDM(simulation_daytime, delivery_day, delivery_time)
#
#vizzu.show_dispatch_per_agent()

#vizzu.show_agent_trade_positions(position='ID_position')
#vizzu.show_return_per_agent()


##
#timestamps = [(1, 1),(2, 72),(3, 72),(4, 72),model.clock.report_time_matrix.index[-1]]
#timestamps = [model.clock.report_time_matrix.index[-1]]
#timestamps = [(2, 48),(2, 49),(2, 50)]
#timestamps = [(2, 48),(2, 49),(2, 50)]
#print(timestamps)
#indicators=['sum_volume',
#            'min_price',
#            'wm_price',
#            'max_price',
#            'cleared_sum_volume',
#            'cleared_min_price',
#            'cleared_wm_price',
#            'cleared_max_price',
#             'allredispatchvolumes'
#             ]
#indicators=['allredispatchvolumes']
#for i in range(len(timestamps)):
#    vizzu.step_stat_sellbuy(steps_lst=[timestamps[i]], market ='RED',  indicator='allredispatchvolumes')
#indicators=['sum_volume','cleared_sum_volume']
#for i in range(len(indicators)):
#    vizzu.step_stat_sellbuy(steps_lst=timestamps, market = 'IDM', indicator=indicators[i])
#    vizzu.step_stat_sellbuy(steps_lst=timestamps, market ='RED',  indicator=indicators[i])
##
#vizzu.show_trade_per_agent()


#timestamps = [(2, 47),(2, 48),(2, 49),(2, 50),(2, 51)]
#
#
#show_demand_supply_IDM(simulation_daytime, delivery_day, delivery_time)


#get results of reporters as DataFrame
agentdf = model.dc.get_agent_vars_dataframe()
modeldf = model.dc.get_model_vars_dataframe()

agentdf= agentdf.unstack(1)
agentdf.sort_index(axis=1, inplace=True)


simulation_task= model.rpt.rep_sim_task()
simulation_task['sim_start_time'] = simulation_start_time
simulation_task['sim_end_time'] = simulation_end_time
simulation_task['sim_run_time'] = str(simulation_run_time)
simname=simulation_task.loc[0,'simulation_name']+'_'
assetsdf = model.rpt.rep_portfolio()
congestionsdf = model.rpt.rep_congestions()
agent_strategiesdf = model.rpt.rep_agent_strategies()
market_rulesdf = model.rpt.rep_market_rules()
forecast_errorsdf = model.rpt.rep_forecast_errors()


###excel writing


stamp= str(datetime.now().replace(microsecond=0))
stamp=stamp.replace('.','')
stamp=stamp.replace(':','_')
writer = pd.ExcelWriter(rdir+'ModelResults'+simname+stamp+'.xlsx', engine='xlsxwriter')
simulation_task.to_excel(writer, sheet_name = 'simulation_input')
startrow = len(simulation_task)+2
market_rulesdf.to_excel(writer, sheet_name = 'simulation_input', startrow=startrow)
startrow += len(market_rulesdf)+2
assetsdf.to_excel(writer, sheet_name = 'simulation_input', startrow=startrow)
startrow += len(assetsdf)+2
congestionsdf.to_excel(writer, sheet_name = 'simulation_input', startrow=startrow)
startrow += len(congestionsdf)+2



indicators, allprofitloss =rep.interdependence_indicators()
indicators.to_excel(writer,sheet_name = 'interdependence_indicators')

#redispatch key figures
keyfigures = Series()
keyfigures= keyfigures.append(model.aTSO.system_transactions.sum()/4)
keyfigures= keyfigures.append(model.aTSO.imbalances.sum()/4)
#change index value for plotting purposes label
keyfigures['imbalance_market'] = keyfigures['imbalance_market(scheduled)']
keyfigures.drop('imbalance_market(scheduled)', inplace=True)
keyfigures= keyfigures.append(model.aTSO.financial_return.sum())
keyfigures= keyfigures.append(model.rpt.redispatch_PI().sum()/4)
keyfigures= keyfigures.append(rep.redispatch_supply_demand_ratio())
keyfigures= keyfigures.append(allprofitloss)
#remove duplicates
keyfigures=keyfigures.groupby(keyfigures.index).first()
keyfigures.to_frame().to_excel(writer, sheet_name ='key_figures')

model.rpt.redispatch_PI().to_excel(writer, sheet_name = 'performance_indicators')



#modeldf.to_excel(writer, sheet_name = 'ModelResults')
agentdf.to_excel(writer, sheet_name = 'AgentResults')


#market stats
#try:
#    for k in model.IDM_obook.rep_dict.keys():
#        table = model.IDM_obook.rep_dict[k]
#        table.to_excel(writer, sheet_name = 'IDM_'+k)
#except AttributeError:
#    pass
#try:
#    for k in model.red_obook.rep_dict.keys():
#        table = model.red_obook.rep_dict[k]
#        table.to_excel(writer, sheet_name = 'RED_'+k)
#except AttributeError:
#    pass
#try:
#
#    table = model.DAM_obook.rep_dict['cleared_sell_sum_volume']
#    table.to_excel(writer, sheet_name = 'DAM_cleared_sell_sum_volume')
#    table = model.DAM_obook.rep_dict['cleared_buy_sum_volume']
#    table.to_excel(writer, sheet_name = 'DAM_cleared_buy_sum_volume')
#except AttributeError:
#    pass
#try:
#    for k in model.BEM_obook.rep_dict.keys():
#        table = model.BEM_obook.rep_dict[k]
#        table.to_excel(writer, sheet_name = 'BEM_'+k)
#except AttributeError:
#    pass


#all order collection per round (only if rpt.save_all_orders_per_round is applied)
all_collections=[]
collection_names=[]
#if sim_task['run_IDM[y/n]'][0] =='y':
#    all_collections += [model.IDM_obook.sellorders_per_round,
#                  model.IDM_obook.buyorders_per_round,
#                  model.IDM_obook.cleared_sellorders_per_round,
#                  model.IDM_obook.cleared_buyorders_per_round]
#    collection_names +=['IDsellorders','IDbuyorders','IDc_sellorders','IDc_buyorders']
#
#if sim_task['run_RDM[y/n]'][0] =='y':
#    all_collections += [model.red_obook.sellorders_per_round,
#                  model.red_obook.buyorders_per_round,
#                  model.red_obook.cleared_sellorders_per_round,
#                  model.red_obook.cleared_buyorders_per_round]
#    collection_names += ['REDsellorders','REDbuyorders','REDc_sellorders','REDc_buyorders']
#
#
#if sim_task['run_DAM[y/n]'][0] =='y':
#    all_collections += [model.DAM_obook.cleared_sellorders_per_round,
#                      model.DAM_obook.cleared_buyorders_per_round]
#    collection_names +=['DAc_sellorders','DAc_buyorders']

if sim_task['run_IDM[y/n]'][0] =='y':
    all_collections += [model.IDM_obook.sellorders_all_df,
                  model.IDM_obook.buyorders_all_df,
                  model.IDM_obook.cleared_sellorders_all_df,
                  model.IDM_obook.cleared_buyorders_all_df]
    collection_names +=['IDsellorders','IDbuyorders','IDc_sellorders','IDc_buyorders']

if sim_task['run_RDM[y/n]'][0] =='y':
    all_collections += [model.red_obook.sellorders_all_df,
                  model.red_obook.buyorders_all_df,
                  model.red_obook.cleared_sellorders_all_df,
                  model.red_obook.cleared_buyorders_all_df,
                  model.red_obook.redispatch_demand_upward_all_df,
                  model.red_obook.redispatch_demand_downward_all_df]
    collection_names += ['REDsellorders','REDbuyorders','REDc_sellorders','REDc_buyorders', 'RED_demand_upward','RED_demand_downward']


if sim_task['run_DAM[y/n]'][0] =='y':
    all_collections += [model.DAM_obook.cleared_sellorders_all_df,
                      model.DAM_obook.cleared_buyorders_all_df]
    collection_names +=['DAc_sellorders','DAc_buyorders']

if sim_task['run_BEM[y/n]'][0] =='y':
    all_collections += [model.BEM_obook.sellorders_all_df,
                  model.BEM_obook.buyorders_all_df]
    collection_names +=['BEsellorders','BEbuyorders']

bb=0
for a in all_collections:
#    orders= pd.concat(a.values(),keys=a.keys())
#    if not orders.empty:
#        orders.to_excel(writer,sheet_name=collection_names[bb])
    if not a.empty:
        a.to_excel(writer,sheet_name=collection_names[bb])
    bb+=1


#In case I want to store orders as hdf5
#with pd.HDFStore('./results/allOrders '+stamp+'.h5') as store:
#    store['simulation_name'] = Series([sim_task.loc[0,'simulation_name']])
#    bb=0
#    for a in all_collections:
#        orders= pd.concat(a.values(),keys=a.keys())
#        if not orders.empty:
#            store[collection_names[bb]] = orders
#            orders.to_excel(writer,sheet_name=collection_names[bb])
#        bb+=1

model.rpt.get_cleared_prices().to_excel(writer,sheet_name='cleared_prices')
model.rpt.get_system_dispatch().to_excel(writer,sheet_name='system_dispatch')
model.rpt.get_all_trade_schedules().to_excel(writer,sheet_name='trade_schedules')
model.rpt.get_all_returns().to_excel(writer,sheet_name='all_returns')
writer.save()

###In case of hdf5 )doenst work yet.
#with pd.HDFStore(rdir+'Results '+simname+stamp+'.h5') as store:
#    store['simulation_name'] = Series([sim_task.loc[0,'simulation_name']])
#    store['simulation_task'] = simulation_task
##    store['simulation_parameters']= simulation_parameters
#    store['interdependence_indicators'] =indicators
#    store['key_figures'] = keyfigures
#    store['performance_indicators']= model.rpt.redispatch_PI()
#    store['AgentResults'] =agentdf
#    #save orders
#    bb=0
#    for a in all_collections:
#        orders= pd.concat(a.values(),keys=a.keys())
#        if not orders.empty:
#            store[collection_names[bb]] = orders
#        bb+=1
    #market stats
#    try:
#        for k in model.IDM_obook.rep_dict.keys():
#            table = model.IDM_obook.rep_dict[k]
#            table.to_excel(writer, sheet_name = 'IDM_'+k)
#    except AttributeError:
#        pass
#    try:
#        for k in model.red_obook.rep_dict.keys():
#            table = model.red_obook.rep_dict[k]
#            table.to_excel(writer, sheet_name = 'RED_'+k)
#    except AttributeError:
#        pass
#    try:
#
#        table = model.DAM_obook.rep_dict['cleared_sell_sum_volume']
#        table.to_excel(writer, sheet_name = 'DAM_cleared_sell_sum_volume')
#        table = model.DAM_obook.rep_dict['cleared_buy_sum_volume']
#        table.to_excel(writer, sheet_name = 'DAM_cleared_buy_sum_volume')
#    except AttributeError:
#        pass
#    try:
#        for k in model.BEM_obook.rep_dict.keys():
#            table = model.BEM_obook.rep_dict[k]
#            table.to_excel(writer, sheet_name = 'BEM_'+k)
#    except AttributeError:
#        pass

print(" done------------------------------------")






