# -*- coding: utf-8 -*-
"""
Created on Fri May  5 11:44:08 2017

@author: Otto
"""
from mesa import Agent, Model
from mesa.time import RandomActivation
from random import randrange, choice
import pandas as pd
import math
import pypsa
from pandas import Series, DataFrame
import numpy as np
from OrderMessage import *
from pyomo.environ import (ConcreteModel, Var, Objective,
                           NonNegativeReals, Constraint, Reals,
                           Suffix, Expression, Binary, SolverFactory)

from pypsa.opt import (l_constraint, l_objective, LExpression, LConstraint)

class MarketParty(Agent):
    """A Market party agent:
            -  has assets (ID, Pmax, Pmin, SMRC, Location)
            -  has a portfolio position (Pmin<Psched<Pmax)
            -  provides redispatch offers to TSO
            -  Target: maximize profit subject to portfolio limits

    """
    def __init__(self, unique_id, model, assets = None, agent_strategy = None):
        super().__init__(unique_id, model)
        self.model = model
        # Series of strategy items
        self.strategy = agent_strategy
        #DF with Asset() objects and unique ID as index
        if len(assets.index) != len(assets.index.unique()):

            raise Exception('asset ids must be unique per agent',assets.index)
        else:
            self.assets = assets
        self.money = 0
        self.step_rank=None
        #indicator for need of portfolio optimization (if no trade and no forecast changes, no optimization to be calculated)
        self.unchanged_position = False #values: True, False, 'forecast error'
        if self.strategy.loc['IBM_pricing'] == 'IB_price':
            try:
                self.imbalance_risk_price = self.model.IB_marketoperator.IBP_fixed
            except:
                #1000 as standard imbalance risk price
                self.imbalance_risk_price = 1000
        elif isinstance(self.strategy.loc['IBM_pricing'], int):
            self.imbalance_risk_price = self.strategy.loc['IBM_pricing']
        elif self.strategy.loc['IBM_pricing']=='ID_markup':
            self.imbalance_risk_price = 1000
        else:
            raise Exception ('imbalance pricing strategy not implemented in agents')
        #TODO: harmonize accepted and historic orders format ()
        #All orders should be in a non-multiindex format. They are cleaned up er round
        orderlabels =['agent_id','associated_asset','delivery_location','volume','price', 'delivery_day','delivery_time','order_type','init_time', 'order_id', 'direction','matched_order','cleared_volume','cleared_price','rem_vol', 'due_amount']
        self.accepted_red_orders = DataFrame( columns = orderlabels) #cleaned up in set_asset_commit_constraints()
        self.accepted_ID_orders = DataFrame(columns = orderlabels)  #cleaned up in update_trade_schedule()
        self.accepted_DA_orders = DataFrame(columns = orderlabels)  #cleaned up in update_trade_schedule()
        self.accepted_BE_orders = DataFrame(columns = orderlabels)  #NOT YET IMPLEMENTED. cleaned up in update_trade_schedule()
        self.ordercount = 1
        self.trade_schedule = model.clock.asset_schedules_horizon() #manipulated every round. All trade positions where delivery periode>current time remain unchanged
        self.trade_schedule= self.trade_schedule.reindex(columns=  ['DA_position','ID_position','RD_position','BE_position','forecast_error','total_trade', 'imbalance_position', 'total_dispatch'], fill_value= 0)
        self.financial_return = model.clock.asset_schedules_horizon() #manipulated every round. All returns where delivery periode>current time remain unchanged
        self.financial_return = self.financial_return.reindex(columns = ['DA_return','ID_return','RD_return', 'BE_return','IB_return', 'total_return', 'total_dispatch_costs', 'profit'])


        #initiate pypsa model for optimal unit commitment
        self.commit_model = pypsa.Network()
        self.commit_model.add("Bus","bus")
        self.commit_model.add("Load","trade_position",bus="bus")
        #add a generator that captures the unfeasible trade commitment (open short position)
        self.commit_model.add("Generator",'short_position' ,bus="bus",
               committable=True,
               p_min_pu= 0,
               marginal_cost=self.imbalance_risk_price,
               p_nom=10000)
        #add a negative generator unit to capture unfeasible trade commitment (open long positions)
        #has also a negative price.
        self.commit_model.add("Generator",'long_position',bus="bus",
               committable = True,
               p_min_pu= 1,
               p_max_pu= 0,
               p_nom=-10000,
               marginal_cost= -self.imbalance_risk_price)
        all_ids = self.assets.index.values

        for i in range(len(all_ids)):
            asset = self.assets.loc[all_ids[i],:].item()
            self.commit_model.add("Generator",asset.assetID ,bus="bus",
                   committable=True,
                   p_min_pu= asset.pmin/asset.pmax,
                   marginal_cost = asset.srmc,
                   p_nom=asset.pmax)
            #Agent strategy determines which constraints are taken intpo account during asset optimization
            if self.strategy['ramp_limits']==True:
                self.commit_model.generators.ramp_limit_up[asset.assetID] = asset.ramp_limit_up
                self.commit_model.generators.ramp_limit_down[asset.assetID] = asset.ramp_limit_down
                #TODO: find out what the impact of ramp_limit start stop is.
                #pyPSA question not yet answered. start_stop ramps only used in startstop price determination.
#                self.commit_model.generators.ramp_limit_start_up[asset.assetID] = asset.ramp_limit_start_up
#                self.commit_model.generators.ramp_limit_shut_down[asset.assetID] = asset.ramp_limit_shut_down
            if self.strategy['start_stop_costs']==True:
                self.commit_model.generators.start_up_cost[asset.assetID] = asset.start_up_cost
                self.commit_model.generators.shut_down_cost[asset.assetID] = asset.shut_down_cost
            if self.strategy['min_up_down_time']==True:
                self.commit_model.generators.min_up_time[asset.assetID] = asset.min_up_time
                self.commit_model.generators.min_down_time[asset.assetID] = asset.min_down_time

    def step(self):
        #add 1 to agent step order and store for report
        self.model.agent_random_step_index += 1
        self.step_rank = self.model.agent_random_step_index

        self.update_trade_schedule(positions=['DA_position','ID_position','RD_position'])
        self.set_asset_commit_constraints()
        self.portfolio_dispatch()
        #ID_makebid leads to instatanous IDM clearing
        self.ID_makebid()
        if not self.accepted_ID_orders.empty:
            print('processing ID clearing result with another trade schedule update and portfolio optimization')
            #after instantanous clearing another portfolio optimization is needed before red orders can be made
            self.update_trade_schedule(positions=['ID_position'])
            self.portfolio_dispatch()
        self.red_makebid()
        self.BE_makebid()


    def update_trade_schedule(self, positions =[]):
        """positions is a list of positions to be updated.
        it may contain 'DA_position', 'ID_position', RED_position','BE_position'.
        also the return from trading is updated with this method."""
        print('start update trade schedule of Agent ', self.unique_id)
        if (self.accepted_red_orders.empty)&(self.accepted_ID_orders.empty)&(
                self.accepted_DA_orders.empty)&(
                        self.accepted_BE_orders.empty)&(
                                self.unchanged_position != 'forecast_error'):
            #no new trades and no new forecast errors in last round
            self.unchanged_position = True
            print('no position has changed of this agent')
        else:
            self.unchanged_position = False
        new_trade_schedule = self.model.schedules_horizon.copy()
        new_trade_schedule = new_trade_schedule.add(self.trade_schedule,fill_value = 0)
        new_trade_returns = self.model.schedules_horizon.copy()
        new_trade_returns = new_trade_returns.add(self.financial_return,fill_value = 0)
        if self.unchanged_position == False:
            for i in positions:
                new_transactions = DataFrame()
                if i == 'DA_position':
                    new_transactions =self.accepted_DA_orders[['delivery_day','delivery_time'
                                                         ,'cleared_volume','direction', 'due_amount']]
                    k = 'DA_return'
                    #clear accepeted_orders DataFrame. Will be filled again after stettlement  this round
                    self.accepted_DA_orders = self.accepted_DA_orders.iloc[0:0]
                elif i == 'ID_position':
                    new_transactions =self.accepted_ID_orders[['delivery_day','delivery_time'
                                                         ,'cleared_volume','direction', 'due_amount']]
                    k = 'ID_return'

                    #clear accepeted_orders DataFrame. Will be filled again after stettlement  this round
                    self.accepted_ID_orders = self.accepted_ID_orders.iloc[0:0]
                elif i == 'RD_position':
                    new_transactions =self.accepted_red_orders[['delivery_day','delivery_time'
                                                         ,'cleared_volume','direction', 'due_amount']]
                    k = 'RD_return'
                    #accepted redispatch orders are cleared in set_asset_commit_constraints ()
                elif i == 'BE_position':
                    new_transactions =self.accepted_BE_orders[['delivery_day','delivery_time'
                                                         ,'cleared_volume','direction', 'due_amount']]
                    k = 'BE_return'
                    #clear accepeted_orders DataFrame. Will be filled again after stettlement  this round
                    self.accepted_BE_orders = self.accepted_BE_orders.iloc[0:0]
                else:
                    raise Exception('position to be updated unknown')
                if new_transactions.empty:
                    pass #do nothing. next position.
                else:
                    #make sell orders negative
                    mask = new_transactions['direction'] == 'buy'
                    new_transactions[i] = new_transactions['cleared_volume'].where(mask,-1*new_transactions['cleared_volume']).astype('float64')
                    new_transactions[k] = new_transactions['due_amount']
                    new_transactions.set_index(['delivery_day','delivery_time'], inplace=True)
                    #sum (saldo) of trades from the agent per timestamp
                    new_transactions = new_transactions.groupby(level =[0,1]).sum()
                    #add to 'position' column in self.trade_schedule

                    new_trade_schedule[i] = new_trade_schedule[i].add(new_transactions[i], fill_value = 0)
                    #add to 'return' column in self.financial_return
                    new_trade_returns[k] = new_trade_returns[k].add(new_transactions[k], fill_value = 0)
        #overwrite self.trade_schedule
        self.trade_schedule = new_trade_schedule.copy()
        #overwrite self.financial returns
        self.financial_return = new_trade_returns.copy()
        #calculate total schedule. this value can be positive or negative and larger than the sum of all asset pmax.
        self.trade_schedule['total_trade'] = self.trade_schedule[['DA_position','ID_position','RD_position','BE_position','forecast_error']].sum(axis=1)
        #calculate total return.
        self.financial_return['total_return'] = self.financial_return[['DA_return','ID_return','RD_return', 'BE_return','IB_return']].sum(axis=1)
        self.financial_return['profit'] = self.financial_return['total_return'] + self.financial_return['total_dispatch_costs']

    def set_asset_commit_constraints (self):

        if self.accepted_red_orders.empty:
            #in this case there are not time varying dispatch contraints on assets
            #from redisaptch, other than previous contraints in asset.constraint_df
            #however, the constraint_df need to be within dispatch schedule horizon
            all_ids = self.assets.index.values
            #update Red_commit per asset
            for i in range(len(all_ids)):
                asset = self.assets.loc[all_ids[i],:].item()
                asset.calc_dispatch_constraints(self.model.schedules_horizon)
        else:
            all_ids = self.assets.index.values
            #update Red_commit per asset
            i=0
            for i in range(len(all_ids)):
                asset = self.assets.loc[all_ids[i],:].item()

                #get redispatch transactions of that asset
                RED_asset_schedule = self.accepted_red_orders.loc[self.accepted_red_orders['associated_asset'] == asset.assetID, ['delivery_day', 'delivery_time','cleared_volume','direction']]
                if RED_asset_schedule.empty:
                    #eventhough no redisaptch has been cleared for the agent,contraints are calculated to get the right size of the contraint_df
                    new_red_schedule = self.model.schedules_horizon.copy()
                    asset.calc_dispatch_constraints(new_red_schedule)
                else:
                    new_red_schedule = self.model.schedules_horizon.copy()
                    # make temporary dataframe from accepted bids that can be added to redispatch asset schedule
                     #make buy orders negative to use them for a dispatch reduction (downward)
                    mask = RED_asset_schedule['direction'] == 'sell'
                    RED_asset_schedule['cleared_volume'] = RED_asset_schedule['cleared_volume'].where(mask,-RED_asset_schedule['cleared_volume'])

                    RED_asset_schedule.set_index(['delivery_day','delivery_time'], inplace = True)
                    RED_asset_schedule.sort_index(level = 1, inplace = True)
                    RED_asset_schedule = RED_asset_schedule.groupby(level =[0,1]).sum()
                    RED_asset_schedule.rename(columns = {'cleared_volume': 'commit'}, inplace = True)

                    #place commitment in schedule horizon format
                    new_red_schedule['commit'] = RED_asset_schedule['commit'].copy()
                    new_red_schedule['commit'] = new_red_schedule['commit'].loc[self.model.schedules_horizon.index].fillna(value=0).copy()
                    asset.calc_dispatch_constraints(new_red_schedule)
            #remove all accepted redispatch orders from this round.
            self.accepted_red_orders = self.accepted_red_orders.iloc[0:0]


    def portfolio_dispatch(self):
        """pypsa used to find optimal unit comitment given the trade position.
        - the trade position is used as 'load'
        -a slack generator with high costs is used to capture the unfeasible dispatch ('open position)
        -if the total trade position is negative it is not caputred by the slack generator but cut out in advance from the schedule and added to imbalance.
        """

        print('start portfolio optimization of Agent ', self.unique_id)

        #all assets id's of this agent
        all_ids = self.assets.index.values
        must_run_commit= DataFrame()
        if self.unchanged_position == True:
            print('no additional portfolio optimization needed because nothing has changed for this agent')
            #add dispatch cost of current (thus realized) dispatch to bank account
            day,mtu = self.model.clock.calc_timestamp_by_steps(self.model.schedule.steps,0)
            self.money += self.financial_return.loc[(day,mtu),'total_dispatch_costs'].copy()
        else:
            #convert model time index to pypsa snapshot (may not be tuples or multiindex)
            snap = DataFrame(index=self.model.schedules_horizon.index)
            snap=snap.reset_index()
            snap['strIndex']=snap['delivery_day'].map(str)+str('_')+snap['delivery_time'].map(str)
            self.commit_model.set_snapshots(snap['strIndex'])

            #add the trade position networkmodel load.
            #   Note that positive values mean consumption in PyPSA.
            #   positive trade positions, however mean long position. trade schedule is therefore multiplied by -1
            relevant_trades = -self.trade_schedule.loc[self.model.schedules_horizon.index].copy()
            if len(relevant_trades['total_trade'])== len(snap['strIndex']):
                #adjust relevant trades by setting negative values ('generation') on 0
                if (relevant_trades['total_trade']<0).any():
                    relevant_trades['total_trade'] = relevant_trades['total_trade'].where(relevant_trades['total_trade']>=0.0,0)
                    print('Agent{} has a total schedule with values < 0'.format(self.unique_id))
                #make list from series
                commit_lst = list(relevant_trades['total_trade'].fillna(value=0))
            else:
                raise Exception ('there is a issue with the snapshot timestamps and asset trade_schedule timestamps')
            self.commit_model.loads_t.p_set['trade_position']=  commit_lst
            #calculate timestamp of last round
            day, MTU=   self.model.clock.calc_timestamp_by_steps(self.model.schedule.steps -1, 0)
            for i in range(len(all_ids)):
                asset = self.assets.loc[all_ids[i],:].item()
                #time variant asset constraints in p.u. of pmax
                if len(snap['strIndex']) == len(asset.constraint_df.loc[self.model.schedules_horizon.index]):
                    #to be given to pypsa
                    pmin_t = list(asset.constraint_df['p_min_t'].loc[self.model.schedules_horizon.index]/asset.pmax)
                    pmax_t = list(asset.constraint_df['p_max_t'].loc[self.model.schedules_horizon.index]/asset.pmax)
                    if (asset.constraint_df['upward_commit']>0).any():
                        #constraint snapshots
                        up_const = asset.constraint_df[['dispatch_limit', 'p_max_t']].loc[self.model.schedules_horizon.index].loc[
                                        asset.constraint_df['upward_commit']!=0].reset_index()
                        up_const['gen_name'] = asset.assetID
                        up_const ['strIndex']=up_const['delivery_day'].map(str)+str('_')+up_const['delivery_time'].map(str)
                        #make an index from generatorname and snapshot for later use in pypsa constraint method
                        up_const.set_index(['gen_name','strIndex'], inplace=True)
                        must_run_commit = pd.concat([must_run_commit, up_const])
                else:
                    print(asset.assetID)
                    raise Exception ('there is a issue with the snapshot timestamps and asset constraints timestamps')
                self.commit_model.generators_t.p_max_pu[asset.assetID] = pmax_t
                self.commit_model.generators_t.p_min_pu[asset.assetID] = pmin_t

                #ensure that minimum up & downtimes > optimization horizon are corrected
                if asset.min_up_time > len(snap):
                    self.commit_model.generators.min_up_time[asset.assetID] = len(snap)
                if asset.min_down_time > len(snap):
                    self.commit_model.generators.min_down_time[asset.assetID] = len(snap)

                #ensure that the initial status taken from
                try:
                    last_dispatch = asset.schedule.loc[(day,MTU), 'commit']
                    if last_dispatch > 0:
                        self.commit_model.generators.initial_status[asset.assetID]=1
                    else:
                        self.commit_model.generators.initial_status[asset.assetID]=0
                except:
                    #in the first step there is no previous dispatch.
                    if not self.model.DA_marketoperator.test_init_dispatch.empty:
                        self.commit_model.generators.initial_status[asset.assetID]=self.model.DA_marketoperator.test_init_dispatch[asset.assetID]
                    else:
                        #assume 1
                        self.commit_model.generators.initial_status[asset.assetID]=1

            def red_commit_constraint(network, snapshots):
                """this method gives an extra must-run constraint to generators that have been
                  commited to upward redispatch"""
                if must_run_commit.empty:
                    pass
                else:
                    gen_p_bounds = {(gen_sn) : (must_run_commit.loc[gen_sn,'dispatch_limit'],
                                    must_run_commit.loc[gen_sn,'p_max_t'])
                                    for gen_sn in must_run_commit.index.values}
                    red_must_run={}
                    for gen_sn in must_run_commit.index.values:
                        red_must_run[gen_sn] = [[(1, network.model.generator_p[gen_sn])],"><", gen_p_bounds[gen_sn]]
                    l_constraint(network.model, "must_run", red_must_run, list(must_run_commit.index.values))

            #run linear optimal power flow
            try:
                lopf_status= self.commit_model.lopf(self.commit_model.snapshots, extra_functionality = red_commit_constraint,
                                       solver_name= 'gurobi', free_memory={'pypsa'})

            except:
                print(self.commit_model.generators_t.p_max_pu)
                print(self.commit_model.generators_t.p_min_pu)
                import pdb
                pdb.set_trace()
            if lopf_status[0]!='ok':
                try:
                    asset = self.assets.loc['Centrale Lage Weide',:].item()
                except:
                    print('okoo')
                import pdb
                pdb.set_trace()

            #process loadflow results to disaptch and trade schedule
            opt_dispatch = self.commit_model.generators_t.p.copy()
            opt_dispatch['long_position']= -opt_dispatch['long_position']

            if opt_dispatch.empty:
                print('Issue with agent ',self.unique_id)
                print(self.trade_schedule)
                raise Exception('optimal power flow did not find a solution')
            #convert index again
            opt_dispatch.index = opt_dispatch.index.str.split(pat='_', expand =True)
            opt_dispatch.index.set_names(['delivery_day','delivery_time'], inplace=True)
            #make inters from index
            opt_dispatch.reset_index(inplace=True)
            opt_dispatch[['delivery_day','delivery_time']] = opt_dispatch[['delivery_day','delivery_time']].astype('int64')
            opt_dispatch.set_index(['delivery_day','delivery_time'], inplace=True)
            #calculate total dispatch (excluding the dummy generator/storage)
            opt_dispatch['total_dispatch'] =opt_dispatch.sum(axis=1)- opt_dispatch['long_position'] - opt_dispatch['short_position']
            self.trade_schedule.loc[self.model.schedules_horizon.index,'total_dispatch'] = opt_dispatch['total_dispatch'].loc[self.model.schedules_horizon.index]

            #positive trade schedule values mean that more is bought than sold (long), negative values means short position (more sold than bought)
            #dispatch positive means injection to grid, negative means consumption
            #total trade schedule + total dispatch = imbalance position.
            # a positive imbalance position is a long imbalance position ->more produced than (net) sold.
            #  a negative imbalance position is a short imbalance position ->less produced than (net) sold
            self.trade_schedule['imbalance_position'].loc[
                    self.model.schedules_horizon.index] =  self.trade_schedule[
                            'total_dispatch'].loc[self.model.schedules_horizon.index
                    ] + self.trade_schedule['total_trade'].loc[
                            self.model.schedules_horizon.index]
            if (self.trade_schedule['imbalance_position'].loc[self.model.schedules_horizon.index]!=0).any():
#                if self.unique_id == 'NAM':
#                    import pdb
#                    pdb.set_trace()
                print('IMBALANCE of agent: ', self.unique_id)
    #            import pdb
    #            pdb.set_trace()
    #            print(opt_dispatch)
    #            print(self.trade_schedule)
    #            print(self.trade_schedule['imbalance_position'])

            #calculate dispatch costs (also devided by 4 as we have 15 minute steps)
            dispatch_cost = opt_dispatch.copy()
            for j in opt_dispatch.loc[:,(opt_dispatch.columns != 'long_position')& (
                    opt_dispatch.columns != 'short_position')& (
                    opt_dispatch.columns != 'total_dispatch')].columns:
                #variable cost
                dispatch_cost['var_cost_'+j] = dispatch_cost[j] * self.commit_model.generators.loc[j,'marginal_cost']/4

                #calculate startstop cost
                startstopcost =Series([1]*len(dispatch_cost),index =dispatch_cost.index).where(dispatch_cost[j] > 0,0)
                #starts=1, stops=-1
                startstopcost=startstopcost - startstopcost.shift(1)
                #take into account initial status
                if (self.commit_model.generators.initial_status[j]==1)&(int(round(dispatch_cost[j].iloc[0]))==0):
                    startstopcost.iloc[0] = -1
                elif (self.commit_model.generators.initial_status[j]==0)&(int(round(dispatch_cost[j].iloc[0]))>0):
                    startstopcost.iloc[0] = 1
                else:
                    startstopcost.iloc[0] = 0
                startstopcost.loc[startstopcost==1] =self.commit_model.generators.start_up_cost[j]
                startstopcost.loc[startstopcost==-1] =self.commit_model.generators.shut_down_cost[j]
                dispatch_cost['fix_cost_'+j] = startstopcost
            dispatch_cost.drop(opt_dispatch.columns, axis=1,inplace = True)
            #calculate total dispatch cost (startstop cost included)
            dispatch_cost['total_dispatch_costs'] = dispatch_cost.sum(axis=1)


            #dispatch costs are by definition negative
            self.financial_return.loc[self.model.schedules_horizon.index,'total_dispatch_costs'] = -dispatch_cost[
                    'total_dispatch_costs'].loc[self.model.schedules_horizon.index].copy()

            #add dispatch cost of current (thus realized) dispatch to bank account
            day,mtu = self.model.clock.calc_timestamp_by_steps(self.model.schedule.steps,0)
            self.money += self.financial_return.loc[(day,mtu),'total_dispatch_costs'].copy()
        #end of if-else unchanged_position == True

        #assign dispatch values to asset schedule.
        i=0
        for i in range(len(all_ids)):
            asset = self.assets.loc[all_ids[i],:].item()
            #enlarge asset schedule time index
            mask =self.model.schedules_horizon.index.isin(asset.schedule.index)
            asset.schedule = asset.schedule.append(self.model.schedules_horizon.loc[~mask,asset.schedule.columns])
            if self.unchanged_position == False: #if unchanged == True this step is skipped
                #add optimal dispatch results to asset schedule, without overwriting the past, i.e. realized dispatch
                mask = asset.schedule.index.isin(opt_dispatch.index)
                asset.schedule['commit'] = asset.schedule['commit'].where(~mask,opt_dispatch[asset.assetID].copy())
                #ensure that no very small values from the solver stay in results
                asset.schedule['commit'] =asset.schedule['commit'].round(0).astype(int)
#            if (asset.schedule['commit'] > asset.pmax).any():
#                import pdb
#                pdb.set_trace()

            #calculate available capacity based on constraint df temp pmax and pmin
#            asset.schedule['p_max_t'].loc[self.model.schedules_horizon.index] = asset.constraint_df['p_max_t']
#            asset.schedule['p_min_t'].loc[self.model.schedules_horizon.index] = asset.constraint_df['p_min_t']
            #full_available volume refers to operational volume.
#            asset.schedule['full_available_up'] = (asset.schedule['p_max_t'] - asset.schedule['commit']).where(
#                    (asset.schedule['commit'] >= asset.pmin) & (
#                            asset.schedule['p_max_t'] > asset.schedule['commit']) & (
#                                    asset.constraint_df['downward_commit'] == 0), 0)
            #available down is also a positive value!!
#            asset.schedule['full_available_down'] = (asset.schedule['commit']-asset.schedule['p_min_t']).where(
#                    (asset.schedule['commit'] > asset.pmin) &(asset.constraint_df['upward_commit'] == 0), 0)
            #calculate available capacity based on constraint df temp pmax and pmin
            asset.schedule['p_max_t'].loc[self.model.schedules_horizon.index] = asset.constraint_df['p_max_t']
            asset.schedule['p_min_t'].loc[self.model.schedules_horizon.index] = asset.constraint_df['p_min_t']

            asset.schedule['full_available_up'] = (asset.schedule['p_max_t'] - asset.schedule['commit']).where(
                    (asset.schedule['commit'] >= asset.pmin) & (
                            asset.schedule['p_max_t'] > asset.schedule['commit']) & (
                                    asset.constraint_df['downward_commit'] == 0), 0)
            #available down is also a positive value!!
            asset.schedule['full_available_down'] = (asset.schedule['commit']-asset.schedule['p_min_t']).where(
                    (asset.schedule['commit'] > asset.schedule['p_min_t']) & (asset.constraint_df['upward_commit'] == 0), 0)

            if ((asset.schedule['full_available_up'] < 0).any())|((asset.schedule['full_available_down'] < 0).any()):
                import pdb
                pdb.set_trace()
                raise Exception('available_up and available_down must be values >= 0')
            mask = (self.trade_schedule['imbalance_position'].loc[self.model.schedules_horizon.index] != 0)
            if (mask == True).any():
                #Note: MTU with imbalance are restricted for usual bidding.
                #The market party applies a intraday bidding strategy to these MTU
                asset.schedule['full_available_up'].loc[self.model.schedules_horizon.index
                          ] = asset.schedule['full_available_up'].loc[
                                  self.model.schedules_horizon.index].where(~mask, 0)
                asset.schedule['full_available_down'].loc[self.model.schedules_horizon.index
                          ] = asset.schedule['full_available_down'].loc[
                                  self.model.schedules_horizon.index].where(~mask, 0)

            #NOTE: this function is only possible if patient traders are imbalance implemented. But it is actually not needed.
#            #MTUs with imbalance short position are restricted for further 'sell-orders'. Buy is OK, but will also be placed as market order.Risk: double score.
#            mask_short= (self.trade_schedule['imbalance_position'].loc[self.model.schedules_horizon.index] < 0)
#            #MTUs with imbalance long position are restricted for further 'buy-orders'. Sell is OK, but will also be placed as market order.Risk: double score.
#            mask_long= (self.trade_schedule['imbalance_position'].loc[self.model.schedules_horizon.index] > 0)
#            if ((mask_short == True).any())|((mask_long == True).any()):
#                asset.schedule['full_available_up'].loc[self.model.schedules_horizon.index
#                          ] = asset.schedule['full_available_up'].where(~mask_short, 0)
#                asset.schedule['full_available_down'].loc[self.model.schedules_horizon.index
#                          ] = asset.schedule['full_available_down'].where(~mask_long, 0)

            #available capacity with contraint that it is <=ramp rate from one MTU to the next
            asset.schedule['ramp_constr_avail_up'] =asset.schedule['full_available_up'].where(
                    asset.schedule['full_available_up']<=asset.ramp_limit_up *asset.pmax, asset.ramp_limit_up *asset.pmax)
            asset.schedule['ramp_constr_avail_down'] =asset.schedule['full_available_down'].where(
                    asset.schedule['full_available_down']<=asset.ramp_limit_down *asset.pmax, asset.ramp_limit_down *asset.pmax)
            #available capacity with constraint that it is <= remaining ramps considering commited ramp t-1 and t+1
            #Pt - Pt-1
            asset.schedule['commit_ramp_t-1'] = asset.schedule['commit'] - asset.schedule['commit'].shift(1)
            #Pt+1 - Pt
            asset.schedule['commit_ramp_t+1'] = asset.schedule['commit'].shift(-1) - asset.schedule['commit']
            #correct nan of first and last time stamp. assume commit ramp of 0.
            asset.schedule['commit_ramp_t-1'].fillna(value = 0, inplace=True)
            asset.schedule['commit_ramp_t+1'].fillna(value = 0, inplace=True)
            asset.schedule['rem_ramp_constr_avail_up'] = asset.schedule.apply(
                    lambda x: min(- x['commit_ramp_t-1'] + asset.ramp_limit_up *asset.pmax,
                                  x['commit_ramp_t+1'] + asset.ramp_limit_up *asset.pmax,
                                  x['full_available_up']), axis =1)
            asset.schedule['rem_ramp_constr_avail_down'] = asset.schedule.apply(
                    lambda x: min(x['commit_ramp_t-1'] + asset.ramp_limit_down * asset.pmax,
                                  - x['commit_ramp_t+1'] + asset.ramp_limit_up * asset.pmax,
                                  x['full_available_down']), axis =1)
            #if the portfolio dispatch optimization allows start stop changes >ramp limits, negative remaining ramps are to be avoided
            asset.schedule['rem_ramp_constr_avail_up']=asset.schedule['rem_ramp_constr_avail_up'].where(asset.schedule['rem_ramp_constr_avail_up']>=0, 0)
            asset.schedule['rem_ramp_constr_avail_down']=asset.schedule['rem_ramp_constr_avail_down'].where(asset.schedule['rem_ramp_constr_avail_down']>=0, 0)


    def red_makebid(self):


       #check if redipatch is part of simulation task
       if self.model.exodata.sim_task.loc[0,'run_RDM[y/n]']=='n':
           print('Agent {}:no redispatch in simlulation task'.format(self.unique_id))
       elif self.model.red_marketoperator.rules['order_types']== 'IDCONS_orders':
           #no dediacted redisaptch orders allowed. redispatch via IDCONS on intraday market.
           pass
       elif self.strategy['RED_volume']=='None':
           #this agent does not participate in the redispatch market
           print('Agent {}:does not participate in redispatch market'.format(self.unique_id))
           pass
       else:
           #first delete all own redispatch orders from previous round from orderbook
           self.model.red_obook.delete_orders(agent_id_orders = self.unique_id)
           asset_location_lst = []
           agentID_lst = []
           assetID_lst =[]
           init_lst = []
           direction_lst = []
           ordertype_lst = []
           vol_lst=[]
           price_lst=[]
           day_lst=[]
           mtu_lst=[]
           delivery_duration =[]
           gate_closure_MTU = self.model.red_marketoperator.gate_closure_time
           print("Agent {} makes redispatch bids".format(self.unique_id))
           #works for up to 100 agents
           init = self.step_rank/100 + self.model.clock.get_MTU()
           dayindex = list(self.model.schedules_horizon.index.get_level_values(0))[gate_closure_MTU:]
           timeindex = list(self.model.schedules_horizon.index.get_level_values(1))[gate_closure_MTU:]

           #get all assets of that market party
           all_ids = self.assets.index.values
           for i in range(len(all_ids)):
               a = self.assets.loc[all_ids[i],:].item()
               #store current asset schedule (excluding the past) for calculation of dispatch contraints from redispatch
               a.schedule_at_redispatch_bidding= a.schedule.loc[self.model.schedules_horizon.index].copy()
               if self.strategy['RED_timing']=='instant':
#                   if a.assetID== 'IJmond 1':
#                        import pdb
#                        pdb.set_trace()
                   #list cotaining three lists (delivery day, delivery time, delivery duration)
                   startblocks =[[],[],[]]
                   stopblocks = [[],[],[]]
                   price_start_lst = []
                   price_stop_lst= []
                   if self.strategy['RED_volume']=='random':
                       vol_up_lst = self.small_random_volume(a.schedule[['full_available_up','p_max_t']].loc[
                                    self.model.schedules_horizon.index].fillna(0))
                       vol_down_lst = self.small_random_volume(a.schedule[['full_available_down','p_max_t']].loc[
                                    self.model.schedules_horizon.index].fillna(0))
                   elif (self.strategy['RED_volume']=='all_operational')|(
                           self.strategy['RED_volume']=='all_plus_startstop'):
                       vol_up_lst = list(a.schedule['full_available_up'].loc[
                                    self.model.schedules_horizon.index].fillna(0).astype(int))
                       vol_down_lst = list(a.schedule['full_available_down'].loc[
                                    self.model.schedules_horizon.index].fillna(0).astype(int))
                   elif self.strategy['RED_volume']=='not_offered_plus_startstop':
                       #get the position from offered on IDM
                       buy_position, sell_position =self.model.IDM_obook.get_offered_position(associated_asset=a.assetID)
                       #deduct offered positio from availble capacity
                       if a.schedule['full_available_up'].loc[
                                    self.model.schedules_horizon.index].index.isin(sell_position.index).any():
                           vol_up_lst =a.schedule['full_available_up'].loc[
                                        self.model.schedules_horizon.index].fillna(0).to_frame().join(
                                        -sell_position).sum(axis=1).astype(int).copy().values
                           #correct negative values.Reason is a portfolio optimization after IDM clearing.
                           vol_up_lst[vol_up_lst < 0] = 0
                           vol_up_lst = list(vol_up_lst)
                       else:
                           #sell_position empty or outside schedule
                           vol_up_lst = list(a.schedule['full_available_up'].loc[
                                    self.model.schedules_horizon.index].fillna(0).astype(int))
                       if a.schedule['full_available_down'].loc[
                                    self.model.schedules_horizon.index].index.isin(buy_position.index).any():
                           vol_down_lst =a.schedule['full_available_down'].loc[
                                            self.model.schedules_horizon.index].fillna(0).to_frame().join(
                                            -buy_position).sum(axis=1).astype(int).copy().values
                           vol_down_lst[vol_down_lst < 0] = 0
                           vol_down_lst = list(vol_down_lst)
                       else:
                           vol_down_lst = list(a.schedule['full_available_down'].loc[
                                    self.model.schedules_horizon.index].fillna(0).astype(int))

                   else:
                       raise Exception('redispatch volume strategy not known')
                   if (self.strategy['RED_volume']=='all_plus_startstop')|(
                           self.strategy['RED_volume']=='not_offered_plus_startstop'):
                       av_cap = pd.concat([a.schedule.loc[self.model.schedules_horizon.index[gate_closure_MTU:]],
                                    a.constraint_df.loc[self.model.schedules_horizon.index[
                                    gate_closure_MTU:],'upward_commit'].copy()], axis=1)
                       startblocks, stopblocks = self.start_stop_blocks (av_cap, \
                               a.pmin, a.min_up_time, a.min_down_time,a.assetID)
                       #in case the pricing strategy contains no start stop markup, prices are per default srmc
                       if startblocks:
                           price_start_lst = [int(a.srmc)] * len(startblocks[0])
                       if stopblocks:
                           price_stop_lst= [int(a.srmc)] * len(stopblocks[0])

                   if self.strategy['RED_pricing'] =='srmc':
                       price_up_lst = [int(a.srmc)] * len(dayindex)
                       price_down_lst = [int(a.srmc)] * len(dayindex)
                       price_start_lst = [int(a.srmc)] * len(startblocks[0])
                       price_stop_lst= [int(a.srmc)] * len(stopblocks[0])
                   elif (self.strategy['RED_pricing']=='all_markup')|(
                           self.strategy['RED_pricing']=='opportunity_markup'):
                       price_up_lst = self.get_opportunity_costs(
                               direction='upward', of_volumes = vol_up_lst,
                               asset = a,success_assumption = 'offered_volumes')
                       price_down_lst = self.get_opportunity_costs(
                               direction='downward', of_volumes = vol_down_lst,
                               asset = a, success_assumption = 'offered_volumes')
                       #slice list to consider gate closure time
                       price_up_lst = price_up_lst[gate_closure_MTU:]
                       price_down_lst = price_down_lst[gate_closure_MTU:]
                   if (self.strategy['RED_pricing']=='all_markup')|(
                           self.strategy['RED_pricing']=='startstop_markup'):

                      price_start_lst, start_markup = self.startstop_markup(
                              direction = 'upward', of_volumes = startblocks, asset = a,
                              gct = gate_closure_MTU, partial_call = False)
                      price_stop_lst, stop_markup = self.startstop_markup(
                             direction = 'downward', of_volumes = stopblocks,
                             asset = a, gct = gate_closure_MTU, partial_call = False)
                   if (self.strategy['RED_pricing']=='all_markup')|(
                           self.strategy['RED_pricing']=='ramping_markup'):
                      ramp_markup_up =self.ramping_markup(direction='upward',
                                                      of_volumes = vol_up_lst,
                                                      asset = a, return_markup=True)
                      ramp_markup_down =self.ramping_markup(direction='downward',
                                                      of_volumes = vol_down_lst,
                                                      asset = a, return_markup=True)
                      #add ramp_markups to price list
                      if len(ramp_markup_up[gate_closure_MTU:])==len(price_up_lst):
                          price_up_lst = [i[0] +i[1] for i in zip(ramp_markup_up[gate_closure_MTU:],price_up_lst)]
                      else:
                          import pdb
                          pdb.set_trace()
                      if len(ramp_markup_down[gate_closure_MTU:])==len(price_down_lst):
                          price_down_lst = [i[0] +i[1] for i in zip(ramp_markup_down[gate_closure_MTU:],price_down_lst)]
                      else:
                          import pdb
                          pdb.set_trace()
                   if (self.strategy['RED_pricing']=='all_markup')|((
                           self.strategy['RED_pricing']=='double_scoring_markup')&(
                                   self.strategy['RED_volume']!='not_offered_plus_startstop')):

                      doublescore_markup_up =self.doublescore_markup(direction='upward',
                                                      of_volumes = vol_up_lst,
                                                      asset = a, return_markup=True)
                      doublescore_markup_down =self.doublescore_markup(direction='downward',
                                                      of_volumes = vol_down_lst,
                                                      asset = a, return_markup=True)
                      #add ramp_markups to price list
                      if len(doublescore_markup_up[gate_closure_MTU:])==len(price_up_lst):
                          price_up_lst = [i[0] +i[1] for i in zip(doublescore_markup_up[gate_closure_MTU:],price_up_lst)]
                      else:
                          import pdb
                          pdb.set_trace()
                      if len(doublescore_markup_down[gate_closure_MTU:])==len(price_down_lst):
                          price_down_lst = [i[0] +i[1] for i in zip(doublescore_markup_down[gate_closure_MTU:],price_down_lst)]
                      else:
                          import pdb
                          pdb.set_trace()


#                   else:
#                       raise Exception('RED pricing strategy not known')
                   length =len(dayindex) * 2 + len(startblocks[0]) + len(stopblocks[0])
                   #per order attribute a list over all agent assets is built
                   asset_location_lst += [a.location] * length
                   agentID_lst += [self.unique_id]* length
                   assetID_lst += [a.assetID]* length
                   init_lst += [init] * length
                   direction_lst += ['buy'] * len(dayindex) + ['sell'] *len(dayindex) +['sell'] * len(startblocks[0])+['buy'] * len(stopblocks[0])
                   ordertype_lst += ['redispatch_supply']* length
                   delivery_duration += [1] * len(dayindex) * 2 + startblocks[2] + stopblocks[2]
                   vol_lst += vol_down_lst[gate_closure_MTU:] + vol_up_lst[gate_closure_MTU:] + [a.pmin] *(
                           len(startblocks[0]) + len(stopblocks[0]))
                   price_lst += price_down_lst + price_up_lst + price_start_lst + price_stop_lst
                   day_lst += dayindex * 2 + startblocks[0] + stopblocks[0]
                   mtu_lst += timeindex * 2 + startblocks[1] + stopblocks[1]


               else:
                   raise Exception ('redispatch timing strategy not known')

           orders = DataFrame()
           #NOTE: importance to have same ranking of culumns and values
           columns=['agent_id','associated_asset','delivery_location',
                                  'volume','price', 'delivery_day','delivery_time',
                                  'order_type','init_time', 'direction', 'delivery_duration']

           values =[agentID_lst,assetID_lst, asset_location_lst,
                               vol_lst, price_lst, day_lst,mtu_lst,
                               ordertype_lst, init_lst, direction_lst, delivery_duration]

           #make dataframe per column to maintain datatype of lists (otherwise seen as objects by pandas)
           for i in range(len(columns)):
                orders[columns[i]]=values[i]
           #remove 0 MW rows
           orders = orders.loc[orders['volume']!=0].copy()
#           if (orders['price'] == 0).any():
#               import pdb
#               pdb.set_trace()
           if not orders.empty:
               # insert order IDs (must be at second last column because of many dependencies)
               orders.insert(loc = len(orders.columns)-2,column='order_id',
                             value =list(range(self.ordercount, self.ordercount + len(orders))) )
               orders['order_id']=orders['agent_id'] + orders['associated_asset'] + orders['order_id'].astype(str)

               #order count for the order ID
               self.ordercount += len(orders)
               order_message = OrderMessage(orders)
               self.model.red_obook.add_order_message(order_message)

    def ID_makebid(self):
        #check if redipatch is part of simulation task
        if self.model.exodata.sim_task.loc[0,'run_IDM[y/n]']=='n':
            print('Agent {}:no intraday market in simlulation task'.format(self.unique_id))
        elif self.strategy['IDM_volume']=='None':
           #this agent does not participate in the redispatch market
           print('Agent {}:does not participate in redispatch market'.format(self.unique_id))
           pass
        else:
            #first delete all ID orders from previous round from orderbook
            self.model.IDM_obook.delete_orders(agent_id_orders = self.unique_id)

            print("Agent {} makes ID bids".format(self.unique_id))
#            order_lst=[]
            asset_location_lst = []
            agentID_lst = []
            assetID_lst =[]
            init_lst = []
            direction_lst = []
            ordertype_lst = []
            vol_lst=[]
            price_lst=[]
            day_lst=[]
            mtu_lst=[]
            delivery_duration =[]
            gate_closure_MTU = self.model.ID_marketoperator.gate_closure_time
            dayindex = list(self.model.schedules_horizon.index.get_level_values(0))[gate_closure_MTU:]
            timeindex = list(self.model.schedules_horizon.index.get_level_values(1))[gate_closure_MTU:]
            otype = 'intraday_limit_order'
            #init means simulation mtu plus agent step rank. works for up to 100 agents.
            init = self.step_rank/100 +self.model.clock.get_MTU()
            #get all assets of that market party
            all_ids = self.assets.index.values

            if (self.strategy['IDM_volume']=='random_plus_cond_startstop')|(
                    self.strategy['IDM_volume']=='all_plus_cond_startstop'):
                #get previous timestamp (required e.g. for IDCONS volume)
                #this assumes that the agents know the congestion periods
                prev_day, prev_mtu= self.model.clock.calc_timestamp_by_steps(self.model.schedule.steps -1, 0)
                if not self.model.red_obook.redispatch_demand_upward_all_df.empty:
                    red_demand_upward =self.model.red_obook.redispatch_demand_upward_all_df.loc[
                                    self.model.red_obook.redispatch_demand_upward_all_df['offer_daytime']==str((prev_day, prev_mtu))].copy()
                    red_demand_upward = red_demand_upward.groupby(by=['delivery_day', 'delivery_time']).first()
                else:
                    red_demand_upward= DataFrame(columns=['volume'])
                if not self.model.red_obook.redispatch_demand_downward_all_df.empty:
                    red_demand_downward =self.model.red_obook.redispatch_demand_downward_all_df.loc[
                            self.model.red_obook.redispatch_demand_downward_all_df['offer_daytime']==str((prev_day, prev_mtu))]
                    red_demand_downward = red_demand_downward.groupby(by=['delivery_day', 'delivery_time']).first()
                else:
                    red_demand_downward= DataFrame(columns=['volume'])
                red_demand =pd.concat([red_demand_upward['volume'],red_demand_downward['volume']], axis=1)

            for i in range(len(all_ids)):
                a = self.assets.loc[all_ids[i],:].item()
                #the following lists are required for blockorders
                startblocks =[[],[],[]]
                stopblocks = [[],[],[]]
                price_start_lst = []
                price_stop_lst= []
                if self.strategy['IDM_timing']=='instant':
                    if (self.strategy['IDM_volume']=='random')|(
                            self.strategy['IDM_volume']=='random_plus_cond_startstop'):
                        vol_up_lst = self.small_random_volume(a.schedule[['full_available_up','p_max_t']].loc[
                                    self.model.schedules_horizon.index].fillna(0))
                        vol_down_lst = self.small_random_volume(a.schedule[['full_available_down','p_max_t']].loc[
                                    self.model.schedules_horizon.index].fillna(0))
                    elif (self.strategy['IDM_volume']=='all_operational')|(
                            self.strategy['IDM_volume']=='all_plus_cond_startstop'):
                        vol_up_lst = list(a.schedule['full_available_up'].loc[
                                    self.model.schedules_horizon.index].fillna(0).astype(int))
                        vol_down_lst = list(a.schedule['full_available_down'].loc[
                                    self.model.schedules_horizon.index].fillna(0).astype(int))
                    else:
                        raise Exception('IDM volume strategy not known')
                    if (self.strategy['IDM_volume']=='random_plus_cond_startstop')|(
                            self.strategy['IDM_volume']=='all_plus_cond_startstop'):
                        #To the small random operational volume, start stop blocks are added
                        #store current asset schedule (excluding the past) for calculation of dispatch contraints from redispatch
                        a.schedule_at_redispatch_bidding= a.schedule.loc[self.model.schedules_horizon.index].copy()
                        av_cap = pd.concat([a.schedule.loc[self.model.schedules_horizon.index[gate_closure_MTU:]],
                                                           a.constraint_df.loc[self.model.schedules_horizon.index[
                                                                   gate_closure_MTU:],'upward_commit'].copy()], axis=1)

                        if not red_demand.empty:
                            #startblocks are only calculated if demand in previous step is not empty
                            startblocks, stopblocks = self.start_stop_blocks (av_cap, \
                               a.pmin, a.min_up_time, a.min_down_time,a.assetID)
                            #delete blocks that do not overlap with redispatch demand
                            for i in range(len(startblocks[0])-1,-1,-1):
                                #reverse range is used to delete from list without changing index
                                days, mtus = self.model.clock.calc_delivery_period_range(
                                               startblocks[0][i],
                                               startblocks[1][i],
                                               startblocks[2][i])
                                                                #add start day and MTU to the lists
                                days = [startblocks[0][i]]+days
                                mtus = [startblocks[1][i]]+mtus
                                if red_demand.loc[red_demand.index.isin(list(zip(days,mtus)))].empty:
                                    #remove from lists
                                    del startblocks[0][i]
                                    del startblocks[1][i]
                                    del startblocks[2][i]
                            for i in range(len(stopblocks[0])-1,-1,-1):
                                #reverse range is used to delete from list without changing index
                                days, mtus = self.model.clock.calc_delivery_period_range(
                                               stopblocks[0][i],
                                               stopblocks[1][i],
                                               stopblocks[2][i])
                                #add start day and MTU to the lists
                                days = [stopblocks[0][i]]+days
                                mtus = [stopblocks[1][i]]+mtus
                                if red_demand.loc[red_demand.index.isin(list(zip(days,mtus)))].empty:
                                    #remove from lists
                                    del stopblocks[0][i]
                                    del stopblocks[1][i]
                                    del stopblocks[2][i]
                        otype = 'IDCONS_order'

                    if self.strategy['IDM_pricing'] == 'srmc+-1':
                        price_up_lst = [int(a.srmc)+1] * len(dayindex)
                        price_down_lst = [int(a.srmc)-1] * len(dayindex)
                    elif (self.strategy['IDM_pricing'] == 'marginal_orderbook_strategy')|(
                            self.strategy['IDM_pricing'] == 'IDCONS_pricing'):
                        indiff_prices_up = self.get_opportunity_costs(
                               direction='upward', of_volumes = vol_up_lst,
                               asset = a,success_assumption = 'offered_volumes')
                        indiff_prices_down = self.get_opportunity_costs(
                               direction='downward', of_volumes = vol_down_lst,
                               asset = a,success_assumption = 'offered_volumes')

                        price_up_lst = self.intraday_markup(indiff_prices_up, 'sell')
                        price_down_lst = self.intraday_markup(indiff_prices_down, 'buy')
                        #slice list to consider gate closure time
                        price_up_lst = price_up_lst[gate_closure_MTU:]
                        price_down_lst = price_down_lst[gate_closure_MTU:]
                        if self.strategy['IDM_pricing'] == 'IDCONS_pricing':
                            #start stop prices under IDCONS include a partial call markup
                            price_start_lst, start_markup = self.startstop_markup(
                                    direction = 'upward', of_volumes = startblocks,
                                    asset = a, gct = gate_closure_MTU, partial_call=True)
                            price_stop_lst, stop_markup = self.startstop_markup(
                                    direction = 'downward', of_volumes = stopblocks,
                                    asset = a, gct = gate_closure_MTU, partial_call=True)
                        if self.strategy['IDM_volume']=='all_plus_cond_startstop':

                            # Ramping markups are not required for IDCONS unless large volumes are offered.
                            ramp_markup_up =self.ramping_markup(direction='upward',
                                                          of_volumes = vol_up_lst,
                                                          asset = a, return_markup=True)
                            ramp_markup_down =self.ramping_markup(direction='downward',
                                                          of_volumes = vol_down_lst,
                                                          asset = a, return_markup=True)
                            #add ramp_markups to price list (because large volumes are offered)
                            if len(ramp_markup_up[gate_closure_MTU:])==len(price_up_lst):
                                price_up_lst = [i[0] + i[1] for i in zip(
                                        ramp_markup_up[gate_closure_MTU:],price_up_lst)]
                            else:
                                import pdb
                                pdb.set_trace()
                            if len(ramp_markup_down[gate_closure_MTU:])==len(price_down_lst):
                                price_down_lst = [i[0] + i[1] for i in zip(
                                        ramp_markup_down[gate_closure_MTU:],price_down_lst)]
                            else:
                                import pdb
                                pdb.set_trace()
                    else:
                        raise Exception ('IDM pricing strategy not known')
                    length =len(dayindex) * 2 + len(startblocks[0]) + len(stopblocks[0])
                    #per order attribute a list over all agent assets is built
                    asset_location_lst += [a.location] * length
                    agentID_lst += [self.unique_id]* length
                    assetID_lst += [a.assetID]* length
                    init_lst += [init] * length
                    direction_lst += ['buy'] * len(dayindex) + ['sell'] *len(dayindex) +['sell'] * len(startblocks[0])+['buy'] * len(stopblocks[0])
                    ordertype_lst += [otype]* length
                    delivery_duration += [1] * len(dayindex) * 2 + startblocks[2] + stopblocks[2]
                    vol_lst += vol_down_lst[gate_closure_MTU:] + vol_up_lst[gate_closure_MTU:] + [a.pmin] *(
                            len(startblocks[0]) + len(stopblocks[0]))
                    price_lst += price_down_lst + price_up_lst + price_start_lst + price_stop_lst
                    day_lst += dayindex * 2 + startblocks[0] + stopblocks[0]
                    mtu_lst += timeindex * 2 + startblocks[1] + stopblocks[1]
                else:
                    raise Exception('IDM timing strategy not known')

            #place market orders for the imbalance position
            if (self.trade_schedule['imbalance_position'].fillna(value=0).astype(int)!=0).any():
                print ('making market orders caused by imbalance')
                """market orders to mitigate imbalance risk have an administrative order price. """

                imb = DataFrame(columns=['imbalance_position','direction','price'])
                imb['imbalance_position'] = self.trade_schedule['imbalance_position'].fillna(value=0)
                imb = imb.loc[imb['imbalance_position'] !=0].copy()
                #filter out all imbalance of past delivery MTUs inlcuding gate closure time
                mask= imb.index.isin(self.model.schedules_horizon.iloc[gate_closure_MTU:].index)
                imb = imb.loc[mask].copy()

                imb['direction'] = None
                imb['price'] = None

                #try to sell for a long imbalance position
                imb.loc[imb['imbalance_position']>0, 'direction']= 'sell'
                 #try to buy for a short imbalance position
                imb.loc[imb['imbalance_position']<0, 'direction']= 'buy'
                 #imbalance price for buy is positive IB risk price, for sell is negative IB risk price
                imb.loc[imb['imbalance_position']>0, 'price']= -self.imbalance_risk_price
                imb.loc[imb['imbalance_position']<0, 'price']= self.imbalance_risk_price
                if (self.strategy['IBM_volume']=='random'):
                    # make negative (short) positions positive buy volume values
                    #price is only provided
                    imb.loc[imb['imbalance_position']>0, 'imbalance_position']= self.small_random_volume(
                            imb.loc[imb['imbalance_position']>0, ['imbalance_position','price']])
                    imb.loc[imb['imbalance_position']<0, 'imbalance_position']= self.small_random_volume(
                            imb.loc[imb['imbalance_position']<0, ['imbalance_position','price']].abs())
                elif (self.strategy['IBM_volume']=='all'):
                    # make negative (short) positions positive buy volume values
                    imb['imbalance_position']= imb['imbalance_position'].abs()


                if ((self.strategy['IBM_volume']=='all')|(self.strategy['IBM_volume']=='random'))&(
                        self.strategy['IBM_pricing']=='IB_price')&(
                        self.strategy['IBM_timing']=='instant'):
                    #make a 'market order'. imbalances <abs(1) are ignored
                    #per order attribute add to list
                    imb['imbalance_position'] = imb['imbalance_position'].astype(int)
                    vol_lst += list(imb['imbalance_position'])
                    direction_lst += list(imb['direction'])
                    price_lst +=list(imb['price'])
                    day_lst += list(imb.index.get_level_values(0))
                    mtu_lst += list(imb.index.get_level_values(1))
                    asset_location_lst += ['anywhere'] * len(imb)
                    agentID_lst += [self.unique_id] * len(imb)
                    assetID_lst += ['imbalance'] * len(imb)
                    init_lst += [init] * len(imb)
                    ordertype_lst += ['market_order'] * len(imb)
                    delivery_duration += [1] * len(imb)


                elif (self.strategy['IBM_volume']=='impatience_curve')&(self.strategy['IBM_pricing']=='ID_markup')&(
                        self.strategy['IBM_timing']=='impatience_curve'):
                    """ agents with imbalance provide partly market and partly limit orders,
                      depending on the time before delivery"""
                    #impatience curve
                    imp_curve= DataFrame()
                    #todo make this a parameter
                    #this impatient curve is shaped like cumulated ID trade volumes before delivery in NL (2016)
                    imp_curve['mtu_before_delivery'] = [8,12,16,20,24,28,32,36,40,2*96]
                    imp_curve['offer_share_market_orders'] =[1,0.85,0.7,0.5,0.4,0.3,0.25,0.2,0.15,0.1]

                    #add new columns for market orde (MO) volume and limit order (LO) volume
                    imb['MO_vol']=None
                    imb['LO_vol']=None
                    for i in range(len(imp_curve)):

                        if i == 0:
                            lt_idx = self.model.schedules_horizon.index.values[:imp_curve['mtu_before_delivery'].iloc[i]]
                        else:
                            lt_idx =  self.model.schedules_horizon.index.values[imp_curve[
                                    'mtu_before_delivery'].iloc[i-1]:imp_curve['mtu_before_delivery'].iloc[i]]
                        imb.loc[imb.index.isin(lt_idx), 'MO_vol']=imb.loc[imb.index.isin(lt_idx), 'imbalance_position'
                                ] *imp_curve['offer_share_market_orders'].iloc[i]
                        imb.loc[imb.index.isin(lt_idx), 'LO_vol']=imb.loc[imb.index.isin(lt_idx), 'imbalance_position'
                                ] *(1-imp_curve['offer_share_market_orders'].iloc[i])
                    #make a volume list (must be in shape of schedules_horizon)
                    imb_LO_vol =self.model.schedules_horizon.copy()
                    imb_LO_vol['commit'] = imb_LO_vol['commit'].add(imb['LO_vol'], fill_value=0)
                    vol_down_lst =list(imb_LO_vol['commit'].abs().where(imb_LO_vol['commit'] < 0, 0).astype(int))
                    vol_up_lst = list(imb_LO_vol['commit'].where(imb_LO_vol['commit'] > 0, 0).astype(int))
                    #for the pricing of the limit orders, the expected imbalance price is taken as indifference price.
                    #The the ID price markup is calculated, BASED ON THE EXP IBP
                    price_up_lst = self.intraday_markup(list(self.model.rpt.eIBP['expected_IBP_long']), 'sell')
                    price_down_lst = self.intraday_markup(list(self.model.rpt.eIBP['expected_IBP_short']), 'buy')
                    #slice list to consider gate closure time
                    price_up_lst = price_up_lst[gate_closure_MTU:]
                    price_down_lst = price_down_lst[gate_closure_MTU:]
                    #add market orders to atriibute lists
                    vol_lst += list(imb['MO_vol'].abs().astype(int))
                    direction_lst += list(imb['direction'])
                    price_lst +=list(imb['price'])
                    day_lst += list(imb.index.get_level_values(0))
                    mtu_lst += list(imb.index.get_level_values(1))
                    asset_location_lst += ['anywhere'] * len(imb)
                    agentID_lst += [self.unique_id] * len(imb)
                    assetID_lst += ['imbalance'] * len(imb)
                    init_lst += [init] * len(imb)
                    ordertype_lst += ['market_order'] * len(imb)
                    delivery_duration += [1] * len(imb)

                    #add limit orders to atriibute lists
                    length =len(dayindex) * 2
                    #per order attribute a list over all agent assets is built
                    asset_location_lst += ['anywhere'] * length
                    agentID_lst += [self.unique_id]* length
                    assetID_lst += ['imbalance']* length
                    init_lst += [init] * length
                    direction_lst += ['buy'] * len(dayindex) + ['sell'] *len(dayindex)
                    ordertype_lst += ['limit_order']* length
                    delivery_duration += [1] * length
                    vol_lst += vol_down_lst[gate_closure_MTU:] + vol_up_lst[gate_closure_MTU:]
                    price_lst += price_down_lst + price_up_lst
                    day_lst += dayindex * 2
                    mtu_lst += timeindex * 2


                else:
                    raise Exception ('Imbalance strategy (combination) not known')

            #make order dataframe from lists
            orders = DataFrame()
            columns=['agent_id','associated_asset','delivery_location',
                     'volume','price', 'delivery_day','delivery_time',
                     'order_type','init_time', 'direction' , 'delivery_duration']
            values = [agentID_lst,assetID_lst, asset_location_lst,
                      vol_lst, price_lst, day_lst, mtu_lst,
                      ordertype_lst, init_lst, direction_lst, delivery_duration]

            #make dataframe per column to maintain datatype of lists (otherwise seen as objects by pandas)
            for i in range(len(columns)):
                orders[columns[i]]=values[i].copy()
            #remove 0 MW rows
            orders = orders.loc[orders['volume']!=0].copy()

            if not orders.empty:
                # insert order IDs (must be at second last column because of many dependencies)
                orders.insert(loc = len(orders.columns)-2,column='order_id',
                              value =list(range(self.ordercount, self.ordercount + len(orders))) )
                orders['order_id']=orders['agent_id'] + orders['associated_asset'] + orders['order_id'].astype(str)

                #order count for the order ID
                self.ordercount += len(orders)
                order_message = OrderMessage(orders.copy())
                self.model.IDM_obook.add_order_message(order_message)
                if not (orders['order_type']== 'IDCONS_order').empty:
                    #In case of IDCONS orders  these orders need to stored in the redispatch orderbook
                    #as well for redispatch purposes
                    self.model.red_obook.add_order_message(OrderMessage(orders.loc[
                            orders['order_type']== 'IDCONS_order', orders.columns]))

                #make ID bid triggerst immediate ID clearing
                self.model.ID_marketoperator.clear_settle_intraday(for_agent_id =self.unique_id)

    def intraday_markup(self, indiff_price_lst, direction, profit_margin_pu = 0.1):
        """this method provides a heuristic mark-up for intraday orders to a open order book.
           in case the indifference price (costs price including opportunity cost) is extra marginal
           (meaning the order will not be cleared instantanously), the order price is set to the next
           more expensive order plus 1 Euro (in case of buy orders), respectively minus 1 euro (in case of sell order).
           If the indifference price is intra-marginal (will be cleared instantanously), then the indifference
           price plus a standard margin will be offered.
           In case of extra-marginal indifference prices where no competing orders orders exist
           the last cleared price is taken (when higher/lower than indifference price).

           profit_margin is in p.u. ( 0.1 means 10% profit markup on indifference prices)
        """

        #make Series with time index from price list (note: the price_list must be in shape of schedules_horizon)
        indiff_price = Series(indiff_price_lst, index=self.model.schedules_horizon.index)
        price_list = indiff_price.copy()
        price_list.loc[:] = np.nan
        buyorders = self.model.IDM_obook.buyorders[['delivery_day','delivery_time','price']].copy()
        sellorders = self.model.IDM_obook.sellorders[['delivery_day','delivery_time','price']].copy()

        #extra-marginal price setting
        if direction == 'buy':
                for timestamp ,orders_t in buyorders.groupby(by=['delivery_day','delivery_time']):
                   competing_price =orders_t['price'].loc[orders_t['price'] < indiff_price[timestamp]].max()
                   if (~math.isnan(competing_price))&(competing_price + 1 < indiff_price[timestamp]):
                       price_list[timestamp] = competing_price + 1

        elif direction == 'sell':
            for timestamp ,orders_t in sellorders.groupby(by=['delivery_day','delivery_time']):
               competing_price = orders_t['price'].loc[orders_t['price'] > indiff_price[timestamp]].min()
               if (~math.isnan(competing_price))&(competing_price - 1 > indiff_price[timestamp]):
                   price_list[timestamp] = competing_price - 1

        #intra-marginal price setting
        if direction == 'buy':
            for timestamp ,orders_t in sellorders.groupby(by=['delivery_day','delivery_time']):
                if (orders_t['price'] <= indiff_price[timestamp]* (1 - profit_margin_pu)).any():
                    price_list[timestamp] = indiff_price[timestamp]* (1 - profit_margin_pu)
        elif direction == 'sell':
            for timestamp ,orders_t in buyorders.groupby(by=['delivery_day','delivery_time']):
                if (orders_t['price'] >= indiff_price[timestamp] * (1 + profit_margin_pu)).any():
                    price_list[timestamp] = indiff_price[timestamp] * (1 + profit_margin_pu)

       #empty orderbook (possibly just fully matched, but possibly just empty)
        if direction == 'buy':
            prev_highest_cleared = self.model.IDM_obook.rep_dict['cleared_buy_min_price']
        elif direction == 'sell':
            prev_highest_cleared = self.model.IDM_obook.rep_dict['cleared_sell_max_price']
        missing_prices = price_list.loc[price_list.isnull().values]
        for i in range(len(missing_prices)):
            day = missing_prices.index.get_level_values(0)[i]
            mtu = missing_prices.index.get_level_values(1)[i]
            prev_prices = prev_highest_cleared.loc[:,(day,mtu)]
            last_highest_price = prev_prices[prev_prices.notnull().values]
            if direction == 'sell':
                if not last_highest_price.empty:
                    last_highest_price =last_highest_price.iloc[-1].copy()
                    if last_highest_price > indiff_price[(day, mtu)] *(1 + profit_margin_pu):
                        price_list.loc[(day,mtu)] = last_highest_price
                    else:
                        price_list.loc[(day,mtu)] = indiff_price[(day, mtu)] *(1 + profit_margin_pu)
                else:
                    price_list.loc[(day,mtu)] = indiff_price[(day, mtu)] *(1 + profit_margin_pu)
            elif direction == 'buy':
                 if not last_highest_price.empty:
                    last_highest_price =last_highest_price.iloc[-1].copy()
                    if last_highest_price < indiff_price[(day, mtu)] *(1 - profit_margin_pu):
                        price_list.loc[(day,mtu)] = last_highest_price
                    else:
                        price_list.loc[(day,mtu)] = indiff_price[(day, mtu)] *(1 - profit_margin_pu)
                 else:
                    price_list.loc[(day,mtu)] = indiff_price[(day, mtu)] *(1 - profit_margin_pu)
        price_list = price_list.round(0).astype(int).copy()
        return (list(price_list.values))



    def BE_makebid(self):
        if self.model.exodata.sim_task.loc[0,'run_BEM[y/n]']=='n':
           pass
        else:
            if (self.strategy['BEM_timing']=='at_gate_closure')|(
                    self.strategy['BEM_volume']=='available_ramp')|(
                            self.strategy['BEM_pricing']=='srmc'):
                print("Agent {} makes BE bids".format(self.unique_id))
                #first delete all redispatch orders from previous round from orderbook
                self.model.BEM_obook.delete_orders(agent_id_orders = self.unique_id)
                asset_location_lst = []
                agentID_lst = []
                assetID_lst =[]
                init_lst = []
                direction_lst = []
                ordertype_lst = []
                vol_lst=[]
                price_lst=[]
                day_lst=[]
                mtu_lst=[]
                delivery_duration =[]
                gate_closure_MTU = self.model.BE_marketoperator.gate_closure_time
                if gate_closure_MTU <len(self.model.schedules_horizon):
                    dayindex = list(self.model.schedules_horizon.index.get_level_values(0))[gate_closure_MTU]
                    timeindex = list(self.model.schedules_horizon.index.get_level_values(1))[gate_closure_MTU]
                else:
                    #gate closure time is out of range of simulation. no bids are made
                    return
                otype = 'FRR_order'
                #init means simulation mtu plus agent step rank. works for up to 100 agents.
                init = self.step_rank/100 +self.model.clock.get_MTU()
                #get all assets of that market party
                all_ids = self.assets.index.values
                for i in range(len(all_ids)):
                    a = self.assets.loc[all_ids[i],:].item()
                    if  ((a.schedule.loc[(dayindex,timeindex),
                                        'rem_ramp_constr_avail_up'] < 0).any())|((a.schedule.loc[(dayindex,timeindex),
                                        'rem_ramp_constr_avail_down']<0).any()):
                        aa=a.schedule
                        import pdb
                        pdb.set_trace()
                    #offers remaining ramp
                    vol_up_lst = [a.schedule.loc[(dayindex,timeindex),
                                        'rem_ramp_constr_avail_up'].astype(int)]
                    vol_down_lst = [a.schedule.loc[(dayindex,timeindex),
                                        'rem_ramp_constr_avail_down'].astype(int)]
                    price_up_lst = [int(a.srmc)]
                    price_down_lst = [int(a.srmc)]

                    asset_location_lst += [a.location]*2
                    agentID_lst += [self.unique_id]*2
                    assetID_lst += [a.assetID]*2
                    init_lst += [init]*2
                    direction_lst += ['buy'] + ['sell']
                    ordertype_lst += [otype]* 2
                    delivery_duration += [1] * 2
                    vol_lst += vol_down_lst + vol_up_lst
                    price_lst += price_down_lst + price_up_lst
                    day_lst += [dayindex] * 2
                    mtu_lst += [timeindex] * 2

                #make order dataframe from lists
                orders = DataFrame()
                columns=['agent_id','associated_asset','delivery_location',
                         'volume','price', 'delivery_day','delivery_time',
                         'order_type','init_time', 'direction' , 'delivery_duration']
                values = [agentID_lst,assetID_lst, asset_location_lst,
                          vol_lst, price_lst, day_lst, mtu_lst,
                          ordertype_lst, init_lst, direction_lst, delivery_duration]

                #make dataframe per column to maintain datatype of lists (otherwise seen as objects by pandas)
                for i in range(len(columns)):
                    orders[columns[i]]=values[i].copy()
                #remove 0 MW rows
                orders = orders.loc[orders['volume']!=0].copy()

                if not orders.empty:
                    # insert order IDs (must be at second last column because of many dependencies)
                    orders.insert(loc = len(orders.columns)-2,column='order_id',
                                  value =list(range(self.ordercount, self.ordercount + len(orders))) )
                    orders['order_id']=orders['agent_id'] + orders['associated_asset'] + orders['order_id'].astype(str)

                    #order count for the order ID
                    self.ordercount += len(orders)
                    order_message = OrderMessage(orders.copy())
                    self.model.BEM_obook.add_order_message(order_message)
            else:
                raise Exception ('Balancing energy market strategy not known')



    def small_random_volume(self, available_volume, min_volume = 5, max_volume= 20):
        """this method provides a random volume, under consideration of the min and max available volume.
           If min and max of a timestamp are equivalent, then the random volume is the same.
           It returns a list. note that no volumes <1 are provided, even when available.
           input is a Series, output is a list
           """
        if available_volume.empty:
            return

        available_volume['min_vol'] = available_volume.iloc[:,0].where(available_volume.iloc[:,0]<min_volume, min_volume)
        available_volume['max_vol'] = available_volume.iloc[:,0].where(available_volume.iloc[:,0]<max_volume, max_volume)
        available_volume['rand_vol'] = int(0)
        #make small available volumes for the 'random volume' to avoid unused capacity.
        available_volume['rand_vol'] = available_volume['rand_vol'].where(
                available_volume['min_vol']<available_volume['max_vol'],available_volume.iloc[:,0].astype(int).values)

        for available, group in available_volume.loc[(available_volume['rand_vol'] == 0)&(
                available_volume['max_vol'] - available_volume['min_vol'] >= 1)].groupby(
                by = ['min_vol','max_vol']):

            #make a random seed that is linked to the randomness of agent rank
            seed= self.step_rank + self.model.schedule.steps
            available_volume.loc[group.index,'rand_vol'] = np.random.RandomState(seed
                                ).randint(group['min_vol'].iloc[0], group['max_vol'].iloc[0])

        if available_volume['rand_vol'].isnull().any():
            import pdb
            pdb.set_trace()
        return (list(available_volume['rand_vol']))

    def start_stop_blocks (self, av_cap, pmin, min_up_time, min_down_time, assetID):
        """this method identifies consecutive MTUs of asset commitment at pmin
            or at 0 MW. These can be used for start or stop orders if these periods
            are >= min_up_time or min_down_time.
            Assumption of this method: if a period is < 2 * min_up_time or min_down_time
            then the entire period is offered in one order. When larger than
            2 * min_up_time or min_down_time, then blocks of min_up_time or down_time are placed
            The method returns nested lists instead of DataFrames to be consistent with
            list approach of make_bid methods (is faster than append to DF)
        """

        if (pmin == 0) | (av_cap.empty):
            #no dedicated stop pr start orders needed because the full range can be provided.
            #Also if available capacity is empty.
            #empty nested list return
            return([[],[],[]],[[],[],[]])

        def count_if_value(x,value):
            """x is pandas.rolling object"""
            amount = np.count_nonzero(np.where(x == value,1,0))
            return(amount)

        #avoid that outages lead and stop commitments lead to new startblocks.
        av_cap['commit'] = av_cap['commit'].where(av_cap['p_max_t']!=0, -1)
        av_cap['commit'] = av_cap['commit'].where(~((av_cap['commit']==pmin)&(av_cap['upward_commit']!=0)), -1)
        av_cap.reset_index(inplace=True)

        gate_closure_time = (av_cap['delivery_day'].iloc[0], av_cap['delivery_time'].iloc[0])
        av_cap['feasible_startblock'] =av_cap['commit'].rolling(window=min_up_time).apply(
                lambda x: count_if_value(x,0))
        av_cap['del_time_startblock'] = av_cap.apply(lambda x: self.model.clock.calc_delivery_period_end(
                (x['delivery_day'],x['delivery_time']), -min_up_time+2),axis=1)
        av_cap['feasible_startblock'] =av_cap['feasible_startblock'].where(
                av_cap['del_time_startblock']>=gate_closure_time, np.nan)

        av_cap['feasible_stopblock'] =av_cap['commit'].rolling(window=min_down_time).apply(
                lambda x: count_if_value(x,pmin))
        av_cap['del_time_stopblock'] = av_cap.apply(lambda x: self.model.clock.calc_delivery_period_end(
                (x['delivery_day'],x['delivery_time']), -min_down_time+2),axis=1)
        av_cap['feasible_stopblock'] =av_cap['feasible_stopblock'].where(
                av_cap['del_time_startblock']>=gate_closure_time, np.nan)
        i =0
        startdelday=[]
        startdeltime =[]
        startduration =[]
        stopdelday =[]
        stopdeltime =[]
        stopduration =[]

        while i < len(av_cap):
            if av_cap['feasible_startblock'].iloc[i] == min_up_time:
                if  i + min_up_time-1 >= len(av_cap) -1:
                    if av_cap['feasible_startblock'].iloc[len(av_cap)-1] == min_up_time:
                        startduration += [min_up_time-1 + (len(av_cap) -i)]
                        startdelday += [int(av_cap['del_time_startblock'].iloc[i][0])]
                        startdeltime += [int(av_cap['del_time_startblock'].iloc[i][1])]
                        i += len(av_cap)-i
                    else:
                        #continue to last feasible startblock
                        k = 1
                        while av_cap['feasible_startblock'].iloc[i +k]==min_up_time:
                            k += 1
                        startduration += [min_up_time -1 + k]
                        startdelday += [int(av_cap['del_time_startblock'].iloc[i][0])]
                        startdeltime += [int(av_cap['del_time_startblock'].iloc[i][1])]
                        i += k
                elif av_cap['feasible_startblock'].iloc[i + min_up_time-1] == min_up_time:
                    startduration += [min_up_time]
                    startdelday += [int(av_cap['del_time_startblock'].iloc[i][0])]
                    startdeltime += [int(av_cap['del_time_startblock'].iloc[i][1])]
                    i += min_up_time
                else:
                    #continue to last feasible startblock
                    k = 1
                    while av_cap['feasible_startblock'].iloc[i +k]==min_up_time:
                        k += 1
                    startduration += [min_up_time -1 + k]
                    startdelday += [int(av_cap['del_time_startblock'].iloc[i][0])]
                    startdeltime += [int(av_cap['del_time_startblock'].iloc[i][1])]
                    i += k

            elif av_cap['feasible_stopblock'].iloc[i] == min_down_time:
        #        import pdb
        #        pdb.set_trace()
                if  i + min_down_time-1 >= len(av_cap)-1:
                    if av_cap['feasible_stopblock'].iloc[len(av_cap)-1] == min_down_time:
                        stopduration += [min_down_time -1 + (len(av_cap) -i)]
                        stopdelday += [int(av_cap['del_time_stopblock'].iloc[i][0])]
                        stopdeltime += [int(av_cap['del_time_stopblock'].iloc[i][1])]
                        i += len(av_cap)-i
                    else:
                        #continue to last feasible stopblock
                        k = 1
                        while av_cap['feasible_stopblock'].iloc[i +k] == min_down_time:
                            k += 1
                        stopduration += [min_down_time -1 + k]
                        stopdelday += [int(av_cap['del_time_stopblock'].iloc[i][0])]
                        stopdeltime += [int(av_cap['del_time_stopblock'].iloc[i][1])]
                        i += k

                elif av_cap['feasible_stopblock'].iloc[i + min_down_time-1] == min_down_time:
                    stopduration += [min_down_time]
                    stopdelday += [int(av_cap['del_time_stopblock'].iloc[i][0])]
                    stopdeltime += [int(av_cap['del_time_stopblock'].iloc[i][1])]
                    i += min_down_time
                else:
                    #continue to last feasible stopblock
                    k = 1
                    while av_cap['feasible_stopblock'].iloc[i +k]==min_down_time:
                        k += 1
                    stopduration += [min_down_time -1 + k]
                    stopdelday += [int(av_cap['del_time_stopblock'].iloc[i][0])]
                    stopdeltime += [int(av_cap['del_time_stopblock'].iloc[i][1])]
                    i += k
            else:
                i+=1
        return ([startdelday,startdeltime,startduration], [stopdelday, stopdeltime, stopduration])


    def get_opportunity_costs(self, direction='upward', of_volumes = None, asset = None, success_assumption=None ):
        """returns a list of prices for the schedule horizon including the opportunity markup
        assumption that market time unit of the volumes is 15 minutes. meaning the volume is devided by 4 to get the EUR/MWh.
        Note that only order duration == 1 MTU (15 minutes) is considered"""

        if self.model.rpt.DAM_prices.empty:
            print('no day-ahead prices available. Possibly because DAM is not run.')
            print('Default DA price of 30 EUR/MWh used for (Dutch) imbalance clearing')
            DAP= 30
            MTU =list(self.model.schedules_horizon.index.get_level_values(1))
            DAP= [30] * len(MTU)
        else:
            DAP = self.model.rpt.DAM_prices.loc[self.model.schedules_horizon.index].copy()
            MTU = list(DAP.index.get_level_values(1))
            DAP =list(DAP.iloc[:,0])
        #MTU of hour list needed to get the specific opportunity cost distribution function
        MTU_of_h = []
        for mtu in MTU:
            mtu_of_h = mtu%4
            if mtu_of_h == 0:
                mtu_of_h=4
            MTU_of_h += [mtu_of_h]

#        DAP = list(DAP.iloc[:,0])
        intrinsic_values = []
        if direction == 'upward':
            #for sell orders, the opportunity is that part of
            #   this upward capacity is rewarded with the imbalance price for long,
            #   because additional production/less consumption leads to a long imbalance position
            IBP = 'IB_price_long'
            ramp= asset.ramp_limit_up * asset.pmax #maximum MW difference from one mtu to next.
            direction_factor = 1
        elif direction == 'downward':
            IBP = 'IB_price_short'
            ramp= asset.ramp_limit_down * asset.pmax #maximum MW difference from one mtu to next.
            #he opportunity mark_up is deducted from srmc for the downward (buy) orders
            direction_factor = -1
        else:
            raise Exception ('direction not known, must be upwarda or downwards')

        for p in range(len(DAP)):
            odf = self.model.exodata.opportunity_costs_db
            #the opportunity costs reflect expected EUR/MWh, not saying how much MW is likely to be sold.
            if asset.srmc > odf['K-value'].max():
                K = odf['K-value'].max()
            elif asset.srmc < odf['K-value'].min():
                K = odf['K-value'].min()
            else:
                K = asset.srmc

            try:
                value =odf.loc[(odf['price_data']==IBP) & (odf['PTU_of_an_hour']==MTU_of_h[p]) & (
                        odf['DAP_left_bin']<=DAP[p]) & (odf['DAP_right_bin(excl)'] >DAP[p] ) & (
                                odf['K-value'] == K),'Opp_costs_for_K'].iloc[0]
            except:
                import pdb
                pdb.set_trace()
            intrinsic_values += [value]

        #VOLUME CORRECTION: compare available volume to max ramp volume according to different assumptions

        df = DataFrame()
        df['intrinsic_values'] = intrinsic_values #EUR/MWh
        df['offered_volumes'] = of_volumes #MW per mtu
        #linear ramp assumption
        df['max_ramp_direct_activation'] = ramp/2 #max average MW per mtu
        #linear ramp assumption
        df['max_ramp_mtu-1_activation'] = ramp #max average MW per mtu

        if success_assumption=='max_ramp_direct_activation':
            df['rewarded_volume'] =df[
                    'max_ramp_direct_activation'].where(df[
                            'max_ramp_direct_activation']<df['offered_volumes'],df['offered_volumes'])
        elif success_assumption=='offered_volumes':
            df['rewarded_volume'] =df['offered_volumes']

        elif success_assumption=='max_ramp_mtu-1_activation':
            df['rewarded_volume'] =df[
                    'max_ramp_mtu-1_activation'].where(df[
                            'max_ramp_mtu-1_activation']<df['offered_volumes'],df['offered_volumes'])
        #calculate opporunity cost (EUR!)
        df['opp_cost']=df['rewarded_volume'] * df['intrinsic_values']/4
        #calculate the opportunity cost markup (EUR/MWh) for the offered volume
        #assumption: disregarding risk of partial order clearing and delivery duration>1.
        df['opp_price_markup'] = df['opp_cost']/df['offered_volumes']
        df['order_price'] = direction_factor * df['opp_price_markup'] + asset.srmc
        mask = np.isnan(df['order_price'])
        df.loc[~mask, 'order_price'] =df.loc[~mask,'order_price'].round(0)
        #make np. nan to 0. these orders are filetered out anyway because no 0MW orders are allowed.
        df.loc[mask, 'order_price'] = 0
        df['order_price']=df['order_price'].astype(int).copy()
        return(list(df['order_price']))



    def startstop_markup (self, direction='upward', of_volumes = None,
                          asset = None, gct = None, partial_call = False,
                          order_granularity= 1, minimum_call = 1):
        """this method provides a list of startstop markups AND markup for partial call.
        - orders for start-stop periods do not contain opportunity mark_ups
          because it is assumed that these volumes can not be sold on BEM, and IBM.
        - it is assumed that start stop orders have the volume pmin
        - the start stop offers are provided in form of nested list [[day],[time],[duration]]
        - method provides both, a list of markups and a list of prices inlcuding the markups
        - if partial_call is True, the start stop markup also contains a partial call markup
          Partial call risk considers missing fixed start stop cost and additional imbalance.
          order granularity (MW) and minimum call (MW) determine the considered partial call scenarios
        - assumed probability for various partial call scenario's is a uniform discrete distribution.
          Furthermore it is assumed that order granularity and minimum call, as well as offered
          volume are natural numbers
        """
        if not of_volumes[0]:
            #if no start stop blocks are avaiable empty lists are returned
            return([],[])

        srmc = asset.srmc #eur/mwh
        pmax = asset.pmax #MW
        pmin = asset.pmin #MW
        ramp_limit_up = asset.ramp_limit_up #p.u. of pmax per isp
        ramp_limit_down = asset.ramp_limit_down
        ramp_limit_start_up = asset.ramp_limit_start_up # p.u. pmax per ISP
        ramp_limit_shut_down = asset.ramp_limit_shut_down # p.u. pmax per ISP
        start_up_cost = asset.start_up_cost #eur
        shut_down_cost =  asset.shut_down_cost
        min_down_time = asset.min_down_time #ISPs
        min_up_time = asset.min_up_time

        #excepted imbalance prices
        eIBP = self.model.rpt.eIBP.loc[self.model.schedules_horizon.index[gct:]]
        av_cap = asset.schedule.loc[self.model.schedules_horizon.index[gct:]].copy()

        if ((av_cap['commit'] < pmin )&(av_cap['commit']>0)).any():
            import pdb
            pdb.set_trace()
            raise Exception('this method works only correctly in the absence of scheduled dispatch >pmin or 0')
        if pmin < 1:
            #this method does'nt work and makes no sense
            return([],[])

        #get expected imbalance prices for the known DAP
        av_cap = pd.concat([av_cap,eIBP[['expected_IBP_short','expected_IBP_long']]], axis=1)
        av_cap.reset_index(inplace=True)

        markup_lst = []
        offer_price_lst = []
        for b in range(len(of_volumes[0])):
            av_cap['required_ramp'] = 0
            av_cap['scheduled_startstop'] = 0
            av_cap['imb_from_startstop'] = 0
            av_cap['adjusted_commit'] = 0
            delivery_day = of_volumes[0][b]
            delivery_mtu = of_volumes[1][b]
            delivery_duration = of_volumes[2][b]
            startrow = av_cap.loc[(av_cap['delivery_day'] == delivery_day)&(
                    av_cap['delivery_time'] == delivery_mtu)].index[0]
            if direction == 'downward':
                min_time = min_down_time
                endrow = startrow + max(delivery_duration, min_time)
                starttime = int(pmin/(pmax *ramp_limit_shut_down))
                stoptime =int(pmin/(pmax *ramp_limit_start_up))
                offer_dispatch = 0
            elif direction == 'upward':
                min_time = min_up_time
                endrow = startrow + max(delivery_duration, min_time)
                starttime = int(pmin/(pmax * ramp_limit_start_up))
                stoptime =int(pmin/(pmax * ramp_limit_shut_down))
                offer_dispatch = pmin
            else:
                raise Exception ('direction must be "upward" (for start offers) and "downward" for stop offers')
            #ensure that out of schedule_horizon startstop times are ignored
            if startrow - starttime < 0:
                starttime = startrow
            if endrow + stoptime > len(av_cap):
                stoptime = len(av_cap) - endrow

            #THE BEGIN DISPATCH
            pre_ramp=[]
            pre_sched_ramp=[]
            pre_imb=[]
            post_ramp=[]
            post_sched_ramp =[]
            post_imb=[]
            pre_overlap = 0
            post_overlap= 0
            saved_start_ramp = False
            saved_stop_ramp =False
            #determine required ramp, fuel and imbalance
            if direction == 'upward':
                pre_ramp=[ramp_limit_start_up * pmax * t for t in range(1,starttime)]
                post_ramp=[pmin -ramp_limit_shut_down * pmax * t for t in range(1,stoptime)]
                if (av_cap['commit'].iloc[startrow - starttime:startrow] >=pmin).any():
                    #get first value !=0
                    pre_first_commit=(av_cap[['delivery_day','delivery_time','commit']].iloc[
                            startrow  - starttime:startrow]).loc[
                            (av_cap['commit'].iloc[startrow - starttime :startrow]  >=pmin)].iloc[-1]
                    saved_stop_ramp = True
                    pre_sched_ramp = [pmin - ramp_limit_shut_down * pmax * t for t in range(1,stoptime)]
                    pre_overlap = startrow - av_cap.loc[(av_cap['delivery_day']==pre_first_commit['delivery_day'])&(
                            av_cap['delivery_time']==pre_first_commit['delivery_time'])].index[0] - 1
                    pre_imb = [pmin - sr for sr in  pre_sched_ramp[:pre_overlap]]
                elif (av_cap['commit'].iloc[startrow - starttime -  stoptime +1 :startrow]  >=pmin).any():
                    #get first value !=0
                    pre_first_commit=(av_cap[['delivery_day','delivery_time','commit']].iloc[
                            startrow  - starttime -  stoptime +1 :startrow]).loc[
                            (av_cap['commit'].iloc[startrow - starttime -  stoptime +1:startrow]  >=pmin)].iloc[-1]
                    saved_stop_ramp = True
                    pre_sched_ramp = [pmin - ramp_limit_shut_down * pmax * t for t in range(1,stoptime)]
                    pre_overlap = startrow - av_cap.loc[(av_cap['delivery_day']==pre_first_commit['delivery_day'])&(
                            av_cap['delivery_time']==pre_first_commit['delivery_time'])].index[0] - 1
                    pre_imb = [pmin - sr for sr in  pre_sched_ramp[:pre_overlap]]
                else:
                    saved_stop_ramp = False
                    pre_ramp =[ramp_limit_start_up * pmax * t for t in range(1,starttime)]
                    pre_imb = pre_ramp

                if (av_cap['commit'].iloc[endrow :endrow+ stoptime - 1] !=0).any():
                    #get first value !=0
                    post_first_commit=(av_cap[['delivery_day','delivery_time','commit']].iloc[
                            endrow :endrow + stoptime-1]).loc[
                            (av_cap['commit'].iloc[endrow :endrow+ stoptime - 1] !=0)].iloc[0]
                    saved_start_ramp = True
                    post_sched_ramp = [ramp_limit_start_up * pmax * t for t in range(1,starttime)]
                    post_overlap = av_cap.loc[(av_cap['delivery_day'] == post_first_commit['delivery_day'])&(
                            av_cap['delivery_time']==post_first_commit['delivery_time'])].index[0] - endrow
                    post_imb = [pmin - sr for sr in  post_sched_ramp[-post_overlap :]]

                elif (av_cap['commit'].iloc[endrow :endrow+ stoptime - 1 + starttime -1] !=0).any():
                    #get first value !=0
                    post_first_commit=(av_cap[['delivery_day','delivery_time','commit']].iloc[
                            endrow :endrow + stoptime-1+ starttime -1]).loc[
                            (av_cap['commit'].iloc[endrow :endrow+ stoptime - 1 + starttime -1] !=0)].iloc[0]
                    saved_start_ramp = True
                    post_sched_ramp = [ramp_limit_start_up * pmax * t for t in range(1,starttime)]
                    post_overlap = av_cap.loc[(av_cap['delivery_day'] == post_first_commit['delivery_day'])&(
                            av_cap['delivery_time']==post_first_commit['delivery_time'])].index[0] - endrow
                    post_imb = [pmin - sr for sr in  post_sched_ramp[-post_overlap:]]
                else:
                    saved_start_ramp = False
                    post_imb = post_ramp
                if delivery_duration < min_time:
                    min_time_fuel = [pmin] * (min_time - delivery_duration)
                    min_time_imb = [pmin] * (min_time - delivery_duration)
                else:
                    min_time_fuel = []
                    min_time_imb = []

            if direction == 'downward':
                pre_ramp=[pmin - ramp_limit_shut_down* pmax * t for t in range(1,stoptime)]
                post_ramp=[ramp_limit_start_up * pmax * t for t in range(1,starttime)]
                if (av_cap['commit'].iloc[startrow - starttime:startrow] < pmin).any():
                    #get first value !=0
                    pre_first_commit=(av_cap[['delivery_day','delivery_time','commit']].iloc[
                            startrow  - starttime:startrow]).loc[
                            (av_cap['commit'].iloc[startrow - starttime :startrow] < pmin)].iloc[-1]
                    saved_start_ramp = True
                    pre_sched_ramp = [ramp_limit_start_up * pmax * t for t in range(1,starttime)]
                    pre_overlap = startrow - av_cap.loc[(av_cap['delivery_day']==pre_first_commit['delivery_day'])&(
                            av_cap['delivery_time']==pre_first_commit['delivery_time'])].index[0] - 1
                    pre_imb = [sr for sr in  pre_sched_ramp[:pre_overlap]]
                elif (av_cap['commit'].iloc[startrow - starttime -  stoptime +1 :startrow] <pmin).any():
                    #get first value !=0
                    pre_first_commit=(av_cap[['delivery_day','delivery_time','commit']].iloc[
                            startrow  - starttime -  stoptime +1 :startrow]).loc[
                            (av_cap['commit'].iloc[startrow - starttime -  stoptime +1:startrow] <pmin)].iloc[-1]
                    saved_start_ramp = True
                    pre_sched_ramp = [ramp_limit_start_up * pmax * t for t in range(1,starttime)]
                    pre_overlap = startrow - av_cap.loc[(av_cap['delivery_day']==pre_first_commit['delivery_day'])&(
                            av_cap['delivery_time']==pre_first_commit['delivery_time'])].index[0] - 1
                    pre_imb = [sr for sr in  pre_sched_ramp[:pre_overlap]]
                else:
                    saved_start_ramp = False
                    pre_imb = [- ramp_limit_shut_down* pmax * t for t in range(1,stoptime)]

                if (av_cap['commit'].iloc[endrow :endrow+ stoptime - 1] <pmin).any():
                    #get first value !=0
                    post_first_commit=(av_cap[['delivery_day','delivery_time','commit']].iloc[
                            endrow :endrow + stoptime-1]).loc[
                            (av_cap['commit'].iloc[endrow :endrow+ stoptime - 1] <pmin)].iloc[0]
                    saved_stop_ramp = True
                    post_sched_ramp = [pmin- ramp_limit_shut_down * pmax * t for t in range(1,stoptime)]
                    post_overlap = av_cap.loc[(av_cap['delivery_day'] == post_first_commit['delivery_day'])&(
                            av_cap['delivery_time']==post_first_commit['delivery_time'])].index[0] - endrow
                    post_imb = [ sr for sr in  post_sched_ramp[-post_overlap :]]

                elif (av_cap['commit'].iloc[endrow :endrow+ stoptime - 1 + starttime -1] <pmin).any():
                    #get first value !=0
                    post_first_commit=(av_cap[['delivery_day','delivery_time','commit']].iloc[
                            endrow :endrow + stoptime-1+ starttime -1]).loc[
                            (av_cap['commit'].iloc[endrow :endrow+ stoptime - 1 + starttime -1] <pmin)].iloc[0]
                    saved_stop_ramp = True
                    post_sched_ramp = [pmin- ramp_limit_shut_down * pmax * t for t in range(1,stoptime)]
                    post_overlap = av_cap.loc[(av_cap['delivery_day'] == post_first_commit['delivery_day'])&(
                            av_cap['delivery_time']==post_first_commit['delivery_time'])].index[0] - endrow
                    post_imb = [sr for sr in  post_sched_ramp[-post_overlap:]]
                else:
                    saved_stop_ramp = False
                    post_imb = [-pmin + ramp_limit_start_up* pmax * t for t in range(1,starttime)]
                if delivery_duration < min_time:
                    min_time_fuel = [-pmin] * (min_time - delivery_duration)
                    min_time_imb = [-pmin] * (min_time - delivery_duration)
                else:
                    min_time_fuel = []
                    min_time_imb = []

            #this is only for visualization/controle
            if pre_ramp:
                av_cap['required_ramp'].iloc[startrow - len(pre_ramp):startrow ] = pre_ramp
            if min_time_fuel + post_ramp:
                av_cap['required_ramp'].iloc[endrow - len(min_time_fuel): endrow + len(post_ramp)]=min_time_fuel + post_ramp
            #add scheduled ramp
            if pre_sched_ramp:
                av_cap['scheduled_startstop'].iloc[startrow - pre_overlap :startrow - pre_overlap  + len(pre_sched_ramp)] = pre_sched_ramp
            if post_sched_ramp:
                av_cap['scheduled_startstop'].iloc[endrow + post_overlap - len(post_sched_ramp): endrow + post_overlap]= post_sched_ramp
            #add effect of min up and down time
            if delivery_duration < min_time:
                extra_mintime =  (min_time - delivery_duration)
            else:
                extra_mintime=0
            #determine additional fuel needed
            if (direction=='upward'):
                av_cap['adjusted_commit'].iloc[startrow - pre_overlap:startrow ] = pmin -av_cap['commit'].iloc[startrow - pre_overlap:startrow ]
                av_cap['adjusted_commit'].iloc[endrow-  extra_mintime: endrow + post_overlap
                      ]= pmin - av_cap['commit'].iloc[endrow-  extra_mintime: endrow + post_overlap]
                direction_factor = 1
            elif (direction=='downward'):
                av_cap['adjusted_commit'].iloc[startrow - pre_overlap:startrow ] = -av_cap['commit'].iloc[startrow - pre_overlap:startrow ]
                av_cap['adjusted_commit'].iloc[endrow-  extra_mintime: endrow + post_overlap
                      ]=-av_cap['commit'].iloc[endrow-  extra_mintime: endrow + post_overlap]
                direction_factor = -1
            #determine additional imbalance
            if (saved_stop_ramp ==True):
                av_cap['imb_from_startstop'].iloc[startrow - pre_overlap:startrow ] = av_cap[
                        'adjusted_commit'].iloc[startrow - pre_overlap:startrow ] - (av_cap[
                                'scheduled_startstop'].iloc[startrow - pre_overlap : startrow] *direction_factor)
            else:
               av_cap['imb_from_startstop'].iloc[startrow - len(pre_imb):startrow ] =pre_imb
            if (saved_start_ramp ==True):
                av_cap['imb_from_startstop'].iloc[endrow-extra_mintime: endrow + post_overlap]= av_cap[
                    'adjusted_commit'].iloc[endrow-extra_mintime: endrow + post_overlap]-(av_cap[
                            'scheduled_startstop'].iloc[endrow-extra_mintime: endrow + post_overlap] *direction_factor)
            else:
                av_cap['imb_from_startstop'].iloc[endrow: endrow + len(post_imb)]= post_imb
                if min_time_imb:
                    av_cap['imb_from_startstop'].iloc[startrow + delivery_duration:startrow +min_time] = min_time_imb

            #NOTE: positive values for costs are actual spendings. Negative values are savings.

            #calculate cost
            av_cap['additional_fuel_cost'] =  av_cap['adjusted_commit'] * srmc/4

            #when the expected price is positive, short BRPs pay, long BRPs receive. In all regulating states.
            #What they receive, can, however be lower than srmc.
            #Because of convention that long positions are positive and cost (pendings) are also positive,
            #multiplication by -1 is needed
            av_cap['imb_cost'] = av_cap.apply(
                    lambda x: -x['imb_from_startstop']*x['expected_IBP_long']/4 if (x['imb_from_startstop'] >= 0)
                    else  -x['imb_from_startstop']*x['expected_IBP_short']/4, axis=1)

            additional_fuel_cost = av_cap['additional_fuel_cost'].sum()
            imbalance_risk_cost =  av_cap['imb_cost'].sum()
            # check if start stop cost are saved
            if saved_stop_ramp == True:
                saved_stop = -shut_down_cost
                start_up =0
            else:
                saved_stop = 0
                start_up = start_up_cost
            if saved_start_ramp == True:
                saved_start = -start_up_cost
                shut_down =0
            else:
                saved_start = 0
                shut_down = shut_down_cost

            total_cost = start_up + shut_down + imbalance_risk_cost + additional_fuel_cost + saved_stop + saved_start
            markup = int(round(total_cost/(pmin * delivery_duration/4),0)) #EUR/MWh
            #PARTIAL CALL MARKUP
            if partial_call == True:
                #risk markup of partial activation 0< > pmin is included
                #assumed probability of partial call is a uniform discrete distribution
                if ((type(pmin) is not np.int32)&(type(pmin) is not np.int64))|(
                        type(minimum_call) is not int)|(type(order_granularity) is not int):
                    raise Exception (
                            "partial call works with a assumption of natural numbers and therefore needs positive integers for pmin,minimum_call and order_granularity")
                #expected value for partial call (Todo: make expected value a variable of the method)
                ePC = (minimum_call + pmin)/2
                #risk factor is the part of the offered volume(pmin), which is not covered by the return of the partial call
                risk_factor = (pmin -ePC)/pmin #p.u. of offer volume

                 #mean expected imbalance price during delivery period
                if direction == 'upward':
                    #assumption in case of partial upward call, dispatch needs to be adjusted to pmin
                    mean_eibp =av_cap[['expected_IBP_long']].iloc[startrow:endrow].mean().round().values[0]
                elif direction == 'downward':
                    #assumption in case of partial downward call, dispatch needs to be adjusted to 0
                    mean_eibp =av_cap[['expected_IBP_short']].iloc[startrow:endrow].mean().round().values[0]

                markup = markup + (markup +  mean_eibp) * risk_factor

#                #old approach
#                harmonic_series = sum(1/d for d in range(1,int(round((pmin - minimum_call)/order_granularity))))
#                #add partial call risk markup to startstop markup
#                markup = (markup +  mean_eibp) * harmonic_series

            #add markup of offer to list
            markup_lst += [int(round(markup,0))]
            #add markup to srmc to return a offer-price_lst
            if direction == 'upward':
                offer_price = srmc + markup
            elif direction == 'downward':
                #mark-up is negative because buy order of convention
                offer_price = srmc - markup
            offer_price_lst +=[int(round(offer_price,0))]

        return(offer_price_lst, markup_lst)

    def ramping_markup(self, direction='upward', of_volumes = None, asset = None, return_markup=True):
        """this method provides a list of mark_ups for risks of infeasible ramps.
        - It returns a list of the mark-ups only (for later addition to other mark_ups) or a price list (including srmc).
        - Currently delivery periods > 1 (block orders) are implemented. No error is raised if delivery period is > 1.
        - Positive values for costs are actual cost. Negative values are savings.
        - offered orders are operational capacity orders. No check on asset constraints in this method.
        - offer volumes are provided in list in size of model.schedules_horizon
        """

        if not of_volumes:
            #if no volumes to be calculated
            return([],[])
        if all(v==0 for v in of_volumes):
            #only zero volumes
            return([0]*len(of_volumes))

        srmc = asset.srmc #eur/mwh
        pmax = asset.pmax #MW
        ramp_limit_up = asset.ramp_limit_up #p.u. of pmax per isp
        ramp_limit_down = asset.ramp_limit_down
#        import pdb
#        pdb.set_trace()
        #test if thre are unfeasible ramps
        check_ramps = asset.schedule.loc[self.model.schedules_horizon.index].copy()
        check_ramps['offered']= of_volumes


        if direction == 'upward':
            check_ramps['delta_ramp'] =  check_ramps['rem_ramp_constr_avail_up'] -check_ramps['offered']
        elif direction == 'downward':
            check_ramps['delta_ramp'] = check_ramps['rem_ramp_constr_avail_down'] -check_ramps['offered']
        if not (check_ramps['delta_ramp'] < 0).any():
            #no unfeasible ramps. markup is 0.
            if return_markup ==True:
                return([0]*len(of_volumes))
            else:
                return([srmc]*len(of_volumes))
        #expected imbalance prices
        eIBP = self.model.rpt.eIBP.loc[self.model.schedules_horizon.index].copy()
        av_cap = asset.schedule.loc[self.model.schedules_horizon.index].copy()
        #get expected imbalance prices for the known DAP
        av_cap = pd.concat([av_cap,eIBP[['expected_IBP_short','expected_IBP_long']]], axis=1)
        av_cap.reset_index(inplace=True)

        markup_lst = []
        offer_price_lst = []
        for b in range(len(of_volumes)):
            #check if this volumes has a unfeasible ramp
            if check_ramps['delta_ramp'].iloc[b] >= 0:
                markup_lst += [0]
                offer_price_lst += [srmc]
                continue
            if of_volumes[b] == 0:
                markup_lst += [0]
                offer_price_lst += [srmc]
                continue

            av_cap['required_ramp']=0
            av_cap['imb_from_startstop'] = 0

            if direction == 'upward':
                offer = of_volumes[b] + av_cap['commit'].iloc[b].copy()
            elif direction == 'downward':
                offer = av_cap['commit'].iloc[b].copy() - of_volumes[b]
            #this is an assumption of this method without control
            delivery_duration = 1
            startrow = b
            endrow = startrow + delivery_duration
            pre_ramp=[]
            post_ramp=[]
            ramp = offer #startvalue is offer volume + commit
            success= False
            i =1
            #CALCULATE BEGIN RAMP
            while success == False:
                if startrow - i < 0:
                    #ensure that out of schedule_horizon do not lead to errors
                    #out of schedule ramps are ignored
                    break
                if av_cap['commit'].iloc[startrow - i] < ramp:
                    if abs(av_cap['commit'].iloc[startrow - i] - ramp) > pmax * ramp_limit_up:
                        ramp -= pmax * ramp_limit_up
                        pre_ramp +=[ramp]
                    else:
                        ramp -= abs(av_cap['commit'].iloc[startrow - i] - ramp)
                        success = True
                    i += 1
                elif av_cap['commit'].iloc[startrow - i] > ramp:
                    if abs(av_cap['commit'].iloc[startrow - i] - ramp) > pmax * ramp_limit_up:
                        ramp += pmax * ramp_limit_up
                        pre_ramp  +=[ramp]
                    else:
                        ramp += abs(av_cap['commit'].iloc[startrow - i] - ramp)
                        success = True
                    i += 1
                else:
                   success = True
            pre_ramp = list(reversed(pre_ramp)).copy()

            #CALCULATE END RAMP
            ramp = offer
            i =0
            success = False
            while success == False:
                if endrow + i > len(av_cap) -1:
                    #ensure that out of schedule_horizon do not lead to errors
                    #out of schedule ramps are ignored
                    break
                if av_cap['commit'].iloc[endrow + i] < ramp:
                    if abs(av_cap['commit'].iloc[endrow + i] - ramp) > pmax * ramp_limit_down:
                        ramp -= pmax * ramp_limit_down
                        post_ramp +=[ramp]
                    else:
                        ramp -= abs(av_cap['commit'].iloc[endrow + i] - ramp)
                        success = True
                    i += 1
                elif av_cap['commit'].iloc[endrow + i] > ramp:
                    if abs(av_cap['commit'].iloc[endrow + i] - ramp) > pmax * ramp_limit_up:
                        ramp += pmax * ramp_limit_up
                        post_ramp  +=[ramp]
                    else:
                        ramp += abs(av_cap['commit'].iloc[endrow + i] - ramp)
                        success = True
                    i += 1
                else:
                    success = True

            if pre_ramp:
                av_cap.iloc[startrow - len(pre_ramp):startrow ]['required_ramp'] = pre_ramp
            if post_ramp:
                av_cap['required_ramp'].iloc[endrow: endrow + len(post_ramp)]= post_ramp
            #calc imbalance volume from ramping
            mask = av_cap['required_ramp'] ==0
            av_cap['imb_from_startstop']  =av_cap['imb_from_startstop'].where(mask, av_cap['required_ramp']-av_cap['commit'] )

            #additional fuel costs (costs in operating area startup / shut down period is captured in start stop costs)
            av_cap['additional_fuel_cost'] = av_cap['imb_from_startstop']
            av_cap['additional_fuel_cost'] =  av_cap['additional_fuel_cost'] *srmc/4

            #when the expected price is positive, short BRPs pay, long BRPs receive. In all regulating states.
            #What they receive, can, however be lower than srmc.
            #because fo convention that long positions are positive and cost (pendings) are also positive,
            #multiplication by -1 is needed
            av_cap['imb_cost'] = av_cap.apply(
                    lambda x: -x['imb_from_startstop']*x['expected_IBP_long']/4 if (x['imb_from_startstop'] >= 0)
                    else  -x['imb_from_startstop']*x['expected_IBP_short']/4, axis=1)

            additional_fuel_cost = av_cap['additional_fuel_cost'].sum()
            imbalance_risk_cost =  av_cap['imb_cost'].sum()
            av_cap['net_cost'] = av_cap[['additional_fuel_cost', 'imb_cost']].sum(axis=1)

            total_cost = imbalance_risk_cost + additional_fuel_cost
            markup = int(round(total_cost/(of_volumes[b] * delivery_duration/4),0)) #EUR/MWh
            #add markup of offer to list
            markup_lst += [int(round(markup,0))]

            #add markup to srmc to return a offer-price_lst
            if direction == 'upward':
                offer_price = srmc + markup
            elif direction == 'downward':
                #mark-up is negative because buy order of convention
                offer_price = srmc - markup
            offer_price_lst +=[int(round(offer_price,0))]

        if return_markup ==True:
            return(markup_lst)
        else:
            return(offer_price_lst)

    def doublescore_markup(self, direction='upward', of_volumes = None, asset = None, return_markup=True):
        """this method provides a list of mark_ups for risks of double score on redispatch and intraday trade.
        - It returns a list of the mark-ups only (for later addition to other mark_ups) or a price list (including srmc).
        - Currently delivery periods == 1 (block orders) are implemented. No error is raised if delivery period is > 1.
        - Positive values for costs are actual cost. Negative values are savings.
        - offered orders are operational capacity orders. No check on asset constraints in this method.
        - UNCHECKED ASSUMPTION: offered capaciy == full_available_capacity
        - Be aware of rounding consequences
        """

        if not of_volumes:
            #if no volumes to be calculated
            return([],[])
        if all(v==0 for v in of_volumes):
            #only zero volumes
            return([0]*len(of_volumes))

        srmc = asset.srmc #eur/mwh

        #get the position from offered on IDM
        buy_position, sell_position =self.model.IDM_obook.get_offered_position(associated_asset=asset.assetID)
        #deduct offered positio from availble capacity

        if direction == 'upward':
            if asset.schedule['full_available_up'].loc[
                         self.model.schedules_horizon.index].index.isin(sell_position.index).any():
                av_cap = asset.schedule['full_available_up'].loc[
                             self.model.schedules_horizon.index].fillna(0).to_frame().join(
                             sell_position).copy()

            else:
                #sell_position empty or outside schedule
                markup_up = [0]*len(of_volumes)
                return(markup_up)
        elif direction == 'downward':
            if asset.schedule['full_available_down'].loc[
                         self.model.schedules_horizon.index].index.isin(buy_position.index).any():
                av_cap = asset.schedule['full_available_down'].loc[
                                 self.model.schedules_horizon.index].fillna(0).to_frame().join(
                                 buy_position).copy()
            else:
                #buy_position empty or outside schedule
                markup_down = [0]*len(of_volumes)
                return(markup_down)
        else:
            raise Exception('direction must be upward or downward')


        #expected imbalance prices
        eIBP = self.model.rpt.eIBP.loc[self.model.schedules_horizon.index].copy()
        #get expected imbalance prices for the known DAP
        av_cap = pd.concat([av_cap,eIBP[['expected_IBP_short','expected_IBP_long']]], axis=1)

        #assumption uniform distribution, with minimum called capacity =1
        # exp value = (min + max)/2
        min_IDM_capacity = 1 #MW
        av_cap['exp_doublescore_vol'] = (min_IDM_capacity + av_cap['volume']).where(
                av_cap['volume']> 0, 0)/2
        if direction =='upward':
            #double scoring leads to short position
            #transform MW to MWh in order to multiply by EUR/MWh. Divided by 4 because delivery duration is 15 minutes.
            av_cap['imb_cost_doublescore'] = av_cap['exp_doublescore_vol'] * av_cap['expected_IBP_short'] / 4
            #divid expected imbalance cost by offer volume (MW) and multiply by 4 to get EUR/MWh
            av_cap['markup'] = av_cap['imb_cost_doublescore'].div(av_cap['full_available_up']).replace(to_replace=np.inf, value=0) * 4
            av_cap['offer_price']= srmc + av_cap['markup']
        elif direction =='downward':
            #double scoring leads to short position
            av_cap['imb_cost_doublescore'] = av_cap['exp_doublescore_vol'] * av_cap['expected_IBP_long'] / 4
            #divid expected imbalance cost by offer volume (MW) and multiply by 4 to get EUR/MWh
            av_cap['markup'] = av_cap['imb_cost_doublescore'].div(av_cap['full_available_down']).replace(to_replace=np.inf, value=0) * 4
            av_cap['offer_price']= srmc - av_cap['markup']

        av_cap['markup'].fillna(value= 0, inplace=True)
        av_cap['offer_price'].fillna(value= 0, inplace=True)

        markup_lst = list(av_cap['markup'].round().astype(int))
        offer_price_lst = list(av_cap['offer_price'].round().astype(int))

        if return_markup ==True:
            return(markup_lst)
        else:
            return(offer_price_lst)






